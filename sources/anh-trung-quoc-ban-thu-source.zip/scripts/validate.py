from pathlib import Path
import json,subprocess,sys
r=Path(__file__).resolve().parents[1];m=json.loads((r/'project/preview-timeline.json').read_text());full=json.loads((r/'project/scenes-full.json').read_text());cues=json.loads((r/'project/cues-full.json').read_text())
assert len(full)==116 and len(cues)==204
for scene in full:
 assert abs(scene['start']-cues[scene['srtStart']-1]['start'])<.002
 assert abs(scene['end']-cues[scene['srtEnd']-1]['end'])<.002
assert m['shots'][0]['start']==0 and m['shots'][-1]['end']==m['duration']
assert all(a['end']==b['start'] for a,b in zip(m['shots'],m['shots'][1:]))
assert len(m['voiceEnvelope'])==804 and all(c['end']<=26.8 for c in m['cues'])
for src in [m['audio'],*m['artAssets'],*[s['src'] for s in m['soundEffects']]]:assert (r/'public'/src).is_file(),src
print('Input QA: 116 scenes checked against 204 SRT cues; preview 4 continuous shots, 804 frames, all assets present.')
if len(sys.argv)>1:
 p=Path(sys.argv[1]);meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]));v=next(s for s in meta['streams'] if s['codec_type']=='video');a=next(s for s in meta['streams'] if s['codec_type']=='audio')
 assert (v['width'],v['height'],v['r_frame_rate'],v['codec_name'],a['codec_name'])==(1920,1080,'30/1','h264','aac')
 assert int(v['nb_frames'])==804 and abs(float(meta['format']['duration'])-26.8)<.06
 subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','/dev/null'],check=True)
 print('MP4 verified:',meta['format']['duration'],'s; 1080p30; H264/AAC; 804 frames; full decode passed.')
