from pathlib import Path
import subprocess,json,wave,numpy as np
r=Path(__file__).resolve().parents[1];rate=44100;dur=26.8;n=round(dur*rate)
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(r/'inputs/voice-original.mp3'),'-t',str(dur),'-ar',str(rate),'-ac','2','-f','f32le','-']);v=np.frombuffer(raw,'<f4').reshape(-1,2);mix=np.zeros((n,2),np.float32);mix[:len(v)]=v*.9
fx=[(.4,'paper-note',.14),(2.716,'thought-open',.14),(3.7,'steps',.12),(5.6,'blanket-grab',.1),(9.688,'soft-tap',.15),(11.928,'caption-snap',.13),(14.1,'pencil-cross',.1),(17.1,'focus-pop',.15),(19.542,'question-soft',.17),(21.3,'red-pencil',.13),(23.514,'success-chime',.13)]
source=r/'public/audio/sfx';(r/'public/audio/sfx').mkdir(exist_ok=True)
import shutil
for t,name,vol in fx:
 # Existing synthesised library is packaged in public/audio/sfx.
 with wave.open(str(source/f'{name}.wav')) as w:a=np.frombuffer(w.readframes(w.getnframes()),'<i2')/32768
 at=round(t*rate);count=min(n-at,len(a));mix[at:at+count]+=a[:count,None]*vol
rng=np.random.default_rng(1078)
def sound(at,length,kind,gain):
 count=round(length*rate);t=np.arange(count)/rate;noise=rng.normal(0,1,count);noise=np.convolve(noise,np.ones(13)/13,mode='same');env=np.sin(np.pi*np.arange(count)/max(count-1,1))**.7
 if kind=='fire':a=noise*(.5+.5*np.sin(t*37)**2)+.18*np.sin(t*2*np.pi*73)
 elif kind=='gravel':a=noise*np.exp(-t*2.5)*(.2+.8*np.sin(t*67)**8)
 else:a=noise*(.3+.7*np.sin(t*2.2)**2)+.05*np.sin(t*2*np.pi*430)
 a=a*env*gain;ix=round(at*rate);take=min(count,n-ix);mix[ix:ix+take]+=a[:take,None]
 soundpath=r/'public/audio/sfx'/f'original-{kind}-{at}.wav'
 with wave.open(str(soundpath),'wb') as w:w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes((a*32767).astype('<i2').tobytes())
 return dict(time=at,src=f'audio/sfx/{soundpath.name}',volume=1)
custom=[sound(0,9.4,'fire',.027),sound(3.9,.7,'gravel',.065),sound(6.25,2.5,'pour',.045),sound(9.8,1.4,'gravel',.055)]
mix[-round(.2*rate):]*=np.linspace(1,0,round(.2*rate))[:,None]
with wave.open(str(r/'public/audio/preview-mix.wav'),'wb') as w:w.setparams((2,2,rate,0,'NONE','not compressed'));w.writeframes((mix*32767).astype('<i2').tobytes())
cues=json.loads((r/'project/cues-full.json').read_text())
m={'profile':{'width':1920,'height':1080,'fps':30},'duration':dur,'audio':'audio/preview-mix.wav','shots':[dict(id=i,start=a,end=b) for i,a,b in [('foundry',0,9.688),('coal',9.688,11.928),('tax',11.928,19.542),('scholar',19.542,26.8)]],'events':{'establish':.4,'charge':3.7,'grabLadle':5.6,'pourStart':6.25,'pourEnd':8.8,'coal':9.688,'tax':11.928,'estimate':17.1,'question':19.542,'uncertain':21.3,'evidence':23.514},'soundEffects':[dict(time=t,src=f'audio/sfx/{name}.wav',volume=vol) for t,name,vol in fx]+custom,'cues':[c for c in cues if c['end']<=dur],'voiceEnvelope':[round(float(np.sqrt(np.mean(v[round(f*rate/30):min(len(v),round((f+1)*rate/30))]**2))),4) for f in range(round(dur*30))],'artAssets':['art/song-ironworks.png'],'notes':['Source prompt scenes 001–003; split scene002 into coal and tax shots.','Internal phrase event times are editorial choices; original cue boundaries retained.','AI background and separately drawn animated characters.']}
(r/'project/preview-timeline.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));assert np.abs(mix).max()<.95
(r/'public/audio/sfx/SOURCES.md').write_text('SFX from existing project synthesised library; original-fire/gravel/pour generated locally by seeded filtered noise. No external licensed audio. Voice supplied by user.\n')
print('Prepared 26.8 seconds; peak',np.abs(mix).max())
