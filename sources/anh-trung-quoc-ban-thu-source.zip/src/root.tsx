import React from 'react';
import {Composition} from 'remotion';
import {IndustryPreview} from './film';
export const Root:React.FC=()=> <Composition id="IndustryPreview" component={IndustryPreview} durationInFrames={804} fps={30} width={1920} height={1080}/>;
