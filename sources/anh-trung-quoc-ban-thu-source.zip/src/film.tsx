import React from 'react';
import {AbsoluteFill,Audio,Img,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Line as L,Face,Arm,Caption,K,ink,cream} from './primitive';
import timeline from '../project/preview-timeline.json';
const e=timeline.events;
function Fire({t}:{t:number}){return <g transform="translate(429 405)"><ellipse cy="0" rx="31" ry="18" fill="#ed9a3c" opacity={.25+Math.sin(t*9)*.07}/><path d={`M-28 17Q-40 -12 -18 ${-27-Math.sin(t*7)*6}Q-22 -8 -2 -11Q-4 -34 10 ${-47-Math.sin(t*9)*4}Q4 -20 21 -10Q36 -23 29 4L24 17Z`} fill="#ef9c3c"/><path d={`M-15 17Q-28 -5 -5 ${-18-Math.sin(t*11)*4}Q-3 1 10 -7Q25 7 17 17Z`} fill="#f6cf64"/>{[0,1,2,3].map(i=>{const p=(t*.8+i*.24)%1;return <circle key={i} cx={Math.sin(t*2+i)*21} cy={-p*90} r={1.6*(1-p)} fill="#ecac4b" opacity={1-p}/>})}</g>}
function Worker({x,y,t,scale=1,pose='idle',official=false}:{x:number;y:number;t:number;scale?:number;pose?:'idle'|'pour'|'charge';official?:boolean}){
 const tilt=pose==='pour'?K(t,e.grabLadle,e.pourStart,0,12)+K(t,e.pourStart,e.pourStart+.8,0,27)-K(t,e.pourEnd,e.pourEnd+.55,0,30):0;
 const bodyTilt=pose==='pour'?K(t,e.grabLadle,e.pourStart,0,3):Math.sin(t*1.5+x)*.5;
 return <g transform={`translate(${x} ${y}) scale(${scale})`}><ellipse cy="3" rx="35" ry="5" fill="#9d8f74" opacity=".2"/>
 <L d="M-14 -68L-19 -6L-34 -2 M14 -68L20 -6L33 -2" w={4}/>
 <g transform={`rotate(${bodyTilt} 0 -70)`}><L d="M-24 -143L-33 -73Q0 -64 34 -73L24 -143L10 -151H-10Z" fill={official?'#a86651':'#8da7a0'} w={2.5}/><L d="M-11 -146L8 -119L19 -143 M-29 -87H28 M1 -125V-90" w={1.5}/>
 <g transform={`translate(0 -181) rotate(${Math.sin(t*1.3+x)*.7})`}><Face t={t+x*.01} hat={official?'official':'blue'}/></g>
 {pose==='pour'?<><Arm points="M-25 -136L-13 -113L39 -133"/><Arm points="M24 -136L59 -114L89 -130"/><g transform={`translate(102 -133) rotate(${tilt})`}><L d="M-70 -1H-18" w={5}/><L d="M-18 -8H38L30 18Q9 35 -10 16Z" fill="#777c6b" w={2.5}/><path d="M-14 -7H34L26 4H-10Z" fill="#eb973f"/></g><circle cx="39" cy="-133" r="5" fill="#fffaf0" stroke={ink} strokeWidth="1.5"/><circle cx="89" cy="-130" r="5" fill="#fffaf0" stroke={ink} strokeWidth="1.5"/></>:pose==='charge'?<g transform={`rotate(${Math.sin(t*2)*7} 17 -134)`}><Arm points="M-24 -134L14 -153L48 -178"/><Arm points="M24 -135L46 -145L61 -175"/><g transform={`translate(58 -191) rotate(${K(t,e.charge,e.charge+1,0,40)})`}><L d="M-27 -16L26 -16L19 16H-19Z" fill="#bb9b6a" w={2}/><L d="M-23 -8H23 M-21 1H21 M-13 -16V16 M1 -16V16 M14 -16V16" w={1}/><path d="M-24 -18L-16 -30L-5 -24L2 -33L14 -26L23 -18Z" fill="#9c6647" stroke={ink} strokeWidth="1.5"/></g></g>:<><Arm points={`M-24 -134L-37 -102L-28 -77`}/><Arm points={`M24 -134L${42+Math.sin(t*1.2)*2} -107L29 -92`}/></>}
 </g></g>;
}
function Foundry({t}:{t:number}){const zoom=K(t,0,9.688,1,1.025);const tip=K(t,e.pourStart,e.pourStart+.8);return <g transform={`translate(${640*(1-zoom)} ${360*(1-zoom)}) scale(${zoom})`}>
 <image href={staticFile('art/song-ironworks.png')} x="0" y="0" width="1280" height="720"/><Fire t={t}/>
 <g opacity=".22">{[0,1].map(i=><ellipse key={i} cx={458+Math.sin(t*.5+i)*10} cy={67-(t*16+i*35)%75} rx={20+i*7} ry="12" fill="#9c9b90" opacity={.5}/>)}</g>
 <Worker x={371} y={86} scale={.28} t={t} pose="charge"/>
 <Worker x={555} y={532} scale={.65} t={t} pose="charge"/>
 {t>e.charge&&t<e.charge+1.15&&[0,1,2,3].map(i=>{const p=((t-e.charge)*1.2+i*.12)%1;return <path key={i} d="M-3 -3L4 -2L3 4L-4 3Z" fill="#9a6144" stroke={ink} strokeWidth="1" transform={`translate(${365+p*34} ${52+p*p*58}) rotate(${p*90})`}/>})}
 <L d="M808 609L942 594L965 626L821 643Z" fill="#9d8b69" w={2.5}/><path d="M831 617L917 608L936 623L838 633Z" fill="#716e58" stroke={ink} strokeWidth="1.5"/>
 {tip>0&&t<e.pourEnd+.3&&<><path d={`M849 507Q${850+Math.sin(t*18)*2} 550 862 618`} stroke="#f1ad50" strokeWidth={5*tip} fill="none"/><path d="M839 623L918 613L931 623L844 630Z" fill="#ed9c46" opacity={K(t,e.pourStart,e.pourEnd)}/></>}
 <Worker x={722} y={611} scale={.95} t={t} pose="pour"/>
 <Worker x={1110} y={581} scale={.83} t={t} official/>
 <Caption text="Miền Bắc Trung Quốc · 1078" x={927} y={91} t={t} start={e.establish} width={454}/>
 </g>}
function Coal({t}:{t:number}){const p=K(t,e.coal+.1,e.coal+1.2);return <g><g transform="translate(-150 -144) scale(1.35)"><image href={staticFile('art/song-ironworks.png')} width="1280" height="720"/><Fire t={t}/></g>
 <path d="M0 567Q190 442 370 535L432 720H0Z" fill="#575c54" stroke={ink} strokeWidth="3"/>
 {[0,1,2,3,4,5,6,7,8,9,10,11].map(i=><L key={i} d={`M${30+i%5*66} ${560+Math.floor(i/5)*51}l21 -21l32 10l-4 37l-32 7Z`} fill={i%2?'#555b55':'#6c7067'} w={2}/>)}
 <g transform={`translate(${K(t,e.coal,e.coal+1.1,357,561)} ${K(t,e.coal,e.coal+1.1,548,418)}) rotate(${-23+p*43})`}><L d="M0 0L348 -17" w={12}/><L d="M0 0L348 -17" w={7} stroke="#b7996e"/><L d="M-80 -20L0 -22L-3 25L-61 31L-87 7Z" fill="#82897c" w={3}/>{p<.65&&<L d="M-71 -23L-55 -45L-39 -37L-24 -45L-8 -28L-1 -20Z" fill="#4e554f" w={2}/>}</g>
 {p>.5&&[0,1,2,3].map(i=>{const q=Math.max(0,p-.5)*2;return <L key={i} d="M-8 -4L2 -10L10 0L2 9L-9 5Z" fill="#515852" w={1.5}/>}).map((a,i)=><g key={i} transform={`translate(${473+i*12} ${433+Math.max(0,p-.5)*180-i*12})`}>{a}</g>)}
 <Caption text="Than đá làm nhiên liệu" x={900} y={110} t={t} start={e.coal} width={380}/>
 </g>}
function Ledger({x,y,t,scale=1}:{x:number;y:number;t:number;scale?:number}){return <g transform={`translate(${x} ${y}) scale(${scale})`}><L d="M-175 -108Q-82 -127 0 -97Q84 -127 175 -108L181 124Q79 112 0 141Q-79 112 -182 124Z" fill="#e4d2ac" w={3}/><L d="M0 -97V141 M-166 -94Q-77 -109 -10 -86 M10 -86Q80 -109 165 -94" w={1.8}/>{[0,1,2,3,4,5].map(i=><L key={i} d={`M-150 ${-55+i*28}Q-76 ${-68+i*28} -22 ${-52+i*28} M22 ${-52+i*28}Q76 ${-68+i*28} 150 ${-55+i*28}`} w={1}/>)}</g>}
function Tax({t}:{t:number}){return <g><path d="M0 0H1280V720H0Z" fill={cream}/>
 <g opacity=".17" transform="translate(-46 0) scale(.66)"><image href={staticFile('art/song-ironworks.png')} width="1280" height="720"/></g><path d="M0 573H1280V720H0Z" fill="#d5bd96"/><L d="M0 573H1280" w={2}/>
 <Worker x={920} y={672} t={t} scale={1.42} official/>
 <L d="M588 543L1168 543L1212 596H548Z M588 596V720 M1169 596V720" fill="#b59166" w={3}/>
 <Ledger x={875} y={505} t={t} scale={.73}/>
 <g transform={`translate(${917+Math.sin(t*5)*8} ${480+Math.cos(t*6)*4}) rotate(-30)`}><L d="M0 0L53 -75" w={4}/><L d="M0 0L-3 9L5 2" fill={ink} w={1}/><circle cx="23" cy="-34" r="6" fill="#fffaf0" stroke={ink} strokeWidth="1.5"/></g>
 <L d="M1052 534L1117 532L1139 553H1066Z M1090 507L1157 506L1176 528H1105Z" fill="#8b9183" w={2}/>
 <Caption text="Từ những sổ thuế thời Tống…" x={640} y={96} t={t} start={e.tax} width={440}/>
 <g opacity={K(t,e.estimate,e.estimate+.3)}><text x="348" y="344" textAnchor="middle" fontFamily="Patrick" fontSize="56" fill={ink}>Có thể &gt;100.000</text><text x="348" y="389" textAnchor="middle" fontFamily="Patrick" fontSize="31" fill={ink}>tấn sắt / năm</text><Caption text="ƯỚC TÍNH" x={349} y={448} t={t} start={e.estimate+.2} width={180} color="#c8d6b0"/></g>
 </g>}
function Scholar({t}:{t:number}){const breathe=Math.sin(t*1.9)*1.1;return <g><path d="M0 0H1280V720H0Z" fill={cream}/><g transform="translate(730 139) scale(.36)" opacity={K(t,e.evidence,e.evidence+.5,0,.6)}><image href={staticFile('art/song-ironworks.png')} width="1280" height="720"/><Fire t={t}/></g>
 <g transform={`translate(430 ${372+breathe}) rotate(${Math.sin(t*1.3)*1.3})`}><L d="M-57 44L-76 190H75L56 44Z" fill="#a99070" w={3}/><g transform="scale(1.45)"><Face t={t} hat="none" mood="question"/><circle cx="-13" cy="-3" r="11" fill="none" stroke={ink} strokeWidth="1.7"/><circle cx="13" cy="-3" r="11" fill="none" stroke={ink} strokeWidth="1.7"/><L d="M-2 -4H2" w={1.5}/></g><Arm points="M-54 74L-93 146L-46 174"/><Arm points={`M56 74L${104+Math.sin(t*2)*3} 115L118 158`}/></g>
 <L d="M143 539H755L819 610H106Z M153 610V720 M751 610V720" fill="#bc9b71" w={3}/><Ledger x={420} y={527} t={t} scale={.7}/><Ledger x={669} y={547} t={t} scale={.36}/>
 <g transform={`translate(${573+Math.sin(t*2)*4} ${491+Math.cos(t*2)*3})`}><circle cy="-28" r="34" fill="#c6d6cb" fillOpacity=".4" stroke={ink} strokeWidth="4"/><L d="M-20 -2L-48 43" w={9}/><L d="M-20 -2L-48 43" w={5} stroke="#a5a58d"/><L d="M-13 -48Q0 -57 15 -46" w={2} stroke="#fffdf2"/></g>

 <Caption text={t<e.evidence?'Con số còn gây tranh luận':'Luyện sắt phát triển: có cơ sở'} x={640} y={92} t={t} start={t<e.evidence?e.question:e.evidence} width={492} color={t<e.evidence?'#ead2ae':'#c8d6b0'}/>
 {t<e.evidence?<><text x="1000" y="413" textAnchor="middle" fontFamily="Patrick" fontSize="76" fill={ink}>100.000?</text><g opacity={K(t,e.uncertain,e.uncertain+.3)}><L d="M874 437Q1000 453 1126 435" w={3} stroke="#ad6547"/><text x="1000" y="497" textAnchor="middle" fontFamily="Patrick" fontSize="29" fill={ink}>Sổ thuế ≠ sản lượng thực tế</text></g></>:<><text x="999" y="475" textAnchor="middle" fontFamily="Patrick" fontSize="30" fill={ink}>Ngành luyện sắt thời Tống</text><path d="M950 519L977 539L1021 493" fill="none" stroke="#7f9771" strokeWidth="5" strokeLinecap="round" strokeDasharray="120" strokeDashoffset={120*(1-K(t,e.evidence,e.evidence+.6))}/></>}
 </g>}
export const IndustryPreview:React.FC=()=>{const frame=useCurrentFrame(),{fps}=useVideoConfig(),t=frame/fps;const shot=timeline.shots.find(s=>t>=s.start&&t<s.end)??timeline.shots[3];return <AbsoluteFill style={{background:cream}}><style>{`@font-face{font-family:Patrick;src:url('${staticFile('fonts/PatrickHand-Regular.ttf')}')}`}</style><Audio src={staticFile(timeline.audio)}/><svg width="100%" height="100%" viewBox="0 0 1280 720">{shot.id==='foundry'?<Foundry t={t}/>:shot.id==='coal'?<Coal t={t}/>:shot.id==='tax'?<Tax t={t}/>:<Scholar t={t}/>}<rect width="1280" height="720" fill="#302b28" opacity={Math.max(1-K(t,0,.2),K(t,26.6,26.8))}/></svg></AbsoluteFill>};
