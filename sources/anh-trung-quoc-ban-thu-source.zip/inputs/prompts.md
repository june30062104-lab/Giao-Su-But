# BỘ PROMPT TẠO ẢNH MINH HỌA — CÁCH MẠNG CÔNG NGHIỆP: ANH & TRUNG QUỐC

**Nguồn:** file phụ đề `Miền Bắc T.srt` của người dùng. **Thời lượng:** 00:00:00,059 – 00:14:59,640. **Phạm vi:** toàn bộ 204 dòng phụ đề, được gom thành 116 cảnh vừa đủ ý để minh họa. Tất cả mốc bắt đầu/kết thúc lấy trực tiếp từ SRT gốc.

**Quy tắc khi dựng:** Mỗi cảnh ứng với **một ảnh 16:9**, có thể giữ bằng pan, zoom nhẹ, parallax hoặc chuyển động đồ vật; những câu VO liên tiếp được gom khi một ảnh có thể thể hiện trọn nội dung. Nếu cần nhịp dựng nhanh hơn, có thể cắt thêm giữa các dòng SRT được nêu trong phạm vi cảnh. Không tạo những cảnh giả định như sự kiện lịch sử đã được ghi chép chính xác.

**Thiết kế đồng nhất:** nền giấy kem, viền mực đen vẽ tay, nhân vật người que đầu tròn trắng mắt chấm đen; nhà Tống/Thanh mặc áo dài và mũ đúng giai đoạn, thợ và thương nhân Anh mặc đồ lịch sử thế kỷ 18–19. Các sơ đồ dùng mũi tên và biểu tượng đơn giản, tránh chữ.

**Quy định chữ trong ảnh:** Ưu tiên không có chữ. Trường hợp cần thông tin minh họa, chỉ dùng **tiếng Việt có dấu** hoặc chữ số/năm, không dùng tiếng Anh, chữ Trung Quốc, ký tự giả, logo, watermark hay phụ đề. Chữ số nghiên cứu trong hình chỉ dùng để minh họa các ước tính đúng như lời VO.

---


### CẢNH 001 | 00:00:00,059 → 00:00:09,320 | SRT 1–2

**Lời thoại:** Miền Bắc Trung Quốc, năm 1078. Hãy hình dung những lò luyện sắt đỏ lửa, người thợ tiếp quặng vào lò, còn kim loại nóng chảy được đổ vào khuôn để tạo thành nông cụ và vũ khí.

**Prompt:** Toàn cảnh lò luyện sắt miền Bắc Trung Quốc thời Tống năm 1078; lò đất đá rất cao cháy cam rực, hai thợ đội khăn xanh đổ quặng vào lò, một thợ cầm cán gầu rót dòng sắt lỏng vào khuôn đúc lưỡi cày, người quan mặc áo đỏ đứng giám sát, mái ngói cong thấp thoáng; bố cục toàn cảnh rộng, tôn cảm giác kỹ nghệ nhộn nhịp. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 002 | 00:00:09,688 → 00:00:19,320 | SRT 3–4

**Lời thoại:** Nhiều nơi đã sử dụng than đá làm nhiên liệu. Từ các sổ thuế thời Tống, nhà sử học Robert Hartwell từng ước tính rằng sản lượng sắt của Trung Quốc cuối thế kỷ 11 có thể vượt 100.000 tấn mỗi năm.

**Prompt:** Cận cảnh than đá đen được xúc vào lò luyện thời Tống, phía sau một viên quan mặc áo đỏ ngồi bàn gỗ kiểm tra sổ thuế có những đường kẻ trống không chữ; bên cạnh đặt nhiều thỏi sắt; nếu cần chữ số chỉ hiện “100.000?” dưới dạng con số ước tính, không biến thành con số khẳng định. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 003 | 00:00:19,542 → 00:00:26,520 | SRT 5–6

**Lời thoại:** Con số này còn gây tranh luận, vì sổ thuế không cho biết chắc sản lượng thực tế. Nhưng sự phát triển mạnh của ngành luyện sắt thời Tống là điều có cơ sở.

**Prompt:** Một học giả hiện đại mặc áo nâu ngồi kiểm tra hai quyển sổ cổ và dùng kính lúp nhìn các cột tính; phía sau là hình mờ những lò luyện sắt thời Tống tiếp tục hoạt động; hai bàn tay cân nhắc giữa chứng cứ tư liệu và quy mô sản xuất, gương mặt đăm chiêu chứ không khẳng định chắc chắn. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 004 | 00:00:26,952 → 00:00:32,840 | SRT 7–8

**Lời thoại:** Và từ đây, một so sánh đầy tò mò xuất hiện. Hãy chuyển đến nước Anh năm 1788, hơn 700 năm sau.

**Prompt:** Trang tranh chuyển cảnh lịch sử kiểu minh họa so sánh: bên trái một lò luyện sắt Trung Quốc cổ đại đang rực lửa, bên phải bóng dáng xưởng gang nước Anh năm 1788; giữa hai bên là một dải lịch cuộn dài qua nhiều thế kỷ, có mũi tên ngang, không cần chữ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 005 | 00:00:33,292 → 00:00:40,600 | SRT 9–9

**Lời thoại:** Khi các xưởng máy đang dần thay đổi nền kinh tế, tổng sản lượng gang thô của cả Anh, Scotland và xứ Wales được ghi nhận ở mức khoảng 68.000 tấn.

**Prompt:** Toàn cảnh xưởng luyện gang nước Anh năm 1788, những nhà xưởng gạch và ống khói thấp bên dòng sông, người thợ mặc áo ghi-lê và mũ cũ làm việc với lò; góc dưới có các thỏi gang xếp thành đống; chèn duy nhất con số “68.000” và nhãn “TẤN GANG THÔ” nếu cần dữ liệu. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 006 | 00:00:40,830 → 00:00:48,440 | SRT 10–11

**Lời thoại:** Đây là số liệu gang thô, không thể so trực tiếp với ước tính sắt thời Tống. Nhưng khoảng cách thời gian hơn bảy thế kỷ vẫn khiến sự so sánh trở nên thú vị.

**Prompt:** Hai chồng thỏi kim loại đặt trên hai bục khác nhau, một bên có thợ Trung Quốc thời Tống, bên kia thợ luyện gang Anh thế kỷ 18; giữa là nhà sử học giơ tay báo hiệu không thể so trực tiếp, hai bảng đo khác kiểu và một biểu tượng dấu hỏi; không dùng dấu bằng hay biểu đồ khẳng định chính xác. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 007 | 00:00:48,673 → 00:00:56,200 | SRT 12–12

**Lời thoại:** Nếu bạn sống vào năm 1100 và phải dự đoán nơi nào sẽ bước vào kỷ nguyên máy móc trước, liệu bạn có nghĩ đến một hòn đảo lạnh và ẩm ở rìa châu Âu?

**Prompt:** Bản đồ châu Âu đơn giản vẽ tay, nước Anh là hòn đảo nhỏ lạnh và nhiều mây mưa ở góc trái, một nhân vật đội mũ thế kỷ 18 cầm kính lúp nhìn hòn đảo ngạc nhiên; phía xa Trung Quốc cổ đại hiện như vùng đất có thành thị rộng lớn, không cần nhãn quốc gia. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 008 | 00:00:56,670 → 00:01:06,840 | SRT 13–14

**Lời thoại:** Thế mà Cách mạng Công nghiệp đầu tiên lại khởi phát ở nước Anh. Tại sao Trung Quốc có nhiều phát minh sớm hơn, nhưng nước Anh lại trở thành nơi máy móc, nhà máy và động cơ hơi nước phát triển thành một hệ thống sản xuất hoàn toàn mới?

**Prompt:** Khung hình đối lập lớn: bên trái các thành tựu Trung Quốc cổ xếp thành cụm lò sắt, la bàn và sách in; bên phải Anh xuất hiện nhà máy, động cơ hơi nước và bánh xe lớn, một mũi tên đỏ uốn về phía Anh; ánh mắt nhân vật người que hai bên đều tò mò, gợi câu hỏi tại sao. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 009 | 00:01:07,069 → 00:01:16,840 | SRT 15–16

**Lời thoại:** Câu trả lời không nằm ở việc ai thông minh hơn, mà ở chỗ những phát minh xuất hiện trong môi trường như thế nào, có đáng để sử dụng hay không, và liệu có đủ điều kiện để được cải tiến hết lần này đến lần khác.

**Prompt:** Sơ đồ biểu tượng giải thích: một chiếc bóng đèn ý tưởng ở giữa, xung quanh là mỏ than, túi tiền, người lao động, bánh răng, người thợ và chợ hàng; các sợi dây nối tạo thành mạng, hai nhân vật người que cùng chỉ vào các điều kiện thay vì so trí thông minh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 010 | 00:01:17,375 → 00:01:24,440 | SRT 17–18

**Lời thoại:** Để thấy câu hỏi khó đến đâu, hãy trở lại Trung Quốc thời Tống. Khoảng năm 1100, Khai Phong là một trong những đô thị lớn nhất thế giới.

**Prompt:** Toàn cảnh thành Khai Phong khoảng năm 1100, mái ngói Trung Hoa, cầu gỗ cong trên sông đầy thuyền hàng, tường thành và chợ nhỏ đông đúc, người dân áo choàng xanh vàng đỏ qua lại; góc nhìn từ cao kiểu tranh kể chuyện. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 011 | 00:01:24,669 → 00:01:34,440 | SRT 19–20

**Lời thoại:** Đường phố đông người qua lại, hàng hóa được vận chuyển trên những dòng sông, quán ăn và khu chợ hoạt động nhộn nhịp. Ở Trung Quốc, tiền giấy do nhà nước phát hành đã xuất hiện từ đầu thế kỷ 11.

**Prompt:** Cảnh chợ Khai Phong đông người mua bán vải, hàng gốm và đồ ăn; người mua đưa một tờ tiền giấy cho thương nhân, gần đó thuyền vận tải di chuyển trên sông, giữ tờ tiền không có ký tự giả dạng tiếng Trung hoặc tiếng Anh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 012 | 00:01:34,671 → 00:01:42,440 | SRT 21–22

**Lời thoại:** Vào khoảng những năm 1040, nghệ nhân Tất Thăng tìm ra cách sử dụng các con chữ rời bằng đất sét nung, trước Gutenberg ở châu Âu khoảng bốn thế kỷ.

**Prompt:** Trong xưởng in thời Tống, nghệ nhân Tất Thăng mặc áo xanh sẫm và đội khăn đặt từng con chữ đất sét nung nhỏ lên một khay in, bên cạnh là giấy và bản in vừa lấy ra; một người học việc nhìn chăm chú; không cần thể hiện ký tự trên bề mặt in. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 013 | 00:01:43,160 → 00:01:49,880 | SRT 23–23

**Lời thoại:** Vào cuối thế kỷ 11, Tô Tụng chế tạo một tháp đồng hồ thiên văn cao hơn 10 mét, vận hành bằng bánh xe nước và hệ thống cơ khí phức tạp.

**Prompt:** Một tháp đồng hồ thiên văn thời Tống cao nổi bật trên nền giấy kem, bánh xe nước quay ở chân tháp, các bánh răng và cần gạt lộ ra ở mặt cắt, Tô Tụng áo nâu đứng chỉ vào bộ máy, hai thợ nhỏ làm việc cạnh bánh xe. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 014 | 00:01:50,107 → 00:01:56,760 | SRT 24–24

**Lời thoại:** Sang năm 1313, cuốn Nông thư của Vương Trinh mô tả nhiều công cụ sản xuất, trong đó có thiết bị xe sợi sử dụng sức nước.

**Prompt:** Bên dòng nước ở Trung Quốc năm 1313, một bánh xe nước bằng gỗ dẫn chuyển động sang thiết bị xe sợi dài có nhiều trục, thợ thủ công mặc áo nâu quan sát các bó sợi gai; bên cạnh là cuốn sách cổ mở ra sơ đồ máy bằng nét vẽ, trang sách không có chữ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 015 | 00:01:57,283 → 00:02:07,240 | SRT 25–26

**Lời thoại:** Nhưng cần phân biệt: loại máy này gắn với kỹ thuật xử lý một số loại sợi dài như gai, lanh hoặc tơ, chứ không phải một chiếc máy kéo sợi bông giống hệt thiết bị xuất hiện ở Anh nhiều thế kỷ sau.

**Prompt:** Minh họa đối chiếu kỹ thuật trong cùng một khung: trái là bánh xe nước cùng bó sợi gai dài ở Trung Quốc cổ; phải là máy quay tay Jenny bên các búi bông mềm ở Anh, hai loại sợi được phóng to trong hai vòng tròn; đường phân cách rõ, nhấn mạnh chúng không phải cùng một loại thiết bị. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 016 | 00:02:07,470 → 00:02:16,440 | SRT 27–28

**Lời thoại:** Đến đầu thế kỷ 15, đô đốc Trịnh Hòa chỉ huy những hạm đội vượt Ấn Độ Dương tới tận bờ biển Đông Phi. Nhưng sở hữu nhiều phát minh không đồng nghĩa một cuộc cách mạng công nghiệp sẽ tự động diễn ra.

**Prompt:** Đô đốc Trịnh Hòa mặc áo dài xanh đứng trên boong tàu buồm gỗ lớn dẫn đoàn thuyền vượt đại dương, phía xa là bờ biển Đông Phi với cây cọ; trên góc phải hiện một bóng nhà máy dạng dấu hỏi mờ, nhấn mạnh đi biển giỏi không tự động có công nghiệp. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 017 | 00:02:16,913 → 00:02:22,920 | SRT 29–29

**Lời thoại:** Chính nghịch lý đó khiến Joseph Needham, một nhà khoa học người Anh ở thế kỷ 20, dành nhiều năm tìm hiểu lịch sử khoa học Trung Quốc.

**Prompt:** Joseph Needham, học giả Anh thế kỷ 20 tóc bạc đơn giản, áo vest nâu, ngồi bàn thư viện trước chồng sách và bản vẽ khoa học Trung Hoa; ông cầm kính lúp soi sơ đồ bánh xe nước và chữ in rời, gương mặt ngạc nhiên đầy hứng thú; không ghi tên bằng tiếng Anh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 018 | 00:02:23,145 → 00:02:31,880 | SRT 30–31

**Lời thoại:** Câu hỏi gắn với tên ông có thể tóm gọn như sau: tại sao Trung Quốc từng dẫn trước châu Âu ở nhiều lĩnh vực kỹ thuật, nhưng khoa học hiện đại và Cách mạng Công nghiệp lại phát triển mạnh trước tại châu Âu?

**Prompt:** Một học giả kiểu nhân vật người que đứng giữa hai cánh cửa lịch sử: bên trái các phát minh Trung Quốc như la bàn, sách in, lò luyện; bên phải xưởng máy châu Âu; dấu hỏi lớn nổi giữa, hai đường thời gian tiến tới các hướng khác nhau, không chữ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 019 | 00:02:32,254 → 00:02:39,480 | SRT 32–34

**Lời thoại:** Cũng không thể bảo Trung Quốc phát minh xong rồi ngủ quên. Trong thế kỷ 18, nền kinh tế nhà Thanh vẫn rất sôi động. Dân số tăng lên hàng trăm triệu người.

**Prompt:** Cảnh thành thị nhà Thanh thế kỷ 18 đông người, sông thuyền tấp nập, chợ buôn bán, những xe hàng và nhiều gia đình áo màu pastel; cảm giác kinh tế đang vận hành sôi động, không có cảnh ngủ quên hay đất nước suy tàn. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 020 | 00:02:39,708 → 00:02:50,440 | SRT 35–37

**Lời thoại:** Khu vực hạ lưu sông Dương Tử có những thành phố thương mại phát triển; nhiều gia đình vừa làm nông, vừa kéo sợi và dệt vải để bán. Các sử gia còn tranh luận mức sống của những vùng giàu có ở Trung Quốc có tương đương với nước Anh hay không.

**Prompt:** Một bố cục 3 vùng liền nhau: phố thương mại hạ lưu Dương Tử, gia đình nông dân kéo sợi và dệt vải bông bên khung cửi, thương nhân đang đổi cuộn vải lấy tiền; phía góc một học giả cầm hai bảng so sánh mức sống với vẻ chưa chắc chắn. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 021 | 00:02:50,946 → 00:02:59,400 | SRT 38–40

**Lời thoại:** Nhưng điểm quan trọng là Trung Quốc không đứng yên. Họ đang phát triển theo một con đường phù hợp với kinh tế và xã hội của mình. Vậy điều gì khiến con đường ấy không dẫn đến cơ giới hóa hàng loạt như tại Anh?

**Prompt:** Hai con đường minh họa từ cùng một thành phố Trung Quốc phát triển: một đường dẫn đến ruộng, chợ và thủ công nghiệp, đường kia hướng đến nhà máy máy móc ở xa; nhân vật người que đứng trước ngã rẽ suy nghĩ, tránh mô tả rằng một bên nghèo nàn hoặc không tiến bộ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 022 | 00:02:59,863 → 00:03:07,880 | SRT 41–43

**Lời thoại:** Mảnh ghép đầu tiên nằm dưới lòng đất. Hãy hình dung bạn đang ở trong một mỏ than Anh khoảng năm 1700. Dưới chân, nước ngầm rỉ ra từng chút một.

**Prompt:** Bên trong hầm mỏ than Anh khoảng năm 1700, lối đi gỗ chống đỡ nhỏ hẹp, thợ mỏ đội mũ vải, cầm nến, nước rịn ra từ đá và tạo vũng dưới chân; góc máy thấp sát mặt nước, không khí lạnh tối nhưng vẫn dễ nhìn. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 023 | 00:03:08,104 → 00:03:17,160 | SRT 44–46

**Lời thoại:** Công nhân càng đào sâu, nước càng khó kiểm soát. Nếu không bơm kịp, họ sẽ không thể tiếp tục khai thác. Vấn đề này trở nên cấp thiết vì nhu cầu than tại nước Anh đang tăng mạnh.

**Prompt:** Mặt cắt mỏ than sâu trong lòng đất, hai thợ mỏ vất vả đào than ở tầng thấp, nước ngầm dâng quanh giày, người quản lý trên mặt đất lo lắng nhìn chiếc hầm ngập nước; tạo áp lực buộc phải tìm cách bơm nước. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 024 | 00:03:17,490 → 00:03:24,360 | SRT 47–48

**Lời thoại:** Trong các thế kỷ trước, dân số và hoạt động đô thị phát triển khiến việc cung cấp củi với giá hợp lý, nhất là cho London, trở nên khó khăn hơn.

**Prompt:** Phố London thế kỷ 17 chật chội, nhà gạch thấp và nhiều hộ dân tranh mua bó củi được chở bằng xe ngựa, thương nhân nhìn bảng giá củi tăng bằng mũi tên đỏ không số, phía xa ống khói cho thấy nhu cầu nhiên liệu của đô thị. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 025 | 00:03:24,590 → 00:03:28,920 | SRT 49–49

**Lời thoại:** Điều thay đổi quan trọng là giá tương đối của những loại nhiên liệu và chi phí đưa chúng đến người sử dụng.

**Prompt:** Tranh so sánh kinh tế trực quan: bên trái bó củi trên xe vận tải đường bộ tốn tiền, bên phải thuyền chở than đá trên sông, một người chủ gia đình nhìn hai túi tiền với biểu cảm cân nhắc; các mũi tên giá hướng khác nhau, không ghi nhãn tiếng nước ngoài. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 026 | 00:03:29,315 → 00:03:35,320 | SRT 50–50

**Lời thoại:** Than có nhiều khói và gây ô nhiễm, nhưng có thể được vận chuyển bằng tàu từ các vùng khai thác ven biển đến London với mức giá cạnh tranh.

**Prompt:** Thuyền buồm gỗ chở đầy than đen đi trên biển gần bờ nước Anh hướng về bến London, phía xa nhiều mái nhà cùng những làn khói xám; hai công nhân đang dỡ than lên cầu cảng, tương phản giữa giá rẻ và ô nhiễm không khí. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 027 | 00:03:35,820 → 00:03:42,200 | SRT 51–52

**Lời thoại:** Khi nhu cầu tăng, những vỉa than dễ đào dần không đủ, buộc chủ mỏ phải xuống sâu hơn. Và xuống sâu đồng nghĩa phải đối mặt với nước ngầm.

**Prompt:** Mặt cắt tầng đất cho thấy thợ mỏ đã đào hết vỉa than nông và phải xuống đường hầm sâu hơn, bên dưới nước ngầm tràn vào; một người quản đốc trên mặt đất nắm bản thiết kế bơm, gương mặt lo lắng. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 028 | 00:03:42,429 → 00:03:51,400 | SRT 53–54

**Lời thoại:** Bơm nước bằng sức người hoặc sức ngựa vừa tốn công vừa tốn tiền. Năm 1712, Thomas Newcomen lắp đặt một động cơ bơm nước gần Dudley, vùng Midlands.

**Prompt:** Cảnh chuyển đổi phương án bơm nước: bên trái ngựa quay bánh guồng nặng nhọc bên mỏ, bên phải động cơ hơi nước Newcomen bằng gỗ và kim loại đứng gần mỏ Dudley năm 1712, người thợ chỉ vào cỗ máy mới; hình chưa hiện đại hóa quá mức. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 029 | 00:03:51,797 → 00:03:59,640 | SRT 55–56

**Lời thoại:** Hơi nước được làm ngưng tụ trong xi-lanh để tạo vùng áp suất thấp. Khi áp suất trong xi-lanh giảm, áp suất không khí bên ngoài đẩy pít-tông chuyển động, qua đó vận hành hệ thống bơm.

**Prompt:** Hình cắt đơn giản của động cơ Newcomen: nồi hơi nhỏ bên lò lửa, ống dẫn sang xi-lanh lớn, những giọt nước lạnh ở trong làm hơi ngưng tụ, pít-tông có mũi tên đi xuống và đòn bẩy gỗ phía trên vận hành máy bơm; sơ đồ dễ đọc, không cần chữ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 030 | 00:04:00,115 → 00:04:10,120 | SRT 57–59

**Lời thoại:** Nhìn từ thời nay, động cơ này tiêu hao quá nhiều than. Nhưng có một chi tiết quyết định: nó được đặt gần nơi khai thác than, nơi nhiên liệu có thể mua rất rẻ, kể cả loại than vụn khó bán.

**Prompt:** Động cơ Newcomen đang bơm nước, một người thợ xúc rất nhiều than vào lò, khói xám dày, ngay bên cạnh là đống than vụn giá rẻ tại mỏ; người chủ mỏ đứng cân nhắc chi phí và vẫn hài lòng vì nước được bơm ra. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 031 | 00:04:10,351 → 00:04:16,520 | SRT 60–61

**Lời thoại:** Chừng nào việc bơm nước giúp chủ mỏ khai thác được thêm than và thu lợi nhuận, cỗ máy ấy vẫn đáng dùng, dù hiệu suất chưa cao.

**Prompt:** Một người quản lý mỏ cầm túi tiền và bảng tính không chữ, phía sau là máy hơi nước làm nước chảy khỏi hầm và xe goòng chở than đi ra; bố cục cho thấy động cơ kém hiệu suất vẫn mang lại lợi nhuận nếu giải quyết đúng nhu cầu. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 032 | 00:04:16,977 → 00:04:22,760 | SRT 62–62

**Lời thoại:** Nó tồn tại vì giải quyết được một bài toán kinh tế cụ thể, chứ không phải vì có ai đó quyết tâm thay đổi lịch sử nhân loại.

**Prompt:** Cận cảnh cảnh đời thường: thợ mỏ mừng rỡ nhìn đáy hầm đã rút bớt nước nhờ máy bơm, còn chủ mỏ chỉ lên vỉa than sâu; cỗ máy ở phía xa đơn giản và thô kệch, không có hào quang phát minh thần kỳ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 033 | 00:04:23,283 → 00:04:29,960 | SRT 63–63

**Lời thoại:** Hơn nửa thế kỷ sau, James Watt cải tiến động cơ bằng bộ ngưng tụ riêng biệt và được cấp bằng sáng chế năm 1769.

**Prompt:** James Watt, kỹ sư Scotland thế kỷ 18 mặc áo nâu, bên bàn máy vẽ tay cơ cấu ngưng tụ riêng đặt cạnh xi-lanh, ông dùng tay chỉ vào đường ống dẫn hơi trong khi học việc quan sát; bối cảnh xưởng kỹ thuật gọn gàng. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 034 | 00:04:30,143 → 00:04:35,960 | SRT 64–65

**Lời thoại:** Thiết kế mới tiết kiệm nhiên liệu hơn nhiều. Cùng đối tác Matthew Boulton, ông từng bước đưa động cơ hơi nước đến các nhà xưởng.

**Prompt:** Khung đối chiếu hai động cơ hơi nước cạnh nhau: bên trái máy Newcomen tỏa khói và dùng nhiều than, bên phải máy cải tiến của Watt có bộ ngưng tụ tách riêng và đống than ít hơn; phía sau Watt cùng Boulton đứng trước cánh cửa xưởng dệt. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 035 | 00:04:36,409 → 00:04:43,720 | SRT 66–67

**Lời thoại:** Đó là một khác biệt đáng chú ý giữa việc phát minh ra một thiết bị và việc tạo được môi trường để nó liên tục được hoàn thiện. Nhưng vì sao than của Anh thuận lợi đến vậy?

**Prompt:** Một chuỗi ba xưởng có cùng cỗ máy được cải tiến qua các giai đoạn: cỗ máy bơm nước thô ban đầu, bàn sửa chữa của người thợ, máy hơi nước vận hành dây đai xưởng dệt; người thợ cầm cờ lê nhìn bản đồ mỏ than của Anh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 036 | 00:04:44,107 → 00:04:50,760 | SRT 68–69

**Lời thoại:** Không chỉ vì trữ lượng. Những vùng khai thác như Newcastle, Midlands, Yorkshire và Lancashire tương đối gần các đô thị,

**Prompt:** Bản đồ cách điệu nước Anh, những khối than đen gần Newcastle, Midlands, Yorkshire, Lancashire, các thành phố có mái nhà tập trung bên cạnh mỏ; các đường nối ngắn thể hiện vị trí thuận lợi, không cần nhãn tiếng Anh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 037 | 00:04:50,986 → 00:04:57,160 | SRT 70–71

**Lời thoại:** đường biển, sông ngòi và sau này là kênh đào. Trung Quốc cũng có những mỏ than khổng lồ, đặc biệt ở miền Bắc và Tây Bắc.

**Prompt:** Sơ đồ vận tải hai tầng: một tàu chở than đi men bờ biển Anh gần thành phố, cạnh đó một vùng khai thác than lớn ở miền bắc Trung Quốc, đặt trên hai khung bản đồ mộc mạc; chỉ dùng icon thuyền, than, điểm đến. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 038 | 00:04:57,668 → 00:05:04,760 | SRT 72–73

**Lời thoại:** Nhưng đến thế kỷ 18, nhiều trung tâm sản xuất và thương mại giàu có nhất đã nằm ở hạ lưu sông Dương Tử, cách các vùng than lớn một quãng rất xa.

**Prompt:** Bản đồ Trung Quốc dạng nét mực tối giản, phía Bắc/Tây Bắc có biểu tượng những núi than đen, vùng hạ lưu sông Dương Tử phía nam có chợ, xưởng thủ công và thuyền hàng đông đúc; đường nối dài ngoằn ngoèo giữa hai nơi, không ghi tên bằng chữ nước ngoài. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 039 | 00:05:04,992 → 00:05:14,760 | SRT 74–75

**Lời thoại:** Với phương tiện vận tải thời ấy, chuyển hàng khối lượng lớn như than qua hàng nghìn cây số là một việc tốn kém. Than dồi dào ở một nơi, nhưng khó được chuyển đến nhiều trung tâm sản xuất khác với mức giá cạnh tranh.

**Prompt:** Đoàn xe bò chở những khối than nặng di chuyển qua đồi núi Trung Quốc cổ, người phu khuân vác mệt mỏi; cuối chân trời là thành thị phía nam rất xa, một túi tiền rơi bớt dọc tuyến biểu tượng cho chi phí vận tải lớn. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 040 | 00:05:15,238 → 00:05:25,160 | SRT 76–78

**Lời thoại:** Chính vị trí tài nguyên đã tạo ra một trở ngại thực tế. Còn những lò luyện sắt phát triển ở miền Bắc thời Tống thì sao? Năm 1127, quân Nữ Chân chiếm Khai Phong, triều đình Tống phải rút về phía nam.

**Prompt:** Trang sử liệu chia hai nửa: lò luyện sắt Bắc Tống đang rực sáng ở phía trước, phía sau cảnh binh lính Nữ Chân tiến gần thành Khai Phong năm 1127 và đoàn người rút về phương nam; tái hiện lịch sử có chừng mực, không bạo lực đẫm máu. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 041 | 00:05:25,549 → 00:05:34,040 | SRT 79–80

**Lời thoại:** Qua nhiều thế kỷ, trọng tâm kinh tế phát triển mạnh ở phía nam. Ngành luyện kim Trung Quốc không biến mất, nhưng những mạng lưới sản xuất từng phát triển ở miền Bắc đã bị gián đoạn nghiêm trọng.

**Prompt:** Bản đồ lối sản xuất Trung Quốc qua thế kỷ: biểu tượng xưởng luyện sắt phía Bắc bị ngắt bởi đoạn đường đứt gãy, những thuyền buôn và đồng lúa ở phía nam phát triển; không minh họa ngành luyện kim biến mất hoàn toàn. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 042 | 00:05:34,273 → 00:05:40,120 | SRT 81–81

**Lời thoại:** Theo nhà sử học Kenneth Pomeranz, khả năng tiếp cận than đá tương đối thuận lợi là một trong những may mắn địa lý của nước Anh.

**Prompt:** Học giả Kenneth Pomeranz dạng minh họa người que với áo vest xanh đứng cạnh bản đồ Anh có mỏ than nằm sát xưởng máy, tay cầm kính lúp chỉ quãng đường ngắn; bên cạnh là một cục than và biểu tượng vị trí địa lý may mắn. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 043 | 00:05:40,549 → 00:05:47,480 | SRT 82–83

**Lời thoại:** Tuy nhiên, nhiên liệu rẻ chưa đủ để khiến một chủ xưởng bỏ tiền mua máy. Người ấy còn phải thấy việc dùng máy có lợi hơn dùng lao động thủ công.

**Prompt:** Một chủ xưởng dệt người Anh thế kỷ 18 ngồi bàn gỗ giữa hai phương án: túi than rẻ và một cỗ máy bên phải, nhóm thợ kéo sợi bên trái; người chủ gãi đầu nhìn túi tiền để quyết định có nên mua máy. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 044 | 00:05:47,802 → 00:05:54,520 | SRT 84–85

**Lời thoại:** Hãy tưởng tượng bạn có một xưởng dệt. Nếu thuê thêm một người rất rẻ, trong khi mua và bảo trì máy đắt đỏ, bạn có thể sẽ tiếp tục thuê người.

**Prompt:** Bên trong xưởng kéo sợi truyền thống: nhóm người ngồi quay sợi bằng tay, cạnh họ là cỗ máy kéo sợi đắt tiền được phủ vải; chủ xưởng cầm ví tiền và bảng chi phí trống, nhấn mạnh thuê nhân công rẻ có thể hợp lý hơn mua máy. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 045 | 00:05:54,924 → 00:06:01,720 | SRT 86–86

**Lời thoại:** Nhà sử học kinh tế Robert Allen gọi sự chú ý vào giá tiền công và giá năng lượng là một chìa khóa quan trọng để hiểu công nghiệp hóa Anh.

**Prompt:** Robert Allen, sử gia kinh tế dạng người que áo sơ mi xanh, tại bàn làm việc đầy sổ giá và tiền lương, trên tường có một tranh so sánh túi tiền thuê người với giỏ than đá; ông nối các số liệu bằng đường vẽ nghiên cứu. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 046 | 00:06:02,171 → 00:06:09,160 | SRT 87–88

**Lời thoại:** Theo nghiên cứu của ông, tiền công ở một số khu vực Anh, nhất là London và các trung tâm phát triển, tương đối cao khi so với nhiều nơi khác;

**Prompt:** Một phố London thời thế kỷ 18, thợ thủ công cầm túi tiền nhận tiền công từ chủ xưởng, những đồng xu chất cao trên bàn; bên cạnh là các xưởng đang bận rộn, thể hiện chi phí nhân công cao tại một số trung tâm đô thị. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 047 | 00:06:09,392 → 00:06:13,240 | SRT 89–90

**Lời thoại:** trong khi than đá lại rẻ. Điều đó khuyến khích những phát minh tiết kiệm sức lao động.

**Prompt:** Cân đòn bẩy mang tính biểu tượng: một bên nhiều đồng tiền để trả nhân công, bên kia một xe than rất đầy nhưng túi tiền mua nhỏ; giữa cân là ông chủ xưởng mắt mở to vì nhận ra máy móc tiết kiệm lao động trở nên hấp dẫn. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 048 | 00:06:13,845 → 00:06:21,720 | SRT 91–91

**Lời thoại:** Vào những năm 1760, chiếc máy kéo sợi Jenny do James Hargreaves phát triển cho phép một người xe nhiều sợi cùng lúc bằng một chiếc máy quay tay.

**Prompt:** James Hargreaves dạng nhân vật người que mặc áo ghi-lê nâu đứng bên máy kéo sợi Jenny quay bằng tay, từ một tay quay đi ra nhiều cuộn sợi mảnh song song, một công nhân nhìn ngạc nhiên; cấu tạo gỗ đơn giản, không dùng động cơ điện. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 049 | 00:06:21,955 → 00:06:28,040 | SRT 92–93

**Lời thoại:** Phát minh ấy cho thấy sự khác biệt về động lực đầu tư: nếu tiết kiệm được nhiều tiền công, tiền mua máy có thể nhanh chóng được bù lại.

**Prompt:** Một chủ xưởng cầm bàn tính gỗ không chữ, phía sau một máy Jenny thay cho nhiều khung kéo sợi thủ công, túi tiền tiết kiệm tích dần bên cạnh; ánh mắt chủ xưởng vui vẻ vì có thể thu hồi vốn mua máy. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 050 | 00:06:28,491 → 00:06:38,360 | SRT 94–95

**Lời thoại:** Ở nơi lao động rẻ hơn, thời gian hoàn vốn có thể dài hơn. Đó cũng là lý do không thể đơn giản hỏi vì sao người Trung Quốc không dùng cỗ máy từ sách năm 1313 để làm điều người Anh làm sau này.

**Prompt:** So sánh hai nhà xưởng: nơi nhân công rẻ có nhiều người ngồi xe sợi thủ công và máy móc để không; nơi lương cao có chủ xưởng nhìn máy mới; ở giữa có một trang sách kỹ thuật Trung Quốc năm 1313, nhấn mạnh không được so hai máy như nhau. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 051 | 00:06:38,595 → 00:06:47,960 | SRT 96–98

**Lời thoại:** Những thiết bị ấy phục vụ loại sợi và quy trình khác, nên còn có rào cản kỹ thuật thực sự, bên cạnh rào cản kinh tế. Giờ nước Anh đã có nguồn năng lượng thuận lợi và động lực cơ giới hóa.

**Prompt:** Hai loại thiết bị xe sợi ở góc nhìn cận cảnh: máy xe sợi gai bằng bánh xe nước truyền thống bên trái và máy kéo sợi bông Jenny bên phải; các loại sợi được vẽ lớn để lộ khác biệt, giữa chúng là biểu tượng ổ khóa kỹ thuật và túi tiền. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 052 | 00:06:48,582 → 00:06:55,240 | SRT 99–100

**Lời thoại:** Nhưng nhà máy muốn phát triển còn cần nguyên liệu cùng người mua sản phẩm. Và mảnh ghép tiếp theo đưa chúng ta đến một phần tối tăm của lịch sử.

**Prompt:** Một nhà máy dệt Anh đang hoạt động có cỗ máy và ống khói, phía trước hai chiếc xe kéo: một xe chở nguyên liệu vào cổng, một xe mang cuộn vải đến khu chợ; bầu trời phía cuối tranh tối dần gợi mở phần lịch sử khó khăn sắp tới. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 053 | 00:06:55,465 → 00:07:01,720 | SRT 101–101

**Lời thoại:** Ngành dệt bông là một trong những lĩnh vực mở đường cho Cách mạng Công nghiệp Anh, dù khí hậu nước này không thích hợp để trồng bông với quy mô thương mại.

**Prompt:** Xưởng dệt bông Anh thế kỷ 18 với máy quay sợi và công nhân chăm chỉ, qua cửa sổ là cảnh mưa lạnh không có cây bông; một thuyền nhập bông thô cập cảng phía xa nối vào xưởng bằng mũi tên. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 054 | 00:07:02,303 → 00:07:08,360 | SRT 102–103

**Lời thoại:** Những loại vải bông chất lượng cao từ Ấn Độ từng rất được ưa chuộng tại châu Âu. Các nhà sản xuất Anh phải cạnh tranh với hàng nhập khẩu;

**Prompt:** Một gian chợ ở châu Âu thế kỷ 18 bày những tấm vải bông Ấn Độ có hoa văn nhiều màu, người mua rất thích thú; thợ dệt Anh áo nâu ở gian bên cạnh nhìn cuộn vải ngoại nhập với vẻ lo lắng vì cạnh tranh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 055 | 00:07:08,711 → 00:07:18,680 | SRT 104–105

**Lời thoại:** chính quyền từng ban hành luật hạn chế một số loại vải bông nhập khẩu để bảo vệ lợi ích trong nước. Khi những cỗ máy kéo sợi và dệt vải được cải tiến, các xưởng Anh dần tăng sản lượng, giảm chi phí và mở rộng thị trường.

**Prompt:** Bên trái quan chức Anh thời thế kỷ 18 đóng dấu lên giấy luật không chữ, bên phải xưởng dệt nội địa cải tiến máy và sản xuất thêm nhiều cuộn vải; đường mũi tên từ chợ sang nhà xưởng thể hiện thị trường được bảo vệ và mở rộng sản xuất. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 056 | 00:07:18,938 → 00:07:27,160 | SRT 106–107

**Lời thoại:** Nhưng càng sản xuất nhiều, họ càng cần nhiều bông thô. Và một phần ngày càng lớn của nguồn bông ấy đến từ các đồn điền ở châu Mỹ, nơi những người bị bắt làm nô lệ phải lao động cưỡng bức.

**Prompt:** Một xưởng dệt đang tăng năng suất với hàng cuộn vải chất cao, chủ xưởng chỉ vào chiếc thuyền chở bông đang tới; phía xa là đồn điền bông châu Mỹ, những người lao động bị nô dịch đang hái bông dưới sự giám sát, vẽ tôn trọng nhân phẩm, không tạo hình bạo lực trực diện. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 057 | 00:07:27,796 → 00:07:33,080 | SRT 108–108

**Lời thoại:** Đường từ Caribe và những nguyên liệu khác từ các vùng đất xa xôi cũng góp phần nuôi dưỡng nền kinh tế thương mại Anh.

**Prompt:** Tuyến thương mại Đại Tây Dương dạng bản đồ minh họa mộc mạc: một tàu chở đường từ vùng Caribe, một tàu chở bông và gỗ từ các vùng bên kia biển hướng về Anh, nhà kho gỗ ở cảng đông đúc; đường đi là mũi tên mềm không ghi địa danh tiếng Anh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 058 | 00:07:33,729 → 00:07:42,760 | SRT 109–110

**Lời thoại:** Kenneth Pomeranz gọi phần đất đai ở nước ngoài gián tiếp phục vụ nền kinh tế Anh là những “mẫu đất ma”. Hãy thử tưởng tượng nước Anh phải tự trồng toàn bộ số bông và nguyên liệu họ nhập khẩu.

**Prompt:** Khái niệm “mẫu đất ma” bằng hình ảnh ẩn dụ: hình nước Anh nhỏ đặt trên nền giấy, phía sau xuất hiện bóng mờ một diện tích ruộng bông, rừng cây và mía lớn gấp nhiều lần; một học giả chỉ vào phần đất mờ và một chủ xưởng Anh nhận nguyên liệu, chữ duy nhất tùy chọn “ĐẤT Ở HẢI NGOẠI”. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 059 | 00:07:43,259 → 00:07:47,880 | SRT 111–111

**Lời thoại:** Nhưng nhờ thương mại toàn cầu và hệ thống thuộc địa, một phần áp lực về tài nguyên được chuyển ra bên ngoài.

**Prompt:** Các con tàu chở kiện bông, thùng đường và gỗ từ vùng xa cập cảng Anh, phía sau tường thành là nhà máy; người thợ đứng trên hai bờ ngăn cách bởi biển, cho thấy nền kinh tế dựa một phần vào tài nguyên nhập khẩu, không nhấn vào khai thác trong nước. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 060 | 00:07:48,114 → 00:07:54,440 | SRT 112–112

**Lời thoại:** Trung Quốc thế kỷ 18 phải đáp ứng phần lớn nhu cầu lương thực, vải vóc và chất đốt cho dân số khổng lồ bằng đất đai và mạng lưới sản xuất trong nước.

**Prompt:** Trung Quốc thế kỷ 18: đồng lúa, vùng trồng bông, đồi lấy củi và các thôn xóm đông dân nằm kề nhau, nhiều gia đình phải chia công việc canh tác và dệt vải; phong cảnh đầy hoạt động chứ không nghèo đói cực đoan. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 061 | 00:07:54,733 → 00:08:02,120 | SRT 113–114

**Lời thoại:** Khi dân số tăng, áp lực lên ruộng đất và tài nguyên cũng tăng. Nhưng đừng vội kết luận rằng thuộc địa hay chế độ nô lệ một mình đã tạo ra Cách mạng Công nghiệp.

**Prompt:** Đồi đất trồng trọt mở rộng cạnh thôn làng đông người, cánh rừng còn lại thu hẹp, người nông dân nhìn diện tích ruộng có hạn; phía góc ảnh là chiếc bàn tranh luận của hai học giả cho thấy đây không phải nguyên nhân duy nhất của công nghiệp hóa. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 062 | 00:08:02,352 → 00:08:11,080 | SRT 115–116

**Lời thoại:** Điều có thể nói chắc chắn hơn là công nghiệp Anh không phát triển tách biệt khỏi thế giới. Sự mở rộng của nó gắn với một mạng lưới toàn cầu, trong đó có những hình thức bóc lột vô cùng tàn nhẫn.

**Prompt:** Mạng lưới thương mại toàn cầu trên giấy kem gồm châu Âu, châu Mỹ, Ấn Độ và Caribe được thể hiện bằng hình tượng tàu hàng, đồn điền, thợ dệt và những dây nối; một khu vực phía sau là lao động cưỡng bức thể hiện nghiêm túc, không tô hồng chế độ nô lệ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 063 | 00:08:11,456 → 00:08:18,200 | SRT 117–118

**Lời thoại:** Dù vậy, các quốc gia châu Âu khác cũng có thuộc địa và mạng lưới thương mại. Hà Lan có nền kinh tế năng động cùng mức tiền công tương đối cao.

**Prompt:** Ba quốc gia thương mại châu Âu dạng ba quầy cảng trong một tranh so sánh: Anh có than và nhà xưởng, Hà Lan có thuyền buôn và người nhận tiền công, Tây Ban Nha có tàu thuộc địa; các nhân vật nhìn lẫn nhau, không tạo kết luận một yếu tố đủ quyết định. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 064 | 00:08:18,595 → 00:08:25,240 | SRT 119–120

**Lời thoại:** Tại sao bước ngoặt công nghiệp lại bắt đầu ở Anh? Một phần lời giải có thể nằm ở cách những người hiểu khoa học gặp gỡ những người biết chế tạo và kinh doanh.

**Prompt:** Hai nhân vật người que, một nhà khoa học mang dụng cụ kính thủy tinh và một người thợ cầm bánh răng, gặp một thương nhân cầm túi tiền, ba người ghép các mảnh phát minh trên bàn; phía ngoài cửa là quán cà phê London. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 065 | 00:08:25,714 → 00:08:33,560 | SRT 121–122

**Lời thoại:** Hãy tưởng tượng một quán cà phê ở London đầu thế kỷ 18. Người ta đọc báo, bàn chuyện tàu thuyền, chia sẻ tin tức và tranh luận về những ý tưởng mới.

**Prompt:** Quán cà phê London đầu thế kỷ 18, khách nam mặc áo vest dài và mũ kiểu cổ ngồi quanh bàn tròn đọc báo không chữ, xem mô hình tàu và tranh luận; một người giơ mô hình bánh răng nhỏ, khung cảnh đông vui nhưng rõ chủ thể. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 066 | 00:08:33,792 → 00:08:40,280 | SRT 123–123

**Lời thoại:** Từ năm 1660, Hiệp hội Hoàng gia tại Anh thúc đẩy việc quan sát, thí nghiệm, công bố và tranh luận về các khám phá khoa học.

**Prompt:** Hội trường nhỏ Hiệp hội Hoàng gia năm 1660, một nhà nghiên cứu đứng trình diễn thí nghiệm với bơm khí và chuông thủy tinh trước nhóm học giả ghi chép, phía sau giá sách và dụng cụ quan sát; nhấn vào thí nghiệm công khai và kiểm chứng. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 067 | 00:08:40,712 → 00:08:46,600 | SRT 124–124

**Lời thoại:** Rồi ở Birmingham, vào cuối thế kỷ 18, một nhóm được gọi là Hiệp hội Mặt trăng tạo ra những cuộc gặp giữa nhà khoa học,

**Prompt:** Một bữa tối của Hiệp hội Mặt trăng ở Birmingham, bàn gỗ tròn dưới cửa sổ có mặt trăng sáng, những nhân vật nhà khoa học, thợ máy, chủ xưởng và thợ gốm ngồi cùng nhau trao đổi bản vẽ; người lớn tuổi mặt tròn đơn giản mặc áo khoác lịch sử. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 068 | 00:08:46,855 → 00:08:54,600 | SRT 125–126

**Lời thoại:** kỹ sư và doanh nhân. Trong mạng lưới ấy có James Watt, Matthew Boulton, nhà sản xuất đồ gốm Josiah Wedgwood và nhà khoa học Joseph Priestley.

**Prompt:** Cận cảnh nhóm gồm James Watt với mô hình động cơ, Matthew Boulton với quyển sổ đầu tư, Wedgwood cầm bình gốm và Priestley có bình thí nghiệm, cùng ghép ý tưởng trên bàn; họ mang tạo hình người que, không cố tạo chân dung thật. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 069 | 00:08:54,755 → 00:09:03,640 | SRT 127–128

**Lời thoại:** Điều đáng chú ý là họ có cơ hội liên tục trao đổi. Nhà sử học Joel Mokyr nhấn mạnh kiểu kết nối giữa tri thức và kỹ thuật thực hành này như một phần của môi trường thuận lợi cho công nghiệp hóa.

**Prompt:** Sơ đồ các ý tưởng truyền tay: nhà khoa học vẽ bản mô tả thí nghiệm, thợ cơ khí cải tiến bánh răng, chủ xưởng dùng máy trong nhà máy; một học giả đứng bên ngoài quan sát và ghi chú, những đường nối cho thấy kiến thức thực hành tích lũy. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 070 | 00:09:04,280 → 00:09:11,160 | SRT 129–130

**Lời thoại:** Nhưng đây là một lời giải thích có ảnh hưởng, chứ không phải kết luận duy nhất được mọi sử gia chấp nhận. Trung Quốc cũng có những học giả và nghệ nhân xuất sắc.

**Prompt:** Hai nhà nghiên cứu từ châu Âu và Trung Quốc ngồi hai phía bàn, mỗi người có chồng sách và sáng chế riêng; ở giữa dấu hỏi cùng nhiều tuyến kiến thức không chắc chắn; bố cục cân bằng, tránh gợi ý người bên này thông minh hơn bên kia. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 071 | 00:09:11,392 → 00:09:19,320 | SRT 131–132

**Lời thoại:** Vấn đề nằm ở những con đường nghề nghiệp và cách kiến thức được khuyến khích phát triển. Trong nhiều thế kỷ, khoa cử là lựa chọn danh giá đối với những người muốn bước vào bộ máy quan lại.

**Prompt:** Một học trò Trung Quốc thời phong kiến áo xanh học kinh điển bên bàn, trước mặt là đường dẫn đến cổng khoa cử và mũ quan, phía bên kia thợ thủ công trong xưởng cơ khí; nhân vật đứng chọn con đường danh giá, không chê bai nghề thợ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 072 | 00:09:19,476 → 00:09:28,680 | SRT 133–134

**Lời thoại:** Nhưng chế tạo máy móc không phải trung tâm của hệ thống tuyển chọn ấy. Điều này có thể khiến nhiều người tài ưu tiên con đường quan trường, trong khi kiến thức thủ công thường được truyền qua xưởng nghề và quan hệ thầy trò.

**Prompt:** Hình đối chiếu hai môi trường truyền nghề: một thí sinh trong phòng thi viết trên giấy, bên cạnh người thợ già chỉ cho học việc chế tạo bánh xe gỗ; dòng người đi thi kéo dài, còn máy móc có ít người quan sát hơn, không quy chụp ai cản trở khoa học. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 073 | 00:09:29,131 → 00:09:36,040 | SRT 135–136

**Lời thoại:** Dù vậy, không thể nói Trung Quốc thiếu sách kỹ thuật hay thiếu các nhà nghiên cứu sáng tạo. Thẩm Quát và Tống Ứng Tinh là những ví dụ nổi bật.

**Prompt:** Hai học giả Trung Hoa Thẩm Quát và Tống Ứng Tinh được thể hiện như nhân vật áo dài quan sát la bàn, hóa thạch và dụng cụ sản xuất, trên bàn là sách có hình vẽ máy; quanh họ có thợ thủ công đang làm việc, khẳng định Trung Quốc vẫn có nghiên cứu kỹ thuật. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 074 | 00:09:36,274 → 00:09:43,400 | SRT 137–138

**Lời thoại:** Sự khác biệt đáng cân nhắc hơn là mức độ và cách thức kết nối giữa nghiên cứu tự nhiên, kỹ năng chế tạo, vốn đầu tư và hoạt động kinh doanh tại từng thời kỳ.

**Prompt:** Sơ đồ hình tròn với bốn nhân vật nghiên cứu tự nhiên, thợ chế tạo, chủ đầu tư và thương nhân, mỗi người cầm dụng cụ riêng, giữa vòng là một cỗ máy đang được lắp ráp; một số đường nối đậm nhạt tượng trưng mức độ kết nối khác nhau qua từng xã hội. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 075 | 00:09:43,847 → 00:09:50,200 | SRT 139–140

**Lời thoại:** Tuy nhiên, tri thức cũng cần có một môi trường chính trị và kinh tế cho phép nó được sử dụng. Hãy quay lại những chuyến hải trình của Trịnh Hòa.

**Prompt:** Một nhà phát minh đứng trước hai cánh cửa tượng trưng luật lệ và thị trường, xa phía sau là đoàn tàu buồm lớn của Trịnh Hòa đang chuẩn bị xuất phát; thể hiện tri thức muốn lan rộng còn cần điều kiện chính trị và kinh tế. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 076 | 00:09:50,478 → 00:09:56,280 | SRT 141–141

**Lời thoại:** Từ năm 1405 đến năm 1433, triều Minh tổ chức bảy chuyến đi lớn tới nhiều vùng quanh Ấn Độ Dương.

**Prompt:** Hạm đội nhiều thuyền buồm gỗ triều Minh trên Ấn Độ Dương giai đoạn 1405–1433, Trịnh Hòa áo xanh đứng trên boong xem bản đồ hàng hải không chữ, nắng vàng và sóng xanh nhẹ, tàu gỗ lớn nhưng không phóng đại vô căn cứ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 077 | 00:09:56,461 → 00:10:04,360 | SRT 142–143

**Lời thoại:** Sau đó, những hạm đội thám hiểm do triều đình tài trợ chấm dứt hoạt động. Nhưng thương nhân tư nhân vẫn đi biển và giao dịch, đôi khi bất chấp các lệnh hạn chế.

**Prompt:** Bến cảng Trung Quốc sau khi những chuyến thám hiểm nhà nước chấm dứt, một tàu lớn của triều đình neo lại nhưng thuyền buôn tư nhân nhỏ vẫn bốc dỡ hàng gốm và tơ lụa, người dân trao đổi sôi nổi; nêu rõ hoạt động thương mại không biến mất. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 078 | 00:10:04,593 → 00:10:13,560 | SRT 144–145

**Lời thoại:** Chính sách của triều đình có thể quyết định số phận những đoàn thám hiểm nhà nước, chứ không xóa sạch mọi hoạt động thương mại đường biển. Trong khi đó, châu Âu gồm nhiều vương quốc và thành bang cạnh tranh.

**Prompt:** Hình đôi so sánh: bên trái quan lại triều Minh cất cuộn bản đồ hải trình của triều đình vào tủ, thuyền buôn tư nhân vẫn đi trên biển; bên phải bản đồ châu Âu với nhiều vương quốc nhỏ cùng những biểu tượng vương miện cạnh nhau, không chữ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 079 | 00:10:14,209 → 00:10:20,920 | SRT 146–146

**Lời thoại:** Christopher Columbus từng tìm kiếm sự hậu thuẫn ở Bồ Đào Nha nhưng không thành, rồi cuối cùng được các nhà cai trị Tây Ban Nha chấp nhận.

**Prompt:** Christopher Columbus người que mặc áo nâu cầm bản đồ tuyến biển đứng trước vua Bồ Đào Nha đang lắc đầu; ở bên phải cùng cảnh, nhà cai trị Tây Ban Nha gật đầu đưa một con tàu mô hình; dùng biểu cảm rõ và bối cảnh lịch sử, không viết tên quốc gia bằng tiếng Anh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 080 | 00:10:21,154 → 00:10:29,880 | SRT 147–148

**Lời thoại:** Một ý tưởng bị từ chối ở nơi này có thể tìm đường sang nơi khác. Sự cạnh tranh ấy gây ra nhiều cuộc chiến tranh tàn khốc, nhưng cũng tạo áp lực để các nhà cai trị đầu tư vào tàu thuyền,

**Prompt:** Một nhà phát minh vác bản vẽ đi từ cửa lâu đài đóng sang cửa lâu đài mở trên bản đồ châu Âu; phía sau có thuyền chiến, xưởng đóng tàu và người nghiên cứu vũ khí, cho thấy cạnh tranh tạo cả sức ép lẫn cơ hội. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 081 | 00:10:30,125 → 00:10:37,320 | SRT 149–150

**Lời thoại:** vũ khí, tài chính và công nghệ. Còn tại Trung Quốc, việc điều hành một đế chế lớn khiến chính quyền phải quan tâm đặc biệt đến ổn định xã hội,

**Prompt:** Màn hình chia hai trường cảnh không đối đầu: bên trái các vương quốc châu Âu phát triển pháo, tàu và ngân khố; bên phải quan lại Trung Hoa theo dõi đồng lúa, kho thuế và biên giới dài; thể hiện hai bài toán quản trị khác nhau. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 082 | 00:10:37,565 → 00:10:46,520 | SRT 151–152

**Lời thoại:** thuế khóa, nông nghiệp và an ninh biên giới. Không thể từ đó kết luận triều đình luôn chống lại phát minh, nhưng những ưu tiên chính trị có thể khác với một quốc gia đang cạnh tranh quyết liệt để mở rộng thương mại.

**Prompt:** Một nhóm quan lại triều Thanh ngồi trước bản đồ đế chế rộng, bàn có bao lúa, sổ thuế và mô hình trạm gác biên giới, nét mặt suy nghĩ khi cân nhắc ổn định; ở góc một người thợ đem dụng cụ mới tới, không ai xua đuổi. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 083 | 00:10:46,752 → 00:10:55,080 | SRT 153–153

**Lời thoại:** Năm 1793, một phái bộ Anh do Lãnh chúa Macartney dẫn đầu đến triều đình Càn Long, mang theo những món quà kỹ thuật và đề nghị mở rộng quan hệ thương mại.

**Prompt:** Đại sảnh triều Thanh năm 1793: Hoàng đế Càn Long trong trang phục vàng ngồi trên ngai, phái bộ Macartney mặc áo khoác châu Âu trang trọng dâng kính thiên văn, đồng hồ và quả địa cầu; hai bên quan sát trong nghi lễ ngoại giao nghiêm túc. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 084 | 00:10:55,470 → 00:11:01,560 | SRT 154–155

**Lời thoại:** Cuộc gặp không đem lại kết quả phía Anh mong muốn. Sự kiện này thường được kể như chuyện một hoàng đế kiêu ngạo không nhận ra công nghệ phương Tây.

**Prompt:** Sau cuộc gặp, phái bộ Anh rời cung điện mang theo bản thảo đề nghị không được chấp thuận, quan lại nhà Thanh trao đổi chính sách; ở góc hiện mô hình đồng hồ châu Âu, không vẽ vua tức giận hay xem thường công nghệ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 085 | 00:11:02,188 → 00:11:10,200 | SRT 156–157

**Lời thoại:** Nhưng cách hiểu ấy quá đơn giản. Các nhà sử học chỉ ra rằng phản ứng của triều đình còn gắn với ngoại giao, an ninh và cách nhà Thanh nhìn nhận vị thế của mình.

**Prompt:** Một sử gia hiện đại lật trang sách để so sánh hai cách kể về buổi tiếp kiến Càn Long: một tranh đơn giản quá mức có biểu tượng dấu gạch chéo, một tranh có hình triều đình, lá chắn an ninh và cán cân ngoại giao; nhấn sự phức tạp lịch sử. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 086 | 00:11:10,574 → 00:11:17,960 | SRT 158–159

**Lời thoại:** Khác biệt không đơn giản là thái độ thích hay ghét công nghệ. Nó nằm ở những mục tiêu kinh tế, chính trị và những điều kiện tạo ra động lực thay đổi.

**Prompt:** Cán cân gồm thương mại, ổn định chính trị, tài nguyên và đổi mới khoa học nằm quanh hai triều đình; cả quan Anh và quan Thanh cùng nghiên cứu các mục tiêu khác nhau, tránh tạo khuôn mẫu thích công nghệ hoặc ghét công nghệ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 087 | 00:11:18,192 → 00:11:24,360 | SRT 160–160

**Lời thoại:** Và cũng chính vì nhiều điều kiện cùng tác động, không thể chỉ vào một nguyên nhân rồi nói rằng đó là câu trả lời cuối cùng cho Cách mạng Công nghiệp.

**Prompt:** Một bảng ghép hình bằng gỗ có nhiều mảnh riêng tượng trưng than, lao động, thương mại, tri thức, chính trị; một nhân vật người que cố chọn một mảnh duy nhất nhưng không hoàn thành, những người khác phải góp các mảnh còn lại. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 088 | 00:11:24,874 → 00:11:31,240 | SRT 161–162

**Lời thoại:** Hãy nhìn cách quá trình này diễn ra ở Anh. Than đá thuận lợi giúp một số động cơ bơm nước hoạt động với chi phí chấp nhận được.

**Prompt:** Động cơ Newcomen bơm nước phía trước, toa chở than ra khỏi mỏ ở phía sau, bao quanh có thợ vận hành và chủ mỏ tính chi phí; dòng chuyển động nước ra ngoài rõ ràng, không có máy phát điện hiện đại. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 089 | 00:11:31,397 → 00:11:37,240 | SRT 163–163

**Lời thoại:** Việc bơm nước góp phần mở rộng khả năng khai thác ở các mỏ sâu, trong lúc nhu cầu than từ thành phố và nhà xưởng không ngừng tăng.

**Prompt:** Mặt cắt mỏ sâu với nước được bơm lên theo ống gỗ, nhóm thợ tiếp tục khai thác than dưới lòng đất; phía trên hai xe chở than đi về thành phố đang cần nhiên liệu, sơ đồ tạo vòng tác động chứ không phải máy bơm là nguyên nhân duy nhất. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 090 | 00:11:37,755 → 00:11:44,840 | SRT 164–164

**Lời thoại:** Từ năm 1709, Abraham Darby sử dụng than cốc trong luyện gang tại Coalbrookdale, góp phần mở đường cho việc giảm phụ thuộc vào than củi.

**Prompt:** Abraham Darby đứng bên lò luyện gang Coalbrookdale năm 1709, thợ xúc những cục than cốc màu đen xốp vào lò, bên cạnh là khuôn đúc gang và dòng kim loại nóng chảy, một đống củi nhỏ ở xa biểu thị giảm lệ thuộc gỗ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 091 | 00:11:45,348 → 00:11:53,080 | SRT 165–166

**Lời thoại:** Sắt và gang trở nên quan trọng đối với quá trình chế tạo công cụ, động cơ và cơ sở hạ tầng. Những cải tiến trong ngành dệt tăng năng suất, tạo thêm hàng hóa và lợi nhuận.

**Prompt:** Một dây chuyền minh họa ba trạm: xưởng luyện gang tạo bánh xe kim loại, xưởng cơ khí lắp động cơ và xưởng dệt sử dụng máy, cuộn vải chất lên xe chở hàng; người thợ từ mỗi trạm chuyền vật liệu cho nhau. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 092 | 00:11:53,572 → 00:12:02,760 | SRT 167–168

**Lời thoại:** Thương mại, vốn đầu tư, kỹ năng và những phát minh mới dần hỗ trợ lẫn nhau. Nhưng khi những ngành sản xuất bắt đầu tạo ra nhu cầu cho nhau, lợi thế có thể được tích lũy qua thời gian.

**Prompt:** Vòng tròn tích lũy gồm xe than, thỏi sắt, máy dệt, túi tiền, bản thiết kế và nhà xưởng kết nối bằng mũi tên quanh một bánh răng lớn; bốn nhân vật thợ, chủ xưởng, nhà nghiên cứu và thương nhân phối hợp bên dưới. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 093 | 00:12:03,390 → 00:12:09,960 | SRT 169–169

**Lời thoại:** Năm 1830, tuyến đường sắt Liverpool và Manchester được khai trương, kết nối một thành phố cảng với một trung tâm công nghiệp.

**Prompt:** Tuyến đường sắt Liverpool–Manchester năm 1830, đầu máy hơi nước cổ kéo toa hàng và hành khách đi qua đồng quê Anh, một đầu gần cảng có thuyền buồm, đầu kia là khu nhà máy; đường ray hiện rõ, tàu đúng kiểu đầu thế kỷ 19. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 094 | 00:12:10,194 → 00:12:17,400 | SRT 170–171

**Lời thoại:** Đường sắt là kết quả của nhiều thập kỷ phát triển về động cơ, luyện kim và đầu tư; đồng thời nó mở ra nhu cầu mới về sắt, than và máy móc.

**Prompt:** Cận cảnh đầu máy và đường ray: thỏi sắt, bánh xe đầu máy, những khối than trên toa hàng cùng người thợ sửa chữa, mũi tên nối nhu cầu sắt – than – máy móc; nền phía sau là cảng và xưởng dệt. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 095 | 00:12:17,765 → 00:12:23,720 | SRT 172–173

**Lời thoại:** Đến giữa thế kỷ 19, Anh đã trở thành một cường quốc công nghiệp nổi bật. Và ưu thế sản xuất ấy không chỉ đem lại hàng hóa rẻ hơn.

**Prompt:** Toàn cảnh thành phố công nghiệp Anh giữa thế kỷ 19: nhiều xưởng gạch, các ống khói, tàu hỏa, thuyền hàng và người lao động, các kiện hàng dệt may đi tới chợ; không tô vẽ thành phố như thiên đường, vẫn có khói và đông đúc. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 096 | 00:12:24,127 → 00:12:33,000 | SRT 174–175

**Lời thoại:** Nó còn góp phần thay đổi tương quan sức mạnh quân sự giữa các quốc gia. Trong thế kỷ 19, Anh nhập khẩu lượng trà lớn từ Trung Quốc, trong khi hàng hóa Anh không được mua lại với quy mô tương xứng.

**Prompt:** Tranh chuyển cảnh công nghiệp và quân sự: bên trái bến cảng Anh đầy hàng xuất khẩu và thương nhân xem giá trà, bên phải con tàu quân sự chạy hơi nước hiện xa trên biển; một mũi tên chuyển từ ưu thế sản xuất sang sức mạnh quốc gia, không minh họa xung đột đã bắt đầu ở đoạn trà. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 097 | 00:12:33,463 → 00:12:38,600 | SRT 176–176

**Lời thoại:** Các mạng lưới thương mại gắn với lợi ích Anh gia tăng việc đưa thuốc phiện trồng tại Ấn Độ vào Trung Quốc trái với lệnh cấm.

**Prompt:** Thuyền chở những hòm hàng thuốc phiện từ Ấn Độ cập cảng Trung Quốc thế kỷ 19 trong ánh sáng trầm, vài người buôn giấu các hòm sau những kiện hàng thường, viên quan ở xa nghi ngờ; minh họa lịch sử buôn lậu, không ca ngợi chất gây nghiện. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 098 | 00:12:38,832 → 00:12:45,720 | SRT 177–177

**Lời thoại:** Năm 1839, quan chức Lâm Tắc Từ tịch thu, tiêu hủy lượng lớn thuốc phiện, và căng thẳng leo thang thành Chiến tranh Nha phiến lần thứ nhất.

**Prompt:** Năm 1839 tại cảng Trung Quốc, quan Lâm Tắc Từ áo quan xanh chỉ đạo công nhân tịch thu và tiêu hủy nhiều thùng thuốc phiện trong khu vực kiểm soát, đám đông quan sát, tàu ngoại quốc nằm xa ngoài cảng; không có bạo lực cường điệu. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 099 | 00:12:46,165 → 00:12:52,600 | SRT 178–178

**Lời thoại:** Trong cuộc chiến, quân Anh sử dụng những tàu chiến có ưu thế về vũ khí và công nghệ, trong đó có chiếc Nemesis thân sắt vận hành bằng hơi nước,

**Prompt:** Tàu chiến Nemesis thân sắt chạy hơi nước trên sông Trung Quốc thời Chiến tranh Nha phiến, bánh guồng hai bên tàu, ống khói tỏa hơi, pháo trên boong; thuyền gỗ Trung Quốc hiện ở phía xa để tạo sự khác biệt công nghệ, tránh phô diễn cảnh chết chóc. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 100 | 00:12:52,898 → 00:13:01,240 | SRT 179–180

**Lời thoại:** có thể di chuyển trên sông mà không phụ thuộc hoàn toàn vào gió. Chiến thắng của Anh không thể quy về một con tàu, nhưng sự chênh lệch về năng lực quân sự và công nghiệp đã bộc lộ rõ rệt.

**Prompt:** Tầm nhìn rộng trên sông trong Chiến tranh Nha phiến: nhiều loại tàu chiến và công sự trên bờ, con tàu hơi nước Nemesis là một phần của hạm đội Anh, sĩ quan quan sát bằng ống nhòm; thể hiện lợi thế quân sự tổng hợp chứ không có một chiếc tàu đơn độc quyết định cả chiến tranh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 101 | 00:13:01,681 → 00:13:07,800 | SRT 181–181

**Lời thoại:** Năm 1842, nhà Thanh phải ký Hiệp ước Nam Kinh, nhượng Hồng Kông, mở các cảng thương mại và trả bồi thường.

**Prompt:** Cảnh ký Hiệp ước Nam Kinh năm 1842 trên bàn đàm phán có đại diện triều Thanh và Anh, giấy hiệp ước được đặt giữa bàn, phía sau cửa sổ là cảng biển và đảo Hồng Kông; gương mặt nghiêm nghị, không tô vẽ một bên thành quái vật. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 102 | 00:13:08,036 → 00:13:17,720 | SRT 182–183

**Lời thoại:** Đây trở thành một cột mốc đau đớn trong chuỗi hiệp ước bất bình đẳng của lịch sử cận đại Trung Quốc. Theo chuỗi ước tính của Angus Maddison, Trung Quốc chiếm khoảng một phần ba GDP thế giới năm 1820,

**Prompt:** Một sử gia Trung Quốc nhìn chuỗi bức tranh buồn về cảng nhượng, hiệp ước và cánh cửa thương mại mở ép buộc, sau đó chuyển thành bàn nghiên cứu với biểu đồ GDP lịch sử; biểu cảm suy tư, không dùng hình ảnh bạo lực. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 103 | 00:13:17,972 → 00:13:24,600 | SRT 184–185

**Lời thoại:** nhưng đến năm 1950 chỉ còn khoảng 4 đến 5 phần trăm. Và tỷ trọng giảm không có nghĩa toàn bộ nền kinh tế Trung Quốc bị xóa sổ.

**Prompt:** Biểu đồ thông tin thân thiện trên tờ giấy kem: hai vòng tròn thể hiện tỷ trọng GDP thế giới của Trung Quốc khoảng năm 1820 và 1950, một vòng lớn khoảng một phần ba, vòng nhỏ khoảng 4–5 phần trăm; chèn nhãn tiếng Việt duy nhất “TỶ TRỌNG GDP THẾ GIỚI”, và năm bằng số nếu cần. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 104 | 00:13:24,832 → 00:13:31,160 | SRT 186–186

**Lời thoại:** Nó cho thấy các nước công nghiệp hóa ở nơi khác đã tăng trưởng nhanh hơn nhiều, làm thay đổi vị thế tương đối của Trung Quốc trong nền kinh tế thế giới.

**Prompt:** Hình ảnh so sánh thị trường thế giới ở hai thời điểm: nhiều nhà máy tại châu Âu và châu Mỹ tăng nhanh về quy mô, Trung Quốc vẫn có sản xuất và thương mại nhưng tỷ trọng tương đối nhỏ đi; dùng bánh biểu đồ và các công xưởng, không vẽ Trung Quốc bị xóa khỏi bản đồ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 105 | 00:13:31,556 → 00:13:39,880 | SRT 187–188

**Lời thoại:** Tuy nhiên, câu chuyện cũng không dừng ở thế kỷ 19. Trung Quốc hiện đại đã trải qua một quá trình công nghiệp hóa sâu rộng, trở thành mắt xích lớn trong những chuỗi cung ứng toàn cầu.

**Prompt:** Hai cảnh Trung Quốc nối bằng đường thời gian mềm: thành phố công nghiệp hiện đại với nhà máy điện tử, cảng container và xe chở hàng, phía xa vẫn có biểu tượng xưởng thủ công xưa; nhấn thay đổi công nghiệp qua các thế hệ. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 106 | 00:13:40,114 → 00:13:47,000 | SRT 189–189

**Lời thoại:** Riêng năm 2025, nước này sản xuất khoảng 961 triệu tấn thép thô, tương đương hơn một nửa sản lượng toàn thế giới.

**Prompt:** Nhà máy thép Trung Quốc hiện đại với lò luyện lớn, cần cẩu và cuộn thép sáng bạc; công nhân đội mũ bảo hộ màu vàng và xanh đứng quan sát, bên cạnh hình biểu đồ hơn nửa chiếc bánh tô một màu khác, nếu có chữ chỉ ghi “NĂM 2025” và “961 TRIỆU TẤN”. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 107 | 00:13:47,353 → 00:13:55,640 | SRT 190–191

**Lời thoại:** Hệ thống đường sắt cao tốc của Trung Quốc cũng phát triển thành mạng lưới lớn nhất toàn cầu. Nhưng điều đó đủ để nhắc chúng ta rằng thành tựu công nghiệp không phải đặc tính cố định của một dân tộc.

**Prompt:** Một đoàn tàu cao tốc Trung Quốc hiện đại lướt qua cầu cạn dài, phía xa là đô thị và những nhà máy; gần đường ray có cậu bé nhìn tấm ảnh nhỏ về thợ luyện sắt thời Tống, biểu tượng năng lực sáng tạo không bị giới hạn trong một thời đại. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 108 | 00:13:55,788 → 00:14:01,880 | SRT 192–192

**Lời thoại:** Các thợ luyện sắt thời Tống, Tất Thăng, Tô Tụng hay những nghệ nhân chế tạo máy móc trong lịch sử Trung Quốc không thiếu trí tuệ.

**Prompt:** Bốn nhân vật người que Trung Hoa từ các thời kỳ đứng cạnh nhau: thợ luyện sắt thời Tống với khuôn đúc, Tất Thăng cầm khay chữ rời, Tô Tụng bên mô hình bánh xe nước và thợ cơ khí đang đo bản vẽ; tất cả có vẻ tự tin và bình đẳng với biểu tượng phát minh. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 109 | 00:14:02,268 → 00:14:10,520 | SRT 193–194

**Lời thoại:** Chỉ là những phát minh của họ xuất hiện trong một thế giới có những giới hạn và động lực khác với nước Anh thế kỷ 18. Và cuối cùng, hãy quay trở lại hai hình ảnh ở đầu câu chuyện.

**Prompt:** Hai dòng thời gian song song: phát minh Trung Quốc cổ với bánh xe nước, in ấn và luyện sắt; công nghiệp Anh với máy hơi nước và nhà máy; các nút rẽ đường đi tạo khác biệt điều kiện và thời điểm, một người kể chuyện đứng giữa mời khán giả nhìn lại. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 110 | 00:14:10,754 → 00:14:15,640 | SRT 195–195

**Lời thoại:** Một bên là những lò luyện sắt thời Tống, biểu tượng của trình độ kỹ thuật đáng nể từ hơn một nghìn năm trước.

**Prompt:** Trở về miền Bắc Trung Quốc năm 1078: khung cảnh lò luyện sắt thời Tống rực sáng, thợ mặc áo xanh đổ kim loại vào khuôn, quan áo đỏ bên các thỏi sắt; góc thấp rộng, không khí thành tựu kỹ thuật nổi bật, đồng nhất với hình mở đầu. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 111 | 00:14:16,061 → 00:14:22,920 | SRT 196–196

**Lời thoại:** Bên kia là cỗ máy bơm nước cồng kềnh ở Anh năm 1712, tiêu tốn nhiên liệu nhưng giải quyết được vấn đề cấp bách của một chủ mỏ.

**Prompt:** Trở về nước Anh năm 1712: động cơ hơi nước Newcomen to thô, đòn bẩy gỗ dài, ống hơi và máy bơm dẫn nước khỏi mỏ than, một người chủ mỏ đứng nhẹ nhõm bên vũng nước đang rút; tông xám nâu tương phản cảnh lò sáng thời Tống. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 112 | 00:14:23,315 → 00:14:30,360 | SRT 197–198

**Lời thoại:** Một ý tưởng muốn lan rộng cần có người muốn sử dụng, có nguồn lực để cải tiến, có thị trường để tồn tại, và có những ý tưởng khác để kết hợp cùng.

**Prompt:** Một phát minh nhỏ bằng bánh răng đặt giữa bàn, bốn nhân vật đại diện người dùng, thợ cải tiến, nhà đầu tư và người bán hàng nối tay đưa nó dần thành máy lớn hơn; mũi tên đi từ ý tưởng tới xưởng hoạt động, bố cục thoáng và rất rõ câu chuyện. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 113 | 00:14:30,595 → 00:14:38,360 | SRT 199–200

**Lời thoại:** Nước Anh không sở hữu một phép màu duy nhất. Nhiều điều kiện về năng lượng, tiền công, thương mại, tri thức và chính trị đã gặp nhau trong một thời điểm đặc biệt,

**Prompt:** Trên bàn gỗ có năm mảnh ghép tượng trưng than đá, túi tiền công, thuyền thương mại, quyển sách tri thức và cung điện chính trị; những bàn tay nhân vật người que ghép lại thành hình một nhà máy, không để một mảnh nào tự đủ tạo thành cả nhà máy. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 114 | 00:14:38,684 → 00:14:46,440 | SRT 201–202

**Lời thoại:** rồi dần củng cố lẫn nhau. Trung Quốc không thua trong một cuộc đua vì thiếu trí tưởng tượng, và nước Anh cũng không chiến thắng đơn giản vì có những con người xuất chúng hơn.

**Prompt:** Hai nhóm nhân vật Trung Quốc và Anh mặc đúng trang phục lịch sử đứng hai bên cùng nhìn chiếc bánh răng chung, ánh mắt thông minh ngang nhau; các đường dẫn khác nhau quanh họ và chiếc bản đồ làm nổi bật hoàn cảnh chứ không phải trí tuệ dân tộc. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 115 | 00:14:46,999 → 00:14:53,480 | SRT 203–203

**Lời thoại:** Điều tạo nên khác biệt là khi một phát minh xuất hiện, xã hội quanh nó có đủ lý do và đủ khả năng để tiếp tục phát triển nó hay không.

**Prompt:** Một cây mầm bánh răng nhỏ được nhiều nhân vật chăm sóc bằng công cụ, sách, nguyên liệu và tiền đầu tư, cây lớn dần thành xưởng máy có các bánh răng nối nhau; ẩn dụ cho phát minh được nuôi dưỡng trong môi trường phù hợp. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.


### CẢNH 116 | 00:14:53,669 → 00:14:59,640 | SRT 204–204

**Lời thoại:** Bởi đôi khi, thứ thay đổi thế giới không phải phát minh xuất hiện đầu tiên, mà là phát minh được tạo điều kiện để không ngừng trở nên tốt hơn.

**Prompt:** Khung hình kết lớn, mở rộng từ bàn tay người thợ đang cầm một bánh răng bé đến chuỗi nhà máy, xe lửa và cảng biển trong hình xoáy ốc, các nhóm người que hợp tác bên dưới; cảm giác tích cực, suy ngẫm, không nêu quốc gia nào bẩm sinh hơn quốc gia nào. Phong cách vẽ tay 2D giống thumbnail mẫu: người que có đầu tròn màu trắng, mắt hai chấm đen và miệng nét nhỏ, tay chân nét mảnh; viền mực đen hơi nguệch ngoạc có chủ ý, nền giấy kem hơi sần, màu tô phẳng trầm ấm, không khí video giải thích lịch sử, không ảnh thật, không 3D, không anime. Bố cục ngang 16:9, chủ thể lớn rõ, tối đa 2–3 điểm nhìn quan trọng, chừa khoảng trống để dễ pan/zoom. Trang phục và đạo cụ đúng thời kỳ. Không logo, không watermark, không phụ đề, không ký tự ngẫu nhiên; nếu trong ảnh xuất hiện chữ, CHỈ cho phép tiếng Việt có dấu và các chữ số đã nêu, tuyệt đối không chữ tiếng Anh, không chữ Trung Quốc, không chữ giả.
