SFX from existing project synthesised library; original-fire/gravel/pour generated locally by seeded filtered noise. No external licensed audio. Voice supplied by user.
