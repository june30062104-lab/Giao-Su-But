# Cách mạng công nghiệp: Anh và Trung Quốc

Bản thử 26,8 giây, ba cảnh prompt đầu tiên (001–003), dựng thành bốn shot: lò luyện, cận than, sổ thuế và đối chiếu chứng cứ. 1920×1080, 30 FPS. Giữ voice gốc, không đổi tốc độ; cuối clip sau câu kết ở 26,520 giây.

Toàn bộ đầu vào được giữ trong inputs/. project/scenes-full.json chứa 116 cảnh; project/cues-full.json chứa 204 câu SRT. Tất cả timestamp cảnh đã đối chiếu với SRT được cung cấp. Chưa render toàn bộ gần 15 phút.

## Chạy

- Cài Node.js 22+, npm và dependencies: npm install.
- Preview: npm run studio.
- Kiểm tra: npm run check và npm run typecheck.
- Xuất: npm run render (thêm --browser-executable=/usr/bin/chromium khi có browser hệ thống).
- QA: npm run qa. Cần Python 3, ffmpeg và ffprobe.
- Tạo lại mix: python scripts/prepare.py (cần NumPy; bộ SFX đã kèm theo).

## Thiết kế

Nền lò luyện mới tạo bằng công cụ tạo ảnh, sau đó giản lược về vẽ tay/màu phẳng; nền không chứa nhân vật hay chữ. Nhân vật SVG đầu tròn trắng, tay chân mảnh, khăn/mũ và áo gợi thời Tống; đầu, mắt, tay, gầu, dòng kim loại và lửa được dựng riêng. Đây là minh họa giải thích, không phải phục dựng khảo cổ đã xác minh từng chi tiết.

Số liệu 100.000 tấn/năm giữ tính bất định theo lời đọc. Không coi việc đối chiếu timestamp là thẩm định độ chính xác lịch sử. Chữ hiển thị là tiếng Việt và chữ số. Giọng đọc do người dùng cung cấp. SFX tổng hợp, không dùng nhạc nền/TTS thay voice.

Các mốc giữa câu là lựa chọn dựng theo nội dung; chưa có word-level timing. Profile tạo hình kế thừa skill explainer-video-remotion v2 và điều chỉnh theo prompt người dùng.
