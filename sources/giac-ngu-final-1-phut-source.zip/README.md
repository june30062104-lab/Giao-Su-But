# Giấc ngủ — bản hoàn thiện một phút

62,4 giây · 1920×1080 · 30 FPS. Giữ voice người dùng, 18 shot, 32 mốc SFX.

Cài: npm install
Xem: npm run studio
Xuất: npm run render
Kiểm tra: npm run typecheck và npm run qa (cần ffmpeg, ffprobe, Python 3). Có thể thêm --browser-executable=/usr/bin/chromium khi xuất trên Linux có Chromium.

Timeline và shotlist trong project/. Mã nhân vật và bối cảnh SVG trong src/. Âm thanh đã trộn và font có trong public/. Miệng chuyển theo biên độ voice, chưa phải lip-sync theo âm vị.

Xem docs/final-minute-direction.md để biết bản tham chiếu đã xem và giới hạn thực tế.
