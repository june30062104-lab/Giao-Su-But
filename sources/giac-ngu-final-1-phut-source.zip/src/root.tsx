import React from 'react';
import {Composition} from 'remotion';
import {SleepFinalMinute} from './final-minute';
export const Root=()=> <Composition id="SleepFinalMinute" component={SleepFinalMinute} durationInFrames={1872} fps={30} width={1920} height={1080}/>;
