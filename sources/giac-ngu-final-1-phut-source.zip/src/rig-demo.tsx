import React from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,useVideoConfig,interpolate} from 'remotion';
import timeline from '../project/rig-demo-timeline.json';
const ink='#302b28',paper='#faf0da';
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
export const Stroke:React.FC<{d:string;fill?:string;width?:number}>=({d,fill='none',width=4})=><path d={d} fill={fill} stroke={ink} strokeWidth={width} strokeLinecap="round" strokeLinejoin="round"/>;
export function Person({x,t,presenter,level}:{x:number;t:number;presenter:boolean;level:number}){
 const phase=presenter?0:1.7,period=presenter?timeline.motion.presenterPeriod:timeline.motion.listenerPeriod;
 const sway=Math.sin(t*Math.PI*2/period+phase)*(presenter?1.35:1.9);
 const bob=Math.sin(t*Math.PI*2/period+phase)*1.4;
 const blink=[1.2,4.55,7.4,10.6].some(a=>Math.abs(t-a-(presenter?0:.48))<.085);
 const concerned=!presenter&&t>timeline.events.argument;
 const surprise=!presenter&&t>timeline.events.email&&t<timeline.events.cross;
 const headAngle=Math.sin(t*2.05+phase)*1.1+(!presenter&&t>5.9?-3:0);
 const gesture=presenter?Math.sin(t*2.8)*3+ (t>3.6&&t<6? -13:0):Math.sin(t*1.7+1)*2;
 const open=presenter&&level>.019;
 return <g transform={`translate(${x} 0)`}>
 <ellipse cx="0" cy="599" rx="83" ry="9" fill="#c9bba2" opacity=".3"/>
 <Stroke d="M-45 442 L-44 577 L-14 577 L-3 491 L12 577 L44 577 L39 440Z" fill={presenter?'#64635c':'#53616a'}/>
 <Stroke d="M-45 571 Q-66 576 -68 590 Q-48 598 -12 591 L-13 575Z" fill={presenter?'#8e7052':'#fffaf0'}/>
 <Stroke d="M12 575 L45 575 Q65 582 65 591 Q42 599 10 591Z" fill={presenter?'#8e7052':'#fffaf0'}/>
 {!presenter&&<Stroke d="M-55 585 L-28 585 M30 585 L49 585" width={2}/>}
 <g transform={`rotate(${sway} 0 465) translate(0 ${bob})`}>
 <Stroke d="M-20 290 L-20 318 L21 318 L20 287" fill="#fffaf0"/>
 <Stroke d={presenter?'M-26 311 L-61 330 L-55 445 Q0 457 55 445 L61 330 L26 311Z':'M-25 312 L-58 327 L-65 356 L-44 365 L-43 444 Q0 450 43 444 L43 365 L65 356 L57 328 L25 312Z'} fill={presenter?'#c2a166':'#81b5ca'}/>
 {presenter&&<><Stroke d="M-24 313 L-4 361 L23 313 M-4 361 L-4 446 M26 369 L44 369" width={2.5}/><circle cx="6" cy="393" r="2" fill={ink}/><circle cx="6" cy="423" r="2" fill={ink}/></>}
 <g transform={`rotate(${gesture} 49 342)`}>
 <Stroke d={presenter?'M49 333 Q70 354 68 378 L99 357 L111 370 Q75 409 57 397 Q43 383 41 354':'M52 360 L59 411 L66 433 Q65 446 56 443 L50 430 L40 367'} fill={presenter?'#f7eddb':'#fffaf0'}/>
 {presenter&&<><Stroke d="M98 358 L110 346 Q115 342 118 347 L111 358 Q128 350 128 355 L116 366 L109 370" fill="#fffaf0" width={3}/><Stroke d="M105 357 L112 361" width={2}/></>}
 </g>
 <g transform={`rotate(${Math.sin(t*1.6+phase)*2} -48 342)`}>
 <Stroke d={presenter?'M-49 332 Q-72 348 -68 392 L-36 393 L-34 376 L-48 374 L-38 351':'M-52 360 L-59 411 L-65 433 Q-66 446 -56 443 L-50 430 L-40 367'} fill="#fffaf0"/>
 {presenter&&<><Stroke d="M-61 366 L-11 358 L-4 416 L-54 423Z" fill="#d5bb8b" width={3}/><Stroke d="M-62 383 Q-37 373 -37 379 L-53 385 Q-34 379 -35 385 L-52 391 Q-35 386 -37 393 L-56 402 Q-65 398 -62 383" fill="#fffaf0" width={2.5}/></>}
 </g>
 <g transform={`rotate(${headAngle} 0 288)`}>
 <Stroke d="M-80 210 C-84 165 -55 134 -7 132 C42 129 80 157 81 207 C85 252 49 289 3 291 C-45 292 -78 259 -80 210Z" fill="#fffaf0"/>
 {presenter?<Stroke d="M-57 151 L-48 127 L-30 133 L-28 117 L-10 129 L1 111 L12 130 L29 123 L24 142 L44 139 L34 155 Q-5 141 -57 151Z" fill="#746356" width={3}/>:<Stroke d="M-52 147 Q-26 123 -7 132 L1 122 L14 134 L25 129 L31 143" width={3}/>}
 {presenter&&<><circle cx="-34" cy="207" r="29" fill="none" stroke={ink} strokeWidth="4"/><circle cx="34" cy="207" r="29" fill="none" stroke={ink} strokeWidth="4"/><Stroke d="M-5 204 Q0 201 5 204 M-64 203 L-79 199 M64 203 L81 198" width={3}/></>}
 {blink?<Stroke d="M-46 208 Q-34 219 -23 208 M23 208 Q34 219 45 208" width={3}/>:<><ellipse cx={-33+(presenter?3:-4)} cy="208" rx={surprise?5:presenter?8:4} ry={surprise?7:presenter?10:4} fill={ink}/><ellipse cx={33+(presenter?3:-4)} cy="208" rx={surprise?5:presenter?8:4} ry={surprise?7:presenter?10:4} fill={ink}/></>}
 {(concerned||surprise)&&<Stroke d={surprise?'M-44 188 Q-33 177 -21 187 M21 186 Q33 175 44 184':'M-46 188 L-23 193 M21 192 L43 185'} width={2.8}/>}
 {open?<ellipse cx="2" cy="251" rx={level>.065?13:9} ry={level>.065?17:6} fill={ink}/>:surprise?<ellipse cx="0" cy="253" rx="6" ry="9" fill={ink}/>:<Stroke d={concerned?'M-11 256 Q0 251 12 254':'M-12 248 Q0 261 12 248'} width={3}/>}
 </g></g></g>;
}
export function Label({text,x,y,start,t,width,color='#f6d76c'}:{text:string;x:number;y:number;start:number;t:number;width:number;color?:string}){
 const p=interpolate(t,[start,start+.28],[0,1],clamp);if(!p)return null;
 return <g transform={`translate(${x} ${y+8*(1-p)})`} opacity={p}><path d={`M${-width/2} 0 Q0 -6 ${width/2} -1`} stroke={color} strokeWidth="24" strokeLinecap="round" strokeDasharray={width} strokeDashoffset={width*(1-p)} fill="none"/><text textAnchor="middle" y="7" fontFamily="Patrick" fontSize="29" fill={ink} stroke="none">{text.slice(0,Math.ceil(text.length*p))}</text></g>;
}
export const RigMotionDemo:React.FC=()=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps,e=timeline.events;
 const level=timeline.voiceEnvelope[f]??0;
 return <AbsoluteFill style={{background:paper}}><style>{`@font-face{font-family:Patrick;src:url('${staticFile('fonts/PatrickHand-Regular.ttf')}')}`}</style>
 <Audio src={staticFile(timeline.audio)}/>
 <svg viewBox="0 0 1280 720" width="100%" height="100%">
 <defs><filter id="paper"><feTurbulence type="fractalNoise" baseFrequency=".7" numOctaves="3" seed="14"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="linear" slope=".045"/></feComponentTransfer><feBlend in="SourceGraphic" mode="multiply"/></filter></defs>
 <g filter="url(#paper)"><path d="M0 0H1280V720H0Z" fill={paper}/>
 <path d="M0 599 Q610 596 1280 601 V720H0Z" fill="#e4c9a3"/>
 <Stroke d="M0 599 Q610 596 1280 601 M0 610 Q610 607 1280 613" width={2.5}/>
 <Stroke d="M53 133 L204 130 L203 399 L55 403Z" fill="#dfcda8"/><Stroke d="M64 144 L194 142 L192 388 L66 392Z" fill="#aecbd0" width={2}/>
 <path d="M67 186 Q95 169 112 186 Q137 163 154 190 L193 190 V210H67Z" fill="#f6f5e9"/>
 <Stroke d="M127 145 L127 390 M66 270 L193 269" width={3}/>
 <Stroke d="M1101 218 L1205 222 L1203 353 L1101 350Z" fill="#c3a47c"/><Stroke d="M1111 230 L1194 231 L1193 341 L1112 340Z" fill="#ede6cc" width={2}/><path d="M1135 324 Q1175 284 1160 254 Q1130 273 1153 308 M1154 304 Q1185 302 1180 279" stroke="#8b9b74" strokeWidth="6" fill="none"/>
 <Stroke d="M1110 548 L1185 548 L1174 601 L1122 601Z" fill="#b77f5e" width={3}/><Stroke d="M1147 548 Q1141 494 1152 454 M1145 528 L1118 500 M1146 509 L1175 482" width={3}/><path d="M1150 490 Q1119 466 1129 447 Q1155 450 1150 490 M1147 526 Q1171 503 1183 510 Q1180 534 1147 538 M1148 513 Q1115 514 1114 490 Q1136 485 1148 513" fill="#8d9e76" stroke={ink} strokeWidth="2"/>
 <Stroke d="M12 645 L162 642 M204 680 L415 683 M890 646 L1010 644 M1070 691 L1230 688" width={1.4}/>
 <Person x={440} t={t} presenter level={level}/><Person x={830} t={t} presenter={false} level={0}/>
 <Label text="Trong đầu: một cuộc họp khẩn…" x={650} y={49} start={e.meeting} t={t} width={440}/>
 {t>e.knock&&t<2.4&&<g opacity={1-interpolate(t,[1.4,2.4],[0,1],clamp)}><Stroke d="M906 190 L922 175 M910 210 L932 208 M899 170 L905 151" width={3}/></g>}
 <Label text={t<e.lock?'Cuộc cãi vã năm ấy…':t<e.email?'Mình khóa cửa chưa?':'Email chưa dám gửi…'} x={840} y={100} start={t<e.lock?e.argument:t<e.email?e.lock:e.email} t={t} width={300} color="#c8ddac"/>
 {t>e.lock&&<text x="956" y="246" fontFamily="Patrick" fontSize="54" fill="#bd5c40" transform={`rotate(${Math.sin(t*3)*4} 956 246)`}>{t>e.cross?'!':'?'}</text>}
 {t>e.cross&&<path d="M693 150 L987 141" stroke="#b3523d" strokeWidth="3" strokeDasharray="300" strokeDashoffset={300*(1-interpolate(t,[e.cross,e.cross+.35],[0,1],clamp))}/>}
 </g></svg></AbsoluteFill>;
};
