import React from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,useVideoConfig,interpolate,Easing} from 'remotion';
import {Stroke as S,Label,Person} from './rig-demo';
import film from '../project/final-minute-timeline.json';
const ink='#302b28',cream='#faf0da';
const cl={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const k=(t:number,a:number,b:number,x=0,y=1)=>interpolate(t,[a,b],[x,y],{...cl,easing:Easing.inOut(Easing.quad)});
function Head({t,eyes='open',mood='calm',mouth=0}:{t:number;eyes?:'open'|'closed'|'tight';mood?:'calm'|'worry'|'surprise';mouth?:number}){
 const blink=eyes==='closed'||(eyes==='open'&&t%3.7<.11);
 return <><S d="M-65 -6 C-70 -47 -39 -75 -2 -75 C38 -77 68 -48 67 -9 C70 30 40 61 2 62 C-36 63 -67 35 -65 -6Z" fill="#fff9e9" width={3}/>
 <S d="M-53 -47 Q-57 -64 -38 -66 L-37 -80 Q-24 -80 -20 -69 Q-20 -91 -8 -83 L1 -72 L13 -87 Q23 -82 18 -70 Q42 -81 39 -67 L54 -64 L41 -48 Q26 -58 14 -54 Q-4 -66 -12 -52 Q-29 -63 -34 -49Z" fill="#6c594d" width={3}/>
 {eyes==='tight'?<S d="M-40 -15L-21 -6L-40 3 M40 -15L21 -6L40 3" width={3}/>:blink?<S d="M-42 -8Q-28 4 -15 -8 M15 -8Q28 4 42 -8" width={3}/>:<><ellipse cx="-27" cy="-9" rx={mood==='surprise'?6:4} ry={mood==='surprise'?9:5} fill={ink}/><ellipse cx="27" cy="-9" rx={mood==='surprise'?6:4} ry={mood==='surprise'?9:5} fill={ink}/></>}
 {mood==='worry'&&<S d="M-43 -30L-18 -23 M18 -23L43 -30" width={2.5}/>}{mood==='surprise'&&<S d="M-42 -31Q-27 -43 -15 -32 M15 -32Q27 -44 42 -31" width={2.5}/>}
 {mouth>.025?<ellipse cx="0" cy="29" rx={mouth>.065?11:7} ry={mouth>.065?14:5} fill={ink}/>:mood==='surprise'?<ellipse cx="0" cy="28" rx="6" ry="9" fill={ink}/>:<S d={mood==='worry'?'M-13 31Q0 21 14 30':'M-12 27Q0 37 12 27'} width={2.5}/>}
 </>;
}
function Plant({x,y,scale=1}:{x:number;y:number;scale?:number}){return <g transform={`translate(${x} ${y}) scale(${scale})`}><S d="M-36 0L-27 65H28L37 0Z" fill="#b78261" width={3}/><S d="M1 0Q-9 -81 5 -122 M-3 -32L-32 -67 M-3 -58L26 -91" width={3}/><S d="M-2 -73Q-37 -105 -20 -121Q11 -111 -2 -73 M-4 -30Q-43 -31 -45 -57Q-16 -64 -4 -30 M-4 -50Q23 -83 43 -68Q40 -45 -4 -50 M4 -101Q27 -132 38 -117Q34 -94 4 -101" fill="#8e9c73" width={2}/></g>}
function Clock({t,large=false,morning=false}:{t:number;large?:boolean;morning?:boolean}){return <g transform={`translate(${large?640:1005} ${large?362:421}) scale(${large?3.6:1})`}><S d="M-66 -38Q0 -43 67 -37L68 32Q0 39 -67 32Z" fill="#6e6b60" width={3}/><S d="M-57 -29H57V23H-57Z" fill="#343d3d" width={2}/><text textAnchor="middle" y="9" fontFamily="monospace" fontSize="30" fill="#e5dfac">{morning?'07':'23'}<tspan opacity={t%1<.65?1:.35}>:</tspan>{morning?'06':'53'}</text><S d="M-45 35V43 M44 35V43" width={5}/></g>}
function Bed({t,action=false,awake=false}:{t:number;action?:boolean;awake?:boolean}){
 const pull=action?k(t,25.9,26.9):0,turn=action?k(t,27.05,27.65):0;
 const breathe=Math.sin(t*1.75)*2.1;const hy=430-pull*37+breathe; const hx=520-pull*101;
 return <g><ellipse cx="560" cy="586" rx="410" ry="26" fill="#746d5b" opacity=".15"/>
 <S d="M190 468L192 607 M878 468L878 607" width={12}/><S d="M186 436L880 437L904 549L206 563Z" fill="#aa805b" width={4}/><S d="M203 543L903 530L903 568L205 581Z" fill="#b48c63" width={3}/><S d="M188 356L187 525 M884 404L885 548" width={14}/>
 <S d="M203 407Q276 360 381 397L425 461Q331 492 210 451Z" fill="#e7dbc0" width={3}/><S d="M218 413Q291 388 354 410" width={1.5}/>
 <g transform={`translate(${321+turn*5} ${410+breathe*.25}) rotate(${-12-turn*15})`}><Head t={t} eyes={awake?'open':action&&t>28.15?'tight':'closed'} mood={action?'worry':'calm'}/></g>
 <S d="M373 447Q405 414 447 433L520 460L407 493Z" fill="#81b5ca" width={3}/>
 <path d={`M${411-pull*12} ${466-pull*39+breathe} Q${hx-22} ${hy+20} ${hx-3} ${hy+13} Q${540-pull*10} ${393-pull*18+breathe} 678 438 Q796 437 892 482 L898 538 Q677 563 401 552Z`} fill="#91a28d" stroke={ink} strokeWidth="3" strokeLinejoin="round"/>
 <S d={`M${hx+6} ${hy+20}Q583 ${453-pull*8} 599 513 M${hx+33} ${hy+17}Q677 458 699 533 M783 478Q805 494 819 520`} width={2}/>
 <S d={`M407 445Q${481-pull*9} ${464-pull*37} ${hx-9} ${hy+5} L${hx+8} ${hy+20}Q${481-pull*4} ${490-pull*38} 411 466Z`} fill="#fff9e9" width={3}/>
 <g transform={`translate(${hx} ${hy}) rotate(${-pull*20})`}>{action?<><S d="M-15 2Q-23 -15 -12 -20L1 -21Q15 -19 18 -9L17 10Q8 21 -1 15L-8 8Z" fill="#fff9e9" width={3}/><S d="M-9 -13L-5 -1 M-1 -15L2 -2 M7 -13L10 -1" width={1.8}/></>:<><S d="M-17 3Q-8 -10 6 -6L27 4Q36 12 23 15L3 10Q-9 18 -17 3Z" fill="#fff9e9" width={3}/><S d="M9 0L24 7 M5 5L20 12" width={1.5}/></>}</g>
 </g>;
}
function Room({t,action=false,awake=false,day=false}:{t:number;action?:boolean;awake?:boolean;day?:boolean}){
 const dawn=day?k(t,43.2,46.4):0;
 return <g><path d="M0 0H1280V720H0Z" fill="#d9c9ab"/><path d="M0 0H187V516L0 648Z" fill="#c5b193"/><path d="M187 0H1280V516H187Z" fill="#ddcdb0"/><path d="M0 648L187 516H1280V720H0Z" fill="#bd9b74"/>
 <S d="M187 0V516L0 648 M187 516H1280 M191 528H1280 M187 516L332 720 M570 516L684 720 M923 516L1087 720" width={2}/><S d="M56 681L1200 680 M111 618L1280 618 M162 562H1280" width={1.2}/>
 <S d="M816 75L1111 76L1114 319L816 319Z" fill="#bb9d74" width={4}/><path d="M828 89H1098V306H828Z" fill="#344e6d"/>
 <g opacity={1-dawn}><circle cx="1047" cy="132" r="23" fill="#e9dfb3"/>{[0,1,2,3,4,5].map(i=><circle key={i} cx={851+i*39} cy={110+(i%3)*27} r="1.6" fill="#e5dfc5"/>)}</g>
 <path d="M828 89H1098V306H828Z" fill="#c0dbe0" opacity={dawn}/><path d="M828 274L852 259L879 264L879 237L900 237L900 267L940 261L960 271L980 247L1015 247L1015 268L1058 263L1098 279V306H828Z" fill="#758787"/>
 <g opacity={dawn}><path d="M849 136Q884 109 906 136Q929 118 951 141H849Z" fill="#fff9e4"/><circle cx="1043" cy="134" r="21" fill="#f0d782"/></g><S d="M963 89V306 M828 199H1098" width={4}/>
 <S d="M797 62H1129 M807 64Q787 190 806 332L855 325Q835 184 858 66 M1082 66Q1108 181 1080 326L1133 332Q1117 186 1122 64" fill="#9caa9c" width={3}/><S d="M824 89Q809 188 827 302 M1108 98Q1093 191 1109 301" width={1.5}/>
 <S d="M245 88L404 83L409 220L247 223Z" fill="#aa8963" width={3}/><S d="M255 99L394 96L396 210L258 212Z" fill="#e8dfc6" width={2}/><path d="M270 194L307 148L332 177L360 135L385 198Z" fill="#9ca187"/>
 <S d="M481 111H689L693 134H481Z M498 133V171 M677 133V171" fill="#ad8963" width={3}/><S d="M510 65L528 64L532 108L512 110Z M535 54L556 55L554 109L534 110Z M560 65L577 62L587 107L566 109Z" fill="#9caaa0" width={2}/><S d="M596 81H654V108H596Z" fill="#c7ad80" width={2}/>
 <S d="M935 470L1102 470L1114 555H937Z M944 555V614 M1104 555V612" fill="#ad8561" width={3}/><S d="M947 485H1098V527H947Z M1003 505L1042 505" width={2}/><Clock t={t} morning={day&&dawn>.65}/>
 <S d="M1171 472V352 M1146 472H1195" width={4}/><S d="M1148 280L1192 282L1219 355L1124 355Z" fill="#ddc78d" width={3}/><path d="M1125 358L1218 358L1280 508L1069 508Z" fill="#ead292" opacity=".12"/>
 <S d="M947 454L967 453L966 466L946 466Z" fill="#cabf9b" width={2}/><S d="M1080 420L1098 420L1095 465L1084 465Z" fill="#e0dbc2" width={2}/>
 <Bed t={t} action={action} awake={awake}/><Plant x={102} y={604} scale={1.25}/>
 <path d="M0 0H1280V720H0Z" fill="#17304f" opacity={.11*(1-dawn)}/>
 {day&&<path d="M1094 204L842 575L391 575L965 204Z" fill="#f9e5a3" opacity={dawn*.16}/>}
 </g>;
}
function Seated({x,t,index=0,worry=false,mouth=0}:{x:number;t:number;index?:number;worry?:boolean;mouth?:number}){
 const angle=Math.sin(t*2+index*1.9)*1.8;
 return <g transform={`translate(${x} 0)`}><S d="M-49 352L-59 518H59L49 352Z" fill={index===1?'#ba927b':index===2?'#a4ae87':'#81b5ca'} width={3}/><g transform={`translate(0 306) rotate(${angle})`}><Head t={t+index*.7} mood={worry?'worry':'calm'} mouth={mouth}/></g><g transform={`rotate(${Math.sin(t*2.4+index)*4} 39 391)`}><S d="M42 378Q78 404 84 443L57 450L36 404" fill="#fff9e9" width={3}/></g><S d="M-42 381L-75 447L-26 462" fill="#fff9e9" width={3}/></g>;
}
function Mind({t,level}:{t:number;level:number}){return <g><path d="M0 0H1280V720H0Z" fill={cream}/><path d="M154 602Q96 458 176 256Q208 118 439 108Q623 39 871 109Q1145 166 1124 425Q1145 573 1038 624Z" fill="#f1e4ca" stroke="#cabd9d" strokeWidth="2"/>

 <Label text="Cuộc họp khẩn" x={640} y={106} start={12.562} t={t} width={240}/>
 <Seated x={380} t={t} index={0} worry mouth={level}/><Seated x={645} t={t} index={1} worry mouth={t%1.1<.5?.08:0}/><Seated x={910} t={t} index={2} worry mouth={t%1.3>.6?.05:0}/>
 <S d="M232 480Q644 414 1052 481L1108 577Q652 665 176 577Z" fill="#c39d71" width={3}/><S d="M259 589V684 M1013 591V684" width={9}/><S d="M329 491L401 486L435 512L357 525Z M831 493L908 497L918 525L847 523Z" fill="#fff8e6" width={2}/>
 <g transform={`translate(638 ${515+Math.sin(t*2)*2})`}><S d="M-38 10Q-59 -9 -39 -25Q-39 -48 -15 -43Q0 -62 19 -43Q45 -48 44 -25Q68 -6 43 15Q27 36 7 24Q-19 40 -38 10Z" fill="#d2a58d" width={2.5}/><S d="M-26 -22Q-4 -16 -15 5 M6 -33Q22 -15 12 9 M29 -17Q43 -9 30 5" width={2}/></g>
 </g>}
function Argument({t,level}:{t:number;level:number}){return <g><path d="M0 0H1280V720H0Z" fill="#eee0c4"/><S d="M130 116H1148V569H130Z" fill="#e4d1af" width={2}/><S d="M130 569H1148 M160 584H1120" width={2}/><Label text="4 năm trước…" x={640} y={77} start={16.356} t={t} width={210}/>
 <g transform={`translate(420 370) rotate(${Math.sin(t*3)*2})`}><S d="M-52 50L-63 169H64L50 48Z" fill="#81b5ca" width={3}/><Head t={t} mood="worry" mouth={level}/><g transform={`rotate(${Math.sin(t*5)*8} 50 84)`}><S d="M44 66L102 98L159 49" width={15}/><path d="M44 66L102 98L159 49" fill="none" stroke="#fff9e9" strokeWidth="9" strokeLinecap="round" strokeLinejoin="round"/></g></g>
 <g transform={`translate(865 370) rotate(${Math.sin(t*2.7+2)*2})`}><S d="M-52 50L-63 169H64L50 48Z" fill="#ba927b" width={3}/><Head t={t+.8} mood="worry" mouth={t%1>.4?.075:0}/><S d="M-49 72L-111 101L-162 60" width={13}/><path d="M-49 72L-111 101L-162 60" fill="none" stroke="#fff9e9" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round"/></g>
 <S d="M597 256L625 232L643 261L674 236 M596 290H571 M689 290H714" width={3}/></g>}
function Lock({t}:{t:number}){const rot=Math.sin(k(t,18.8,20.6)*Math.PI*4)*16;return <g><path d="M0 0H1280V720H0Z" fill={cream}/><S d="M342 -15L912 -15L928 735L337 735Z" fill="#b9946d" width={4}/><S d="M374 34L875 36L885 686L374 684Z" width={2}/><S d="M411 70V641 M842 70V640" width={1.2}/><S d="M722 249L821 249L825 433L720 432Z" fill="#9a9c8c" width={3}/><circle cx="774" cy="304" r="25" fill="#c8c4a8" stroke={ink} strokeWidth="3"/>
 <g transform={`rotate(${rot} 774 304)`}><S d="M776 303L707 322L670 306L654 327L676 349L719 338" fill="#ddd4b3" width={3}/><circle cx="670" cy="329" r="15" fill="none" stroke={ink} strokeWidth="3"/></g><S d="M739 384Q776 360 822 385" width={8}/>
 <g transform={`translate(${Math.sin(t*6)*3} 0)`}><S d="M1280 498L866 444L785 406Q764 396 761 377Q770 369 783 382L814 390Q800 363 812 359L844 391Q840 359 854 362L876 400L904 415L1280 421Z" fill="#fff9e9" width={3}/></g>
<Label text="Mình khóa cửa chưa?" x={640} y={109} start={18.556} t={t} width={310}/><text x="968" y="272" fontFamily="Patrick" fontSize="77" fill="#ac6147" transform={`rotate(${Math.sin(t*4)*5} 968 272)`}>?</text></g>}
function Email({t}:{t:number}){const count=Math.floor(k(t,21.0,23.3)*80);return <g><path d="M0 0H1280V720H0Z" fill="#dfcfb1"/><S d="M0 558H1280V720H0Z" fill="#b58f65" width={3}/><S d="M291 159L963 158L982 512L274 512Z" fill="#777d74" width={4}/><S d="M311 181L943 181L959 490L296 490Z" fill="#fff9e9" width={3}/><S d="M274 512L982 512L1112 617L173 618Z" fill="#b4b6a5" width={4}/>
 <text x="349" y="226" fontFamily="Patrick" fontSize="29" fill={ink}>Thư mới</text><S d="M337 242H917 M337 293H917" width={1.5}/><text x="349" y="278" fontFamily="Patrick" fontSize="23" fill="#776f61">Về chuyện hôm nay…</text>
 {[0,1,2].map(i=><S key={i} d={`M346 ${330+i*39}H${346+Math.min(520,Math.max(0,count-i*27)*19)}`} width={2}/>)}
 <S d="M794 439H922V474H794Z" fill="#b8c9a3" width={2}/><text x="858" y="464" textAnchor="middle" fontFamily="Patrick" fontSize="24" fill={ink}>Gửi</text>
 {[0,1,2,3].map(i=><S key={i} d={`M${264-i*13} ${536+i*16}H${1006+i*17}`} width={1.5}/>)}
 <g transform={`translate(0 ${Math.sin(t*25)*2})`}><S d="M0 704L309 582Q357 543 413 558L471 584Q483 594 464 600L419 586L461 609Q464 620 444 616L396 599L425 621Q420 631 400 623L361 610L291 642L120 720" fill="#fff9e9" width={3}/><S d="M1280 704L1002 583Q948 544 901 558L847 584Q833 595 854 600L900 586L858 609Q853 621 874 616L925 599L894 621Q898 631 918 623L960 609L1014 641L1166 720" fill="#fff9e9" width={3}/></g>
 {t>23.7&&<><path d="M784 435L935 481 M931 431L787 484" stroke="#b7513c" strokeWidth="4" strokeDasharray="180" strokeDashoffset={180*(1-k(t,23.7,24.0))}/><Label text="…nhưng chẳng gửi" x={644} y={102} start={23.7} t={t} width={280} color="#edd3ae"/></>}
 </g>}
function Stage({t}:{t:number}){return <g><path d="M0 0H1280V720H0Z" fill="#413d37"/><path d="M125 85H1154V590H125Z" fill="#d8c5a0"/><path d="M0 579H1280V720H0Z" fill="#a9825c"/>
 <path d="M0 0H1280V85H0Z" fill="#936951" stroke={ink} strokeWidth="3"/><path d="M0 80H205Q175 303 236 550L0 587Z M1280 80H1075Q1104 300 1040 550L1280 587Z" fill="#9e7259" stroke={ink} strokeWidth="3"/>
 <S d="M45 89Q41 293 78 520 M105 89Q93 293 138 515 M1235 89Q1241 293 1203 520 M1175 89Q1187 293 1140 515" width={2}/>
 <g transform="translate(138 119) scale(.8)"><Bed t={t}/></g><Label text="Một người đã ngủ" x={640} y={128} start={31.5} t={t} width={300}/>
 <g opacity={k(t,33.2,33.6)} transform={`translate(949 ${645+Math.sin(t*1.8)*1.6})`}><S d="M-74 49L-84 143H81L72 49Z" fill="#81b5ca" width={3}/><Head t={t} mood="worry"/><S d="M-68 87L-102 132 M68 87L100 132" width={10}/></g>
 <g opacity={k(t,33.6,34)}><S d="M967 535Q1039 464 1099 442" width={2}/><text x="1100" y="421" textAnchor="middle" fontFamily="Patrick" fontSize="25" fill="#fff0cf">Khán giả:</text><text x="1100" y="450" textAnchor="middle" fontFamily="Patrick" fontSize="25" fill="#fff0cf">cũng là bạn</text></g></g>}
function Drift({t}:{t:number}){return <g><path d="M0 0H1280V720H0Z" fill={cream}/><g transform={`translate(640 528) rotate(${Math.sin(t*.8)*1.5})`}><S d="M-88 53Q0 34 89 54L128 192H-128Z" fill="#81b5ca" width={3}/><Head t={t} eyes="closed"/></g>
 {['Cuộc cãi vã…','Khóa cửa?','Email…'].map((txt,i)=>{const p=k(t,38.267+i*.65,40.7+i*.3);return <g key={txt} opacity={1-p} transform={`translate(${330+i*305+(i-1)*p*70} ${235-Math.sin(t+i)*9-p*90}) rotate(${(i-1)*p*12})`}><S d="M-128 -48Q-155 -77 -111 -97Q-77 -128 -33 -107Q24 -130 66 -105Q121 -113 139 -79Q151 -37 109 -27Q58 -9 13 -23Q-47 -7 -83 -28Q-123 -18 -128 -48Z" fill="#f1e4c7" width={2}/><text textAnchor="middle" y="-61" fontFamily="Patrick" fontSize="28" fill={ink}>{txt}</text></g>})}
 <S d="M611 356Q623 337 639 348 M655 347Q671 332 680 348" width={2}/></g>}
function ExplainerRoom(){return <g><path d="M0 0H1280V720H0Z" fill={cream}/><path d="M0 601H1280V720H0Z" fill="#dfc49d"/><S d="M0 601H1280 M0 613H1280 M24 662L181 660 M1025 671L1240 668" width={2}/><S d="M36 88L189 87L189 386L37 387Z" fill="#c6ad86" width={3}/><S d="M48 100H177V375H48Z" fill="#b3d0d3" width={2}/><path d="M49 151Q76 126 94 147Q123 120 144 150H176V170H49Z" fill="#fff9e9"/><S d="M112 101V374 M49 239H177" width={3}/><Plant x={1180} y={545} scale={.85}/><S d="M1091 170L1220 173L1218 335L1089 331Z" fill="#c6ad86" width={3}/><S d="M1102 183L1208 185L1206 322L1102 319Z" fill="#ede6cb" width={2}/><path d="M1154 305Q1123 256 1168 213Q1183 253 1154 273Q1188 249 1192 275Q1180 300 1154 305" fill="#94a47e"/></g>}
function Choices({t,id}:{t:number;id:string}){
 return <g><ExplainerRoom/>{id==='stand'?<g>
 <S d="M510 450H725V477H510Z M523 477V615 M709 477V615 M516 450V325 M720 450V325 M516 325H720" fill="#b5956a" width={5}/>
 <g transform={`translate(624 ${k(t,52.3,53.2,338,254)})`}><Head t={t}/><S d="M-50 54L-58 172H57L49 54Z" fill="#81b5ca" width={3}/><S d={`M-39 171L${-46-k(t,52.3,53.2,0,10)} ${k(t,52.3,53.2,218,343)} M37 171L${47+k(t,52.3,53.2,0,10)} ${k(t,52.3,53.2,218,343)}`} width={22}/><S d="M-51 78L-74 145 M50 77L75 145" width={12}/></g><Label text="Đứng dậy" x={640} y={99} start={51.9} t={t} width={180}/>
 </g>:id==='door'?<g><S d="M413 116H837V608H413Z" fill="#8c8d7d" width={4}/><path d={`M424 127L${k(t,54.6,55.6,826,610)} ${k(t,54.6,55.6,127,177)}V${k(t,54.6,55.6,600,557)}L424 599Z`} fill="#be9a70" stroke={ink} strokeWidth="3"/><circle cx={k(t,54.6,55.6,781,581)} cy="378" r="8" fill="#e9d7a3" stroke={ink} strokeWidth="2"/><Label text="Mở cửa" x={640} y={83} start={54.5} t={t} width={150}/></g>:<g><g transform={`translate(640 340) rotate(${k(t,56.1,57.3,0,-18)})`}><S d="M-84 -114L83 -114L66 128L-64 128Z" fill="#dfe5d5" width={4}/><path d="M-74 -40Q0 -20 75 -40L62 121H-61Z" fill="#a8cbd0" stroke="#627f85" strokeWidth="2"/><S d="M-62 -93L-48 -1" width={2}/><S d="M-1 141Q91 115 143 144L159 202L-26 225L-180 337L-244 267L-94 152Z" fill="#fff9e9" width={3}/><S d="M64 151L114 161 M57 171L119 179 M49 191L116 197" width={2}/></g><Label text="Uống một cốc nước" x={640} y={94} start={56.047} t={t} width={290}/></g>}
 </g>;
}
export const SleepFinalMinute:React.FC=()=>{
 const frame=useCurrentFrame(),{fps}=useVideoConfig(),t=frame/fps,level=film.voiceEnvelope[frame]??0;
 const shot=film.shots.find(s=>t>=s.start&&t<s.end)??film.shots[film.shots.length-1],id=shot.id;
 const wipe=['mind','stage','dialogue'].includes(id);
 return <AbsoluteFill style={{background:cream}}><style>{`@font-face{font-family:Patrick;src:url('${staticFile('fonts/PatrickHand-Regular.ttf')}')}`}</style><Audio src={staticFile(film.audio)}/>
 <svg width="100%" height="100%" viewBox="0 0 1280 720">
 <defs><clipPath id="sceneReveal"><circle cx="640" cy="360" r={wipe?k(t,shot.start,shot.start+.4,0,1500):1500}/></clipPath></defs>
 {wipe&&t<shot.start+.4&&(id==='dialogue'?<Choices t={57.8} id="water"/>:<Room t={t}/>)}
 <g clipPath="url(#sceneReveal)">
 {id==='clock'&&<><path d="M0 0H1280V720H0Z" fill="#55594f"/><path d="M0 533L1280 533V720H0Z" fill="#9b7c59"/><S d="M0 533H1280 M0 554H1280" width={3}/><g transform={`translate(${640*(1-k(t,0,3.8,1,1.035))} ${360*(1-k(t,0,3.8,1,1.035))}) scale(${k(t,0,3.8,1,1.035)})`}><Clock t={t} large/></g><Label text="23 giờ 53 phút" x={640} y={126} start={1.463} t={t} width={260}/></>}
 {id==='room'&&<><g transform={`translate(${-k(t,3.912,9.106,0,27)} ${-k(t,3.912,9.106,0,12)}) scale(${k(t,3.912,9.106,1,1.055)})`}><Room t={t}/></g>{t>7.1&&<><S d={`M448 ${375+Math.sin(t*1.75)*3}Q488 356 509 373`} width={2}/><Label text="Hơi thở chậm và đều" x={650} y={122} start={7.1} t={t} width={310} color="#cdd7ae"/></>}</>}
 {id==='observer'&&<><g transform="translate(130 50) scale(.91)"><Room t={t}/></g><path d="M0 0H174V720H0Z M0 0H1280V70H0Z M1241 0H1280V720H1241Z" fill="#78694f" stroke={ink} strokeWidth="4"/><g transform="translate(-30 188) scale(.79)"><Person x={307} t={t%12.6} presenter={false} level={0}/></g><Label text="Đã ngủ rồi?" x={406} y={206} start={9.106} t={t} width={200}/>{t>10.1&&<text x="629" y={334-Math.sin(t*1.5)*3} fontFamily="Patrick" fontSize="34" fill="#e5dab7">z z Z</text>}</>}
 {id==='mind'&&<Mind t={t} level={level}/>}{id==='argument'&&<Argument t={t} level={level}/>}{id==='lock'&&<Lock t={t}/>}{id==='email'&&<Email t={t}/>}
 {id==='blanket'&&<g transform="translate(-126 -127) scale(1.29)"><Room t={t} action/></g>}
 {id==='stage'&&<Stage t={t}/>}
 {id==='strange'&&<><g transform="translate(-100 -455) scale(2.2)"><Room t={t}/></g><Label text="Rồi chuyện lạ xảy ra…" x={640} y={115} start={36.506} t={t} width={330}/></>}
 {id==='drift'&&<Drift t={t}/>}
 {id==='dawn'&&<><Room t={t} day/><g opacity={1-k(t,41.431,43.2)}><Label text="Âm thanh lùi ra xa…" x={630} y={102} start={41.431} t={t} width={300} color="#d5d7b9"/></g></>}
 {id==='wake'&&<><Room t={t} day awake/><Label text="Ngủ thật rồi." x={638} y={108} start={47.755} t={t} width={210} color="#c9dca8"/></>}
 {id==='question'&&<><ExplainerRoom/><g transform="translate(190 0)"><Person x={440} t={t%12.6} presenter level={level}/></g><text x="882" y="301" fontFamily="Patrick" fontSize="112" fill="#b26043" transform={`rotate(${Math.sin(t*2.5)*4} 882 301)`}>?</text><Label text="Vì sao lại khó đến vậy?" x={640} y={88} start={49.547} t={t} width={340}/></>}
 {['stand','door','water'].includes(id)&&<Choices t={t} id={id}/>}
 {id==='dialogue'&&<><ExplainerRoom/><Person x={435} t={t%12.6} presenter level={level}/><Person x={845} t={(t-57.92)+7.9} presenter={false} level={0}/><Label text="Giả vờ ngủ → Ngủ thật?" x={757} y={85} start={57.92} t={t} width={340}/>{t>59.5&&<><S d="M880 124L912 108 M897 150L933 148" width={2}/><text x="996" y="226" fontFamily="Patrick" fontSize="54" fill="#b26043">?</text></>}</>}
 </g>
 <rect width="1280" height="720" fill="#181e23" opacity={Math.max(1-k(t,0,.2),k(t,62.12,62.4))}/>
 </svg></AbsoluteFill>;
};
