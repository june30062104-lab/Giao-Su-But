# Bản hoàn thiện một phút — giấc ngủ

## Tham chiếu thực sự truy cập được

`1016 (3).mp4`: 71,63356 giây, 854×480, 30 FPS. Đã xem lại toàn bộ qua contact sheet và các khung hình quanh 00:54. Tệp `source .mp4` mới nhất vượt giới hạn tải 32 MiB của công cụ, chưa được xem; không suy diễn nội dung khác biệt của tệp đó.

Quan sát hình ảnh: nét viền tối và hơi bất quy tắc; màu phẳng ấm, nền kem cho đoạn giải thích; nhân vật đầu lớn, mắt/miệng đơn giản; bối cảnh chiếm cả khung hình ở cảnh kể chuyện; có đổi góc/cận vật thể; chữ ngắn trên vệt highlight, ký hiệu/gạch đỏ theo ý. Cảnh 00:54 giữ bối cảnh, hai người nghiêng nhẹ lệch nhịp, thay miệng, chớp mắt và đổi biểu cảm. Không khẳng định đã nhận diện âm thanh từng SFX của tham chiếu.

## Quyết định dựng

- 62,4 giây đầu của voice người dùng, giữ nguyên tốc độ và SRT gốc; cuối clip sau câu kết thúc ở 62,04 giây.
- 18 shot theo ý nghĩa, không mặc định một câu một shot. Xem `project/final-minute-shotlist.csv`.
- Không dùng một người dẫn cố định cạnh bảng. Người dẫn chỉ xuất hiện ở phần hỏi cuối; phần kể dùng nhân vật minh họa trong không gian, vật thể hoặc ẩn dụ.
- Nhân vật/bối cảnh SVG do dự án vẽ; đầu, mắt, miệng, tay và chăn điều khiển riêng; không dùng khung hình cắt từ tham chiếu làm tài nguyên thành phẩm.
- Động tác kéo chăn dùng hình học liên tục của tay, điểm nắm và nếp chăn; không dùng nội suy quang học giữa hai tranh.
- 32 điểm SFX tổng hợp của dự án; âm lượng nhỏ dưới voice. Chuyển động miệng dựa biên độ voice, chưa phải lip-sync theo âm vị.
- Có cắt cảnh, iris reveal tại một số chuyển ý, camera tiến nhẹ, chuyển ánh sáng đêm–sáng; tránh lắc lư tất cả nhân vật ở mọi cảnh.

## Giới hạn

Đây là cách dựng mới theo ngôn ngữ thị giác đã quan sát; không phải bản sao tuyệt đối của từng nét vẽ hay chuyển động trong mẫu. Các điểm nội câu dựa theo nội dung voice/SRT và lựa chọn dựng, không phải timestamp lời nói từ mẫu.
