from pathlib import Path
import json,subprocess,sys
r=Path(__file__).resolve().parents[1];m=json.loads((r/'project/final-minute-timeline.json').read_text());duration=m['duration'];fps=m['profile']['fps']
assert m['shots'][0]['start']==0 and m['shots'][-1]['end']==duration
assert all(a['end']==b['start'] for a,b in zip(m['shots'],m['shots'][1:]))
assert len(m['voiceEnvelope'])==round(duration*fps)
assert all(0<=x['time']<duration and (r/'public'/x['src']).is_file() for x in m['soundEffects'])
assert (r/'public'/m['audio']).is_file()
print('Timeline: 18 continuous shots; 32 SFX; original voice; all assets exist.')
if len(sys.argv)>1:
 p=Path(sys.argv[1]);v=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]));video=next(s for s in v['streams'] if s['codec_type']=='video');audio=next(s for s in v['streams'] if s['codec_type']=='audio')
 assert (video['width'],video['height'])==(1920,1080)
 assert video['r_frame_rate']=='30/1' and video['codec_name']=='h264' and audio['codec_name']=='aac'
 assert int(video['nb_frames'])==1872
 assert abs(float(v['format']['duration'])-duration)<.06
 subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','/dev/null'],check=True)
 print('MP4 verified:',v['format']['duration'],'s;',video['nb_frames'],'frames; H264/AAC; 1080p30; full decode passed.')
