# Phân cảnh quyết định đi ngủ và thực sự ngủ

Voice gốc: 80,309–109,409 giây. Dài 29,1 giây, 1080p30.

Cài: npm install
Xem: npx remotion studio src/index.ts
Xuất: npx remotion render src/index.ts ScriptScene30 output.mp4

Timeline chứa 5 shot, các cue SRT cục bộ và 14 mốc SFX. Voice không thay tốc độ. Miệng điều khiển bằng biên độ, chưa phải âm vị.
