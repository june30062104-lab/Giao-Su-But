import React from 'react';
import {Composition} from 'remotion';
import {ScriptScene30} from './scene30';
export const Root=()=> <Composition id="ScriptScene30" component={ScriptScene30} durationInFrames={873} fps={30} width={1920} height={1080}/>;
