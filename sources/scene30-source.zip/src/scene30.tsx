import React from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,useVideoConfig,interpolate} from 'remotion';
import {Person,Label,Stroke} from './rig-demo';
import data from '../project/scene30-timeline.json';
const ink='#302b28',cream='#faf0da';
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
function Face({t,closed=false,worried=false}:{t:number;closed?:boolean;worried?:boolean}){
 const blink=closed||t%3.6<.12;
 return <><Stroke d="M-54 -13 C-58 -51 -31 -70 0 -69 C39 -70 59 -41 56 -8 C57 26 32 49 0 48 C-33 49 -57 24 -54 -13Z" fill="#fffaf0" width={3}/><Stroke d="M-39 -53 L-23 -76 L-12 -66 L2 -82 L13 -67 L30 -72 L28 -57 L43 -54" fill="#776453" width={3}/>{blink?<Stroke d="M-33 -9 Q-23 0 -13 -9 M12 -9 Q23 0 34 -9" width={3}/>:<><circle cx="-23" cy="-9" r="4" fill={ink}/><circle cx="23" cy="-9" r="4" fill={ink}/></>}{worried&&<Stroke d="M-34 -28 L-13 -23 M13 -23 L34 -28" width={2.5}/>}<Stroke d={worried?'M-10 23 Q0 16 12 23':'M-9 19 Q0 26 10 19'} width={2.5}/></>;
}
function Bedroom({t,restless=false}:{t:number;restless?:boolean}){
 const breath=Math.sin(t*2)*2;
 const turn=restless?Math.sin(t*3.2)*8:0;
 return <g>
 <path d="M535 125H1235V553H535Z" fill="#e9e1ce"/><path d="M535 501H1235V553H535Z" fill="#d4be9c"/>
 <Stroke d="M650 164 L808 163 L807 340 L651 341Z" fill="#8babc1" width={3}/><path d="M658 171H800V332H658Z" fill="#344e70"/><circle cx="768" cy="204" r="19" fill="#f6e9bb"/><Stroke d="M729 170V332 M658 254H800" width={3}/>
 <Stroke d="M580 455 L580 555 M1121 454 L1121 555" width={10}/><Stroke d="M576 445 Q841 429 1125 444 L1125 513 L576 513Z" fill="#b08a65"/>
 <Stroke d="M578 382 L579 481 M1126 397 L1126 481" width={12}/>
 <Stroke d="M588 412 Q626 370 702 389 L745 441 L589 452Z" fill="#f5e8cc" width={3}/>
 <g transform={`translate(673 ${408+breath/2}) rotate(${-17+turn})`}><Face t={t} closed worried={restless}/></g>
 <path d={`M723 ${416+breath} Q821 ${378+breath} 935 405 Q1043 416 1116 451 L1116 484 L708 484Z`} fill="#91a59a" stroke={ink} strokeWidth="3"/>
 <Stroke d={`M785 ${420+breath} Q836 ${411+breath} 873 426 M926 419 Q977 431 1004 464`} width={2}/>
 <g transform={`translate(${restless?turn*.5:0} ${breath})`}><Stroke d="M704 439 Q747 414 778 433 L795 449 Q763 460 724 453Z" fill="#fffaf0" width={3}/><Stroke d="M775 438 L787 444 M768 442 L780 448" width={2}/></g>
 <Stroke d="M1143 434H1223V496H1143Z M1151 496V543 M1214 496V543" fill="#c49b73" width={3}/>
 <Stroke d="M1183 429V371 M1162 429H1204" width={3}/><Stroke d="M1168 332H1198L1211 374H1155Z" fill="#d5bd85" width={3}/>
 {t<10.45&&<g transform={`translate(${interpolate(t,[9.738,10.45],[1044,1175],clamp)} ${interpolate(t,[9.738,10.45],[353,419],clamp)}) rotate(${interpolate(t,[9.738,10.45],[-20,85],clamp)})`}><Stroke d="M-15 -25H15V25H-15Z" fill="#527c92" width={3}/><path d="M-10 -19H10V15H-10Z" fill="#c8e2e4"/></g>}
 {t>=10.45&&<Stroke d="M1160 423L1193 424" width={6}/>}
 {restless&&<><Stroke d={`M594 ${355+turn*.2} L582 341 M604 345L601 328 M986 366L1002 353`} width={2}/></>}
 </g>;
}
function Meeting({t}:{t:number}){
 return <g><Stroke d="M580 154H1160V320H580Z" fill="#f4ead5" width={3}/><Stroke d="M610 185H980 M610 213H1050 M610 241H937" width={2}/>
 {[620,855,1090].map((x,i)=><g key={x} transform={`translate(${x} 405)`}><Stroke d="M-51 -4L-65 131H65L49 -4Z" fill={i===1?'#81b5ca':'#baac8b'} width={3}/><g transform={`translate(0 -25) rotate(${i===1?interpolate(t,[25.284,27.4,28.1,29.1],[0,9,24,28],clamp):Math.sin(t*1.4+i)*2})`}><Face t={t+i} closed={i===1&&t>26.7}/></g><Stroke d="M-49 33L-80 93L-36 104 M49 33L76 91L31 105" fill="#fffaf0" width={3}/></g>)}
 <Stroke d="M523 510L1186 510L1230 562H490Z" fill="#bf966c" width={3}/><Stroke d="M527 562V625 M1185 562V625" width={7}/>
 <Stroke d="M582 522L637 524L648 542L588 540Z M1020 525L1085 525L1095 543L1021 541Z" fill="#fff9eb" width={2}/>
 {t>27.4&&<text x="939" y={322-Math.sin(t*2)*3} fontFamily="Patrick" fontSize="28" fill="#657e91">z z Z</text>}
 </g>;
}
export const ScriptScene30:React.FC=()=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps,e=data.events;
 const shot=data.shots.find(s=>t>=s.start&&t<s.end)??data.shots[4];
 const label=shot.id==='compare'?'Quyết định đi ngủ ≠ Thực sự ngủ':shot.id==='prepare'?'Bạn có thể chuẩn bị…':shot.id==='button'?'…nhưng không thể ra lệnh ngủ':shot.id==='restless'?'Muốn ngủ, vẫn trằn trọc':'Không định ngủ, lại ngủ gật';
 return <AbsoluteFill style={{background:cream}}><style>{`@font-face{font-family:Patrick;src:url('${staticFile('fonts/PatrickHand-Regular.ttf')}')}`}</style><Audio src={staticFile(data.audio)}/>
 <svg viewBox="0 0 1280 720" width="100%" height="100%"><path d="M0 0H1280V720H0Z" fill={cream}/><path d="M0 611H1280V720H0Z" fill="#e7d0ad"/><Stroke d="M0 611H1280 M0 622H1280 M47 673L211 670 M1037 677L1213 674" width={2}/>
 <g transform="translate(-22 135) scale(.79)"><Person x={265} t={t%12.6} presenter level={data.voiceEnvelope[f]??0}/></g>
 <Label text={label} x={775} y={58} start={shot.start+.15} t={t} width={Math.min(690,label.length*16)} color={shot.id==='button'?'#eed08e':'#f6d76c'}/>
 {shot.id==='compare'&&<g>
 <Stroke d="M493 152L819 148L817 526L491 530Z" fill="#f7e6c2" width={2}/><Stroke d="M855 151L1181 155L1184 530L853 525Z" fill="#e5ead5" width={2}/>
 <Label text="Quyết định" x={655} y={196} start={.3} t={t} width={160}/><Label text="Chìm vào giấc ngủ" x={1019} y={196} start={e.decision} t={t} width={240} color="#c8ddac"/>
 <g transform="translate(655 322)"><Face t={t}/><Stroke d="M-42 53L-48 133H48L42 53Z" fill="#81b5ca" width={3}/><g transform={`rotate(${Math.sin(t*2)*7} 42 74)`}><Stroke d="M40 64L73 105L95 65" width={14}/><Stroke d="M40 64L73 105L95 65" width={9}/></g></g>
 {t>e.decision&&<g transform={`translate(1019 ${330+Math.sin(t*1.7)*2}) rotate(13)`}><Face t={t} closed/><Stroke d="M-42 54L-48 125H48L42 54Z" fill="#81b5ca" width={3}/></g>}
 {t>e.control&&<Label text="Trong tầm kiểm soát ✓" x={655} y={494} start={e.control} t={t} width={278} color="#bfd4a4"/>}
 </g>}
 {(shot.id==='prepare'||shot.id==='restless')&&<Bedroom t={t} restless={shot.id==='restless'}/>}
 {shot.id==='prepare'&&<><Label text={t<e.phone?'Tắt đèn':t<e.lie?'Cất điện thoại':'Nằm xuống · Nhắm mắt'} x={876} y={567} start={t<e.phone?e.lamp:t<e.lie?e.phone:e.lie} t={t} width={340} color="#c8ddac"/><rect x="532" y="125" width="704" height="428" fill="#273e65" opacity={interpolate(t,[e.lamp,e.lamp+.45],[0,.12],clamp)} pointerEvents="none"/></>}
 {shot.id==='button'&&<>
 <g transform="translate(173 33) scale(.88)"><Person x={900} t={t%12.6} presenter={false} level={0}/></g>
 <g opacity={interpolate(t,[e.button,e.button+.3],[0,1],clamp)}><Stroke d="M483 230Q460 179 516 165Q520 120 580 135Q640 102 682 141Q746 133 757 184Q805 218 758 252Q717 285 663 266Q603 299 555 274Q503 288 483 230Z" fill="#fff9ec" width={3}/><circle cx="805" cy="280" r="12" fill="#fff9ec" stroke={ink} strokeWidth="2"/><circle cx="840" cy="304" r="6" fill="#fff9ec" stroke={ink} strokeWidth="2"/>
 <g transform={`translate(622 ${interpolate(t,[e.press,e.press+.14,e.press+.34],[0,7,0],clamp)})`}><ellipse cy="228" rx="58" ry="18" fill="#9f6b54" stroke={ink} strokeWidth="3"/><path d="M-58 211V228Q0 253 58 228V211" fill="#c88164" stroke={ink} strokeWidth="3"/><ellipse cy="210" rx="58" ry="18" fill="#dc9673" stroke={ink} strokeWidth="3"/><text y="216" textAnchor="middle" fontFamily="Patrick" fontSize="24" fill={ink}>NGỦ</text></g>
 {t>e.cross&&<><path d="M552 173L694 258 M695 173L553 258" stroke="#b8513c" strokeWidth="6" strokeDasharray="180" strokeDashoffset={180*(1-interpolate(t,[e.cross,e.cross+.35],[0,1],clamp))}/><Label text="Không có nút ra lệnh ngủ" x={650} y={460} start={e.cross} t={t} width={320} color="#e9c2a8"/></>}
 </g></>}
 {shot.id==='meeting'&&<Meeting t={t}/>}
 </svg></AbsoluteFill>;
};
