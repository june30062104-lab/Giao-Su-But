# Cảnh thử hai nhân vật

Cài: npm install
Xem: npx remotion studio src/index.ts
Xuất: npx remotion render src/index.ts RigMotionDemo output.mp4

12,8 giây, 1080p, 30 fps. Voice gốc cắt từ 12,562–25,362 giây. Miệng điều khiển bằng RMS voice, không phải lip-sync theo âm vị. Nhân vật SVG gồm đầu, mắt, miệng, tay và thân độc lập. SFX tổng hợp từ bộ âm thanh của dự án; không lấy tài nguyên từ video mẫu.
