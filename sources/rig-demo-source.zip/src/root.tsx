import React from 'react';
import {Composition} from 'remotion';
import {RigMotionDemo} from './rig-demo';
export const Root=()=> <Composition id="RigMotionDemo" component={RigMotionDemo} durationInFrames={384} fps={30} width={1920} height={1080}/>;
