from pathlib import Path
import json,re,csv
p=Path(__file__).resolve().parents[1];sc=json.loads((p/'project/timeline.json').read_text())['scenes']
# Explicit editorial assignments, one entry for each supplied scene.
groups={
'01':'coast temple temple temple manuscript',
'02':'desk templeMechanism templeMechanism templeMechanism templeMechanism',
'03':'aeolipile aeolipile aeolipile compare timeline',
'04':'question network compare archive map',
'05':'city map succession port desk',
'06':'courtyard debate archive copy',
'07':'geometry shadows astronomy port',
'08':'mirror mirror pump clock copy',
'09':'desk astronomy timeline city',
'10':'geometry machines coin coin bird pump manuscript',
'11':'theatre theatre theatre theatre',
'12':'aeolipile aeolipile manuscript machines',
'13':'aeolipile aeolipile energy belt network compare',
'14':'machines assembly leak manuscript',
'15':'dive dive gears astronomy compare',
'16':'saw saw saw',
'17':'machines assembly compare question balances mill',
'18':'map barbegal mill store',
'19':'mine drainage reservoir crane pantheon network',
'20':'desk manuscript city balances',
'21':'network question compare field',
'22':'field field map accounting accounting choices',
'23':'mine drainage choices choices balances',
'24':'copy crane court workers manuscript network',
'25':'mill mill balances choices fuel',
'26':'fuel energy engine engine accounting fuel map',
'27':'cart cart mill map forge network',
'28':'mineCompare drainage engine network desk balances forge',
'29':'pump compare leak maintenance compare engine',
'30':'desk condenser condenser boring boring timeline forge',
'31':'forge forge casting boring network',
'32':'compare engine engine vacuum manuscript assembly network',
'33':'debate courtyard debate crane network',
'34':'port siege desk copy balances',
'35':'machines machines banquet balances',
'36':'copy copy archive copy courier map archive',
'37':'timeline maintenance network network',
'38':'accounting city entrepreneurs network',
'39':'field accounting manuscript contract',
'40':'workers accounting map pantheon',
'41':'choices choices choices choices choices workers',
'42':'network mill timeline archive courier',
'43':'archive port archive copy',
'44':'copy city machines clock steamWheel machines',
'45':'printing manuscript courier aeolipile steamWheel',
'46':'mercury vacuum papin savery',
'47':'engine engine engine engine engine compare compare',
'48':'temple templeMechanism temple templeMechanism machines',
'49':'network network maintenance network',
'50':'engine maintenance network question question closing'}
labels={
'01.05':'Tái hiện giả định','02.01':'Hero thành Alexandria','02.02':'Khí • nước • đối trọng','03.01':'Quả cầu hơi nước của Hero','03.04':'Quay được ≠ làm việc hữu ích','03.05':'Khoảng 1.600 năm','04.03':'Nguyên lý → cỗ máy hữu ích','05.01':'Alexandria • 331 TCN','05.03':'Ptolemy','06.01':'Mouseion','06.04':'Một câu chuyện được truyền lại','07.01':'Euclid','07.02':'Eratosthenes','07.04':'Hải đăng Pharos','08.01':'Ctesibius','08.03':'Van một chiều','09.02':'Nguyệt thực • 62 SCN','09.03':'Niên đại còn có điểm chưa chắc chắn','10.01':'Hình học và cơ khí','10.02':'Khí nén học','10.03':'Đồng xu → mở van → nước chảy','11.01':'Nhà hát tự động','11.04':'Kéo • dừng • đảo chiều','12.03':'Một thiết kế được ghi chép','13.02':'Mô-men xoắn nhỏ','13.03':'Nhiệt thất thoát','13.04':'Truyền động chưa đủ hiệu quả','14.02':'Có linh kiện ≠ có chu trình','15.01':'Antikythera • 1900','15.03':'Cơ khí Hy Lạp hóa','15.05':'Thủ công tinh xảo ≠ sản xuất đại trà','16.01':'Hierapolis • thế kỷ III','16.03':'Quay tròn → tịnh tiến','17.04':'Người xưa chưa có bản vẽ tương lai','18.02':'Barbegal • 16 bánh xe nước','18.04':'Quy mô sản lượng còn được nghiên cứu','19.02':'Riotinto','19.03':'Las Médulas','19.04':'Guồng người • ròng rọc • dây kéo','19.05':'Pantheon','20.01':'Vitruvius','21.01':'Năm nhóm điều kiện','22.01':'1. Lao động và tổ chức xã hội','22.05':'Nô lệ không phải lao động miễn phí','23.03':'Phương án hơi nước: giả định','24.01':'Suetonius kể lại','24.03':'Giai thoại về Vespasian','24.05':'Một giai thoại, chưa phải kết luận chung','25.03':'Hiệu quả tùy nơi và công việc','26.01':'2. Nhiên liệu','26.04':'Than tại ngay nơi cần bơm','26.07':'Nguồn nhiên liệu khác nhau theo vùng','27.04':'Britannia thời La Mã','28.04':'Bơm nước → khai thác → than','28.05':'Một tình huống giả định','28.07':'3. Chế tạo và kỹ thuật','29.05':'Áp suất thấp ≠ áp suất cao','30.01':'James Watt','30.02':'Bình ngưng riêng','30.04':'Wilkinson • 1774','30.06':'1712 trước 1774','31.01':'Rèn sắt trong lò cổ','31.02':'Rèn sắt và đúc gang','32.01':'Phản lực ≠ ngưng tụ','32.03':'Áp suất khí quyển đẩy piston','32.04':'Torricelli • von Guericke','33.01':'4. Môi trường tri thức','34.01':'Syracuse','34.02':'Minh họa theo truyền thống kể lại','34.03':'Archimedes','34.04':'Plutarch viết nhiều thế kỷ sau','35.04':'Thực dụng và trình diễn','36.02':'Sao chép có thể làm lệch bản vẽ','37.02':'Thử → sửa → thử lại','38.01':'5. Tiền bạc và đầu tư','38.03':'Boulton • Wedgwood • Arkwright','39.03':'Lex Claudia','40.03':'Dacia • thời Trajan','40.04':'Quảng trường Trajan','41.04':'Thiết bị mới, rủi ro chưa rõ','42.03':'476 • Tây La Mã biến đổi','42.04':'Tri thức tiếp tục ở phương Đông','43.01':'Một hình dung phổ biến cần xem lại','43.02':'48 TCN • biến cố Caesar','44.02':'Baghdad • thời Abbasid','44.03':'Anh em Banu Musa','44.04':'Al-Jazari','44.05':'Taqi al-Din','45.01':'Nhà in thời Phục Hưng','45.02':'Bản dịch Latin • 1575','45.05':'Giovanni Branca • 1629','46.01':'Torricelli','46.02':'Thí nghiệm von Guericke','46.03':'Denis Papin','46.04':'Thomas Savery • 1698','47.01':'Newcomen • 1712','47.03':'Ngưng tụ → giảm áp suất','47.04':'Dầm nâng cần bơm','47.06':'Công việc hữu ích tạo khác biệt','48.01':'Trở lại Alexandria','48.04':'Từ phép màu đến cơ chế','49.02':'Chu trình • gia công • nhiên liệu • người mua','50.03':'Các điều kiện cùng hội tụ','50.04':'Theo bạn, rào cản lớn nhất là gì?','50.05':'Chia sẻ góc nhìn của bạn','50.06':'Cùng khám phá lịch sử công nghệ'}
for i,s in enumerate(sc):
 ch,part=s['id'].split('.');kind=groups[ch].split()[int(part)-1];s.update(index=i,kind=kind,label=labels.get(s['id'],''),startFrame=round(s['startMs']*.03),endFrame=round(s['endMs']*.03),variant=int(part)-1,context='britain' if ch in ['30','37','38','45','46','47'] or s['id'] in ['03.04','26.03','26.04','26.05','28.03','29.05','29.06','50.01','50.02'] else 'ancient')
 s['durationFrames']=s['endFrame']-s['startFrame'];s['duration']=s['durationFrames']/30
 s['choreography']={'approachSeconds':min(2,s['duration']*.22),'workStartsAfterApproach':True,'principle':'Walking only toward a work surface, machine, listener or delivery target. Grounded step stance; arm contact with machine is explicit.'}
# Preserve approved opening; two scene descriptions lag the spoken event: 10.04 stays with coin valve, 10.05 reveals birds then vessel.
sc[-1]['endFrame']=64467;sc[-1]['durationFrames']=sc[-1]['endFrame']-sc[-1]['startFrame'];sc[-1]['duration']=sc[-1]['durationFrames']/30
(p/'project/full/scenes.json').write_text(json.dumps(sc,ensure_ascii=False,indent=2))
chap=[]
for s in sc:
 if not chap or chap[-1]['name']!=s['chapter']:chap.append({'name':s['chapter'],'startMs':s['startMs'],'endMs':s['endMs']})
 else:chap[-1]['endMs']=s['endMs']
(p/'project/full/chapters.json').write_text(json.dumps(chap,ensure_ascii=False,indent=2))
with (p/'project/full/shotlist.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['id','startFrame','endFrame','kind','label','illustration','action'])
 for s in sc:w.writerow([s[k] for k in ['id','startFrame','endFrame','kind','label','illustration','motion']])
assert len(sc)==255 and all(a['endFrame']==b['startFrame'] for a,b in zip(sc,sc[1:]));print(len(sc),'scenes',len(set(s['kind'] for s in sc)),'scene families',sc[-1]['endFrame'],'frames')
