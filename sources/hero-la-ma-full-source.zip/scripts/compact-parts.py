from pathlib import Path
import subprocess,concurrent.futures,json,time
p=Path(__file__).resolve().parents[1];out=p/'output/full';small=out/'download-parts';small.mkdir(exist_ok=True)
def count(f):
 try:return int(json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames','-of','json',str(f)],stderr=subprocess.DEVNULL))['streams'][0]['nb_frames'])
 except Exception:return -1
def render(i):
 src=out/f'part-{i:02d}.mp4';dest=small/src.name;expected=1011 if i==0 else min(4500,64467-(1011+(i-1)*4500));beg=time.time()
 while count(src)!=expected:time.sleep(1)
 if count(dest)!=expected:
  cmd=['ffmpeg','-hide_banner','-y','-i',str(src),'-an','-c:v','libx264','-crf','27','-preset','fast','-tune','animation','-threads','1','-pix_fmt','yuv420p','-video_track_timescale','15360',str(dest)]
  with (small/f'encode-{i:02d}.log').open('w') as log:subprocess.run(cmd,check=True,stdout=log,stderr=log)
 assert count(dest)==expected;print(json.dumps({'part':i,'bytes':dest.stat().st_size,'seconds':round(time.time()-beg,1)}),flush=True);return dest
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:parts=list(pool.map(render,range(16)))
listing=out/'download-concat.txt';listing.write_text(''.join("file '"+str(f)+"'\n" for f in parts))
cmd=['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-i',str(p/'public/audio/full-mix.wav'),'-i',str(out/'chapters.ffmeta'),'-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-c:v','copy','-c:a','aac','-b:a','80k','-t','2148.9','-movflags','+faststart',str(p/'output/hero-la-ma-full-download-1080p.mp4')]
subprocess.run(cmd,check=True);print('COMPACT_COMPLETE',flush=True)
