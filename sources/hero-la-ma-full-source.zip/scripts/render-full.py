from pathlib import Path
import subprocess,concurrent.futures,os,json,time,shutil
p=Path(__file__).resolve().parents[1];os.chdir(p);out=p/'output/full';env=os.environ.copy();env['FONTCONFIG_FILE']=str(out/'fonts.conf');out.mkdir(exist_ok=True)
# Render the same React SVG scene components as HeroFull with native SVG rasterization.
# Approved first 1011 frames are preserved from the Chromium-rendered demo.
def run(cmd,log):
 with log.open('w') as f:subprocess.run(cmd,check=True,env=env,stdout=f,stderr=f)
def count(dest):
 try:return int(json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames','-of','json',str(dest)]))['streams'][0]['nb_frames'])
 except Exception:return -1
opening=out/'part-00.mp4'
if count(opening)!=1011:run(['ffmpeg','-v','error','-y','-i',str(p/'public/demo-approved.mp4'),'-an','-c:v','copy','-video_track_timescale','15360',str(opening)],out/'opening.log')
ranges=[(i+1,start,min(64467,start+4500)) for i,start in enumerate(range(1011,64467,4500))]
def render(job):
 i,start,end=job;dest=out/f'part-{i:02d}.mp4';beg=time.time()
 if count(dest)==end-start:print('REUSE',i,flush=True);return dest
 frames=out/f'frames-{i:02d}'
 run(['node',str(out/'full-frames.cjs'),str(start),str(end-1),str(frames)],out/f'frames-{i:02d}.log')
 run(['ffmpeg','-hide_banner','-y','-framerate','30','-start_number',str(start),'-i',str(frames/'frame-%05d.svg'),'-frames:v',str(end-start),'-an','-c:v','libx264','-crf','22','-preset','fast','-tune','animation','-threads','1','-pix_fmt','yuv420p','-video_track_timescale','15360',str(dest)],out/f'encode-{i:02d}.log')
 assert count(dest)==end-start
 shutil.rmtree(frames)
 print(json.dumps({'part':i,'startFrame':start,'frames':end-start,'elapsedSeconds':round(time.time()-beg,1),'bytes':dest.stat().st_size}),flush=True);return dest
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:parts=list(pool.map(render,ranges))
listing=out/'concat.txt';listing.write_text(''.join("file '"+str(f)+"'\n" for f in [opening]+parts))
chap=json.loads((p/'project/full/chapters.json').read_text());meta=';FFMETADATA1\ntitle=Tại sao người La Mã không tạo ra cuộc cách mạng hơi nước?\n'
for i,c in enumerate(chap):meta+=f"[CHAPTER]\nTIMEBASE=1/1000\nSTART={c['startMs']}\nEND={c['endMs']}\ntitle={i+1:02d}. {c['name']}\n"
(out/'chapters.ffmeta').write_text(meta)
run(['ffmpeg','-hide_banner','-y','-f','concat','-safe','0','-i',str(listing),'-i',str(p/'public/audio/full-mix.wav'),'-i',str(out/'chapters.ffmeta'),'-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-c:v','copy','-c:a','aac','-b:a','96k','-t','2148.9','-movflags','+faststart',str(p/'output/hero-la-ma-full-1080p.mp4')],out/'mux.log')
print('MASTER_COMPLETE',str(p/'output/hero-la-ma-full-1080p.mp4'),flush=True)
