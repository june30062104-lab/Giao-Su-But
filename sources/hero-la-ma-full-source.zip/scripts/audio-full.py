from pathlib import Path
import numpy as np,subprocess,wave,json,shutil
p=Path(__file__).resolve().parents[1];sr=44100;duration=2148.9;n=round(duration*sr)
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p/'inputs/voice-complete.flac'),'-ac','1','-ar',str(sr),'-f','f32le','-']);voice=np.frombuffer(raw,'<f4');mix=np.zeros(n,np.float32);mix[:min(n,len(voice))]=voice[:n]*.9;del raw
base=p/'public/audio/sfx';fxdir=p/'public/audio/sfx';fxdir.mkdir(exist_ok=True)
for src in base.glob('*.wav'):
 if src.resolve()!=(fxdir/src.name).resolve():shutil.copy2(src,fxdir/src.name)
def load(path):
 with wave.open(str(path)) as w:
  a=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768;return a.reshape(-1,w.getnchannels()).mean(axis=1)
first=load(p/'public/audio/demo-mix.wav');mix[:len(first)]=first
cache={f.stem:load(f) for f in fxdir.glob('*.wav')};rng=np.random.default_rng(62);events=[]
pools={
'paper':['paper-note','industry-ink','pencil-cross','red-pencil'],
'machine':['industry-gears','industry-steam','soft-tap','industry-waterwheel'],
'water':['water','industry-mine-drips','industry-waterwheel'],
'work':['original-gravel-3.9','industry-ore','meeting-knock','original-gravel-9.8'],
'sea':['industry-ship-creak','water','dawn-birds'],
'concept':['paper-note','soft-tap','caption-snap','question-soft','question-up'],
'coins':['industry-coins','industry-stamp','soft-tap']}
paper=set('desk copy geometry astronomy manuscript archive courtyard debate map timeline courier printing'.split());machines=set('aeolipile compare engine maintenance condenser pump clock mirror coin bird banquet machines theatre gears saw belt leak boring steamWheel mercury vacuum papin savery templeMechanism'.split());water=set('mill barbegal mine drainage reservoir dive'.split());work=set('field workers store cart fuel crane siege pantheon forge casting'.split())
def place(time,name,gain):
 at=round(time*sr);a=cache[name];take=min(len(a),n-at)
 if at<0 or take<=0:return
 mix[at:at+take]+=a[:take]*gain;events.append({'time':round(time,3),'file':'audio/sfx/'+name+'.wav','gain':gain})
scenes=json.loads((p/'project/full/scenes.json').read_text())
for s in scenes[4:]:
 k=s['kind'];start=s['startFrame']/30;dur=s['duration'];idx=s['index'];group='paper' if k in paper else 'machine' if k in machines else 'water' if k in water else 'work' if k in work else 'sea' if k=='port' else 'coins' if k in ['accounting','choices','court','contract'] else 'concept';pool=pools[group]
 place(start+.2,pool[idx%len(pool)],.13)
 if dur>4.2:place(start+min(2,dur*.22)+.2,pool[(idx+1)%len(pool)],.1)
 if k in machines|water and dur>6:
  for off in np.arange(4.5,dur-1,3.3):place(start+float(off),pool[(idx+2)%len(pool)],.06)
 if k in work|{'courier','port','city','debate'} and dur>3:
  for off in [.48,1.02,1.56]:place(start+off,'steps',.075)
 if s['label'] and dur>8:place(start+dur*.6,'paper-note' if k in paper else 'soft-tap',.07)
 if k in water|{'engine','port','steamWheel','forge'}:
  at=round(start*sr);end=min(n,round((start+dur)*sr));count=end-at;noise=rng.normal(0,1,count).astype(np.float32);amb=np.convolve(noise,np.ones(17,dtype=np.float32)/17,mode='same')*.006;edge=min(sr//3,count//2);amb[:edge]*=np.linspace(0,1,edge);amb[-edge:]*=np.linspace(1,0,edge);mix[at:end]+=amb
mix[-round(sr*.18):]*=np.linspace(1,0,round(sr*.18));peak=float(np.max(np.abs(mix)));assert peak<.98,peak
with wave.open(str(p/'public/audio/full-mix.wav'),'wb') as w:w.setparams((1,2,sr,0,'NONE','not compressed'));w.writeframes((mix*32767).astype('<i2').tobytes())
manifest={'composition':'HeroFull','fps':30,'width':1920,'height':1080,'durationInFrames':64467,'duration':duration,'audio':'audio/full-mix.wav','voiceSpeed':1,'mixPeak':peak,'approvedOpeningSeconds':33.7,'events':events,'usedSfx':sorted(set(e['file'] for e in events)),'notes':['Original parts 1 then 2, no retiming. Original concatenation preserved.','Internal action cues editorial; SRT scene times supplied by user, not word alignment.','SFX original procedural library; no music or replacement voice.']}
(p/'project/full/timeline.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print('Full mix',duration,'seconds;',len(events),'placements;',len(manifest['usedSfx']),'sounds; peak',peak,flush=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'public/audio/full-mix.wav'),'-c:a','flac',str(p/'public/audio/full-mix.flac')],check=True)
