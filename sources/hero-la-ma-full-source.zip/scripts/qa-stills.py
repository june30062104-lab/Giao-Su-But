from pathlib import Path
import subprocess,os,concurrent.futures,json
from PIL import Image,ImageDraw
p=Path(__file__).resolve().parents[1];out=p/'output/full';(out/'qa-jpg').mkdir(exist_ok=True);(out/'font-cache').mkdir(exist_ok=True)
(out/'fonts.conf').write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>'+str(p/'public/fonts')+'</dir><cachedir>'+str(out/'font-cache')+'</cachedir><config></config></fontconfig>');env=os.environ.copy();env['FONTCONFIG_FILE']=str(out/'fonts.conf')
def render(f):
 dst=out/'qa-jpg'/(f.stem+'.jpg');subprocess.run(['ffmpeg','-v','error','-y','-i',str(f),'-vf','scale=480:270','-frames:v','1','-threads','1',str(dst)],check=True,env=env);return dst
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:files=list(pool.map(render,sorted((out/'qa-svg').glob('*.svg'))))
sc=json.loads((p/'project/full/scenes.json').read_text());selection=[];seen=set()
for s in sc[4:]:
 if s['kind'] not in seen:selection.append(s);seen.add(s['kind'])
for page in range((len(selection)+23)//24):
 chunk=selection[page*24:(page+1)*24];im=Image.new('RGB',(1920,6*296),'#f0e7ce');dr=ImageDraw.Draw(im)
 for i,s in enumerate(chunk):
  x=i%4*480;y=i//4*296;im.paste(Image.open(out/'qa-jpg'/(s['id']+'.jpg')),(x,y));dr.text((x+10,y+274),s['id']+' / '+s['kind'],fill='#27241f')
 im.save(out/f'contact-families-{page+1}.jpg',quality=88)
print('Rendered',len(files),'scene checks;',len(selection),'unique family checks')
