from pathlib import Path
import subprocess,json,time
p=Path(__file__).resolve().parents[1];out=p/'output/full';master=p/'output/hero-la-ma-full-1080p.mp4';limit=100*1024*1024
if master.stat().st_size<=limit:
 print('SINGLE_FILE_MASTER_FITS',master.stat().st_size,flush=True)
else:
 compact=p/'output/hero-la-ma-full-download-1080p.mp4'
 cmd=['ffmpeg','-hide_banner','-y','-i',str(master),'-map','0:v:0','-map','0:a:0','-map_metadata','0','-map_chapters','0','-c:v','libx264','-crf','27','-preset','fast','-tune','animation','-threads','4','-pix_fmt','yuv420p','-c:a','aac','-b:a','80k','-movflags','+faststart',str(compact)]
 if not compact.exists():
  with (out/'download-encode.log').open('w') as f:subprocess.run(cmd,check=True,stdout=f,stderr=f)
 print('COMPACT_COMPLETE',compact.stat().st_size,flush=True)
 if compact.stat().st_size>limit:
  # A strict storage cap; keep native-resolution high-quality parts regardless.
  capped=p/'output/hero-la-ma-full-capped-1080p.mp4'
  target=int((99*1024*1024*8/2148.9)-80000)
  for step in [1,2]:
   cmd=['ffmpeg','-v','error','-y','-i',str(master),'-map','0:v:0','-c:v','libx264','-b:v',str(target),'-preset','fast','-tune','animation','-threads','4','-pass',str(step),'-passlogfile',str(out/'cap-pass')]
   cmd+=['-an','-f','null','/dev/null'] if step==1 else ['-map','0:a:0','-c:a','aac','-b:a','80k','-map_metadata','0','-map_chapters','0','-movflags','+faststart',str(capped)]
   subprocess.run(cmd,check=True)
  compact=capped
 assert compact.stat().st_size<=limit
 # Preserve original encoded picture quality in two downloadable parts.
 parts=[out/f'part-{i:02d}.mp4' for i in range(16)];parts=[f for f in parts if f.exists()]
 for i,group in enumerate([parts[:8],parts[8:]],1):
  start=0 if i==1 else 1083.7;duration=1083.7 if i==1 else 1065.2;listing=out/f'hq-concat-{i}.txt';listing.write_text(''.join("file '"+str(f)+"'\n" for f in group));dest=p/f'output/hero-la-ma-HQ-part-{i}.mp4'
  cmd=['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-ss',str(start),'-i',str(p/'public/audio/full-mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','96k','-t',str(duration),'-movflags','+faststart',str(dest)]
  subprocess.run(cmd,check=True);assert dest.stat().st_size<=limit,(dest,dest.stat().st_size);print('HQ_COMPLETE',i,dest.stat().st_size,flush=True)
 (out/'download-manifest.json').write_text(json.dumps({'master':master.name,'download':compact.name,'masterBytes':master.stat().st_size,'downloadBytes':compact.stat().st_size,'hqSplitSeconds':1083.7,'reason':'GitHub limits individual files to 100 MiB. Full single-file version uses additional compression; HQ parts preserve original video bitstreams.'},indent=2))
 print('DELIVERY_READY',str(compact),flush=True)
