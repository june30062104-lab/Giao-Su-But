from pathlib import Path
import subprocess
p=Path(__file__).resolve().parents[1];wav=p/'public/audio/full-mix.wav';flac=wav.with_suffix('.flac')
if not wav.exists():subprocess.run(['ffmpeg','-v','error','-i',str(flac),str(wav)],check=True)
out=p/'output/full';out.mkdir(parents=True,exist_ok=True);(out/'fonts.conf').write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>'+str(p/'public/fonts')+'</dir><cachedir>'+str(out/'font-cache')+'</cachedir><config></config></fontconfig>')
print('Full audio ready.')
