from pathlib import Path
import json,zipfile,shutil
p=Path(__file__).resolve().parents[1];r=Path('/workspace/Giao-Su-But');folder=r/'videos/hero-la-ma';folder.mkdir(parents=True,exist_ok=True)
manifest=json.loads((p/'output/full/download-manifest.json').read_text());movie=p/'output'/manifest['download'];assert movie.exists()
shutil.copy2(movie,r/'videos/hero-la-ma-full-1080p.mp4')
for i in [1,2]:shutil.copy2(p/f'output/hero-la-ma-HQ-part-{i}.mp4',r/f'videos/hero-la-ma-HQ-part-{i}.mp4')
shutil.copy2(p/'inputs/captions-user.srt',r/'videos/hero-la-ma-full.srt')
for src,dst in [('project/full/qa-report.json','qa.json'),('project/full/timeline.json','timeline.json'),('project/full/scenes.json','scenes.json'),('project/full/shotlist.csv','shotlist.csv'),('project/storyboard-updated.md','storyboard.md'),('output/full/contact-chapters.jpg','contact-chapters.jpg'),('output/full/walk-action-check.jpg','walk-action.jpg'),('output/full/crane-action-check.jpg','crane-action.jpg'),('output/full/newcomen-action-check.jpg','newcomen-action.jpg'),('output/full/download-manifest.json','downloads.json')]:shutil.copy2(p/src,folder/dst)
chap=json.loads((p/'project/full/chapters.json').read_text());rows='\n'.join(f"| {i+1:02d} | {c['startMs']//60000:02d}:{c['startMs']//1000%60:02d} | {c['name']} |" for i,c in enumerate(chap));root='https://github.com/june30062104-lab/Giao-Su-But/raw/refs/heads/main/'
readme=f'''# Hero / La Mã — toàn bộ video

255 cảnh, 10 chương, 35:48.9, 1920×1080 / 30 fps. Dựng bằng Remotion: nhân vật và đạo cụ tách lớp, có di chuyển đến nơi làm việc, thao tác và vận chuyển. Đoạn mở đầu đã duyệt được giữ nguyên. Voice do người dùng cung cấp, nối phần 1 rồi phần 2, không thay tốc độ; SFX theo hành động, không nhạc nền.

## Tải video

- [Video đầy đủ — một file 1080p]({root}videos/hero-la-ma-full-1080p.mp4).
- Bản HQ giữ chất lượng hình gốc: [phần 1 — 00:00 đến 18:03.7]({root}videos/hero-la-ma-HQ-part-1.mp4), [phần 2 — 18:03.7 đến hết]({root}videos/hero-la-ma-HQ-part-2.mp4).
- [Phụ đề SRT toàn bộ]({root}videos/hero-la-ma-full.srt).
- [Mã nguồn và tài nguyên]({root}sources/hero-la-ma-full-source.zip).

Giới hạn 100 MiB/tệp của GitHub khiến bản liền mạch cần nén thêm (cùng độ phân giải và nội dung); hai phần HQ giữ nguyên luồng hình gốc. File source có audio mix lossless FLAC và script phục hồi WAV.

## Chương

| Chương | Bắt đầu | Nội dung |
|---|---|---|
{rows}

## Kiểm tra

Xem [QA](qa.json), [ảnh các chương](contact-chapters.jpg) và chuỗi hành động [đi lại](walk-action.jpg), [cần cẩu](crane-action.jpg), [Newcomen](newcomen-action.jpg). Timeline và lời đọc đối chiếu với CSV/SRT 255 cảnh. Các mốc hành động bên trong câu là lựa chọn biên tập, chưa phải căn từng từ hay lip-sync âm vị.

Composition `HeroFull` giữ mở đầu từ renderer Chromium; phần SVG còn lại dùng cùng React scene components, raster bằng FFmpeg/librsvg để xuất bản dài. Source cũng có lệnh render toàn bộ qua Remotion/Chromium. Chi tiết trong FULL-VIDEO.md của source.
''';(folder/'README.md').write_text(readme)
dest=p/'output/hero-la-ma-full-source.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for path in ['src','scripts','project/full','public/fonts','public/audio/sfx']:
  for f in (p/path).rglob('*'):
   if f.is_file():z.write(f,f.relative_to(p))
 for name in ['README.md','FULL-VIDEO.md','package.json','tsconfig.json','public/alexandria.png','public/demo-approved.mp4','public/audio/demo-mix.wav','public/audio/full-mix.flac','inputs/storyboard-original.md','inputs/prompts-original.txt','inputs/timing-user.csv','inputs/captions-user.srt','project/timeline.json','project/demo-audio.json','project/demo-timeline.json','project/storyboard-updated.md']:
  z.write(p/name,name)
shutil.copy2(dest,r/'sources/hero-la-ma-full-source.zip')
for f in [r/'sources/hero-la-ma-full-source.zip',r/'videos/hero-la-ma-full-1080p.mp4',r/'videos/hero-la-ma-HQ-part-1.mp4',r/'videos/hero-la-ma-HQ-part-2.mp4']:assert f.stat().st_size<100*1024*1024,(f,f.stat().st_size)
print('Deliverables packaged; every binary under 100 MiB.')
