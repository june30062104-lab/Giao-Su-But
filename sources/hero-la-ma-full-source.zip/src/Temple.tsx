import React from 'react';
import {useCurrentFrame,useVideoConfig} from 'remotion';
import {L,Shape,Column,Person,Flame,Smoke,ease,ink} from './art';
export const Temple=({mode='wide',offset=0}:{mode?:string;offset?:number})=>{const f=useCurrentFrame();const {fps}=useVideoConfig();return <TempleArt mode={mode} t={f/fps+offset}/>};
export const TempleArt=({mode='wide',t=0}:{mode?:string;t?:number})=>{const opening=ease(t,17,21.5);const fire=ease(t,14.2,14.65);const act=ease(t,12.1,14.2)*(1-ease(t,15,17));
 let camera='translate(0 0)';if(mode==='close')camera='translate(-140 -165) scale(1.5)';if(mode==='reaction')camera='translate(-820 -230) scale(1.5)';
 return <svg viewBox="0 0 1280 720" width="100%" height="100%" style={{background:'#c3b994'}}><g transform={camera}>
 <rect width="1280" height="720" fill="#c9c0a0"/>
 <Shape d="M0 0 L620 0 L580 534 L0 620Z" fill="#d5ccac"/><Shape d="M620 0 L1280 0 L1280 610 L580 534Z" fill="#b6af92"/>
 <Shape d="M0 620 L580 534 L1280 610 L1280 720 L0 720Z" fill="#b9a98a"/>
 <Shape d="M0 654 L580 556 L1280 639 L1280 720 L0 720Z" fill="#c7b798"/>
 {[620,670,735,830,1010].map((x,i)=><L key={x} d={`M580 551 L${x-450+i*90} 720`} stroke="#93866d" strokeWidth="1.6"/>)}
 <L d="M0 684 L1280 690 M40 630 L1180 635 M72 198 L545 201 M4 344 L567 346 M623 329 L1280 332 M647 83 L1280 90" stroke="#a59c80" strokeWidth="2"/>
 <L d="M243 202 L241 343 M389 0 L385 200 M81 345 L80 480 M414 347 L413 555 M1065 90 L1064 330" stroke="#a59c80" strokeWidth="2"/>
 <Shape d="M659 113 L1030 113 L1045 558 L655 558Z" fill="#776f58"/>
 <Shape d="M680 134 L1008 134 L1008 548 L680 548Z" fill="#393f32"/>
 <path d="M701 540 L801 449 L897 449 L988 540Z" fill="#8f9a7a" opacity={opening*.9}/><path d="M734 538 L818 475 L885 475 L958 538Z" fill="#b7c19a" opacity={opening}/>
 <g transform={`translate(682 138) scale(${1-opening*.86} 1)`}><Shape d="M0 0 L161 1 L161 408 L0 408Z" fill="#806847"/>{[18,53,88,123,153].map(x=><L key={x} d={`M${x} 5 L${x+2} 402`} stroke="#544831" strokeWidth="2"/>)}<Shape d="M1 73 L160 75 L160 91 L1 89Z" fill="#a5895b"/><Shape d="M1 321 L160 324 L160 339 L1 337Z" fill="#a5895b"/><circle cx="142" cy="230" r="9" fill="none" stroke="#cfb272" strokeWidth="4"/></g>
 <g transform={`translate(1006 138) scale(${-1+opening*.86} 1)`}><Shape d="M0 0 L161 1 L161 408 L0 408Z" fill="#907653"/>{[18,53,88,123,153].map(x=><L key={x} d={`M${x} 5 L${x+2} 402`} stroke="#5b4d35" strokeWidth="2"/>)}<Shape d="M1 73 L160 75 L160 91 L1 89Z" fill="#b1976c"/><Shape d="M1 321 L160 324 L160 339 L1 337Z" fill="#b1976c"/><circle cx="142" cy="230" r="9" fill="none" stroke="#cfb272" strokeWidth="4"/></g>
 <Shape d="M642 103 L1045 103 L1045 132 L642 132Z" fill="#ddd0ac"/><L d="M658 144 L656 547 M1032 141 L1036 550" strokeWidth="3"/>
 <Shape d="M632 556 L1055 556 L1074 579 L615 579Z" fill="#dbcdab"/>
 <Column x={598} y={578} h={514}/><Column x={1102} y={600} h={537}/>
 <Shape d="M580 64 L1146 64 L1146 91 L567 91Z" fill="#e4d8b6"/>
 <Shape d="M1185 226 Q1200 193 1218 226 L1218 365 L1185 365Z" fill="#77795f"/><L d="M1183 381 L1223 381"/>
 <Shape d="M95 176 L254 157 L254 295 L94 308Z" fill="#877d61"/><Shape d="M108 185 L241 169 L241 283 L108 294Z" fill="#d6ded0"/><L d="M177 181 L177 287 M110 234 L239 222" strokeWidth="5"/>
 <path d="M244 173 L456 453 L260 487 L111 292Z" fill="#eae0b9" opacity=".2"/>
 <Shape d="M86 584 Q85 562 96 543 L108 510 Q95 498 111 493 L153 493 Q167 499 153 510 L165 547 Q183 584 155 602 Q105 612 86 584Z" fill="#a67f58"/><L d="M103 533 Q120 543 156 531 M98 572 Q119 581 165 566" strokeWidth="1.8" opacity=".5"/>
 <Person x={300} y={635} s={1.38} t={t} priest action={act} robe="#a5926c"/>
 <Shape d="M371 516 L527 516 L542 536 L357 536Z" fill="#ddd0af"/><Shape d="M374 536 L527 536 L516 650 L386 650Z" fill="#c6b894"/><Shape d="M365 650 L539 650 L551 671 L355 671Z" fill="#ddcfac"/>
 <Shape d="M389 506 Q449 529 511 505 L499 488 L402 488Z" fill="#8c7957"/><L d="M405 491 L428 486 L447 496 L470 486 L492 493" stroke="#544b37" strokeWidth="4"/>
 <L d="M402 552 L401 630 M509 551 L504 630 M421 577 Q447 561 478 577 Q483 601 455 615 Q425 603 421 577Z" strokeWidth="2" opacity=".5"/>
 {fire>0&&<g transform={`translate(449 494) scale(${fire*.72})`}><Flame t={t}/></g>}
 <Smoke t={t} x={449} y={fire>0?433:485} opacity={.23}/>
 {mode!=='close'&&<Person x={939} y={659} s={1.14} t={t} robe="#7c9b99" surprise={ease(t,18.3,19.4)*(1-ease(t,30,33))} phase={1.7}/>}
 {mode!=='close'&&<Person x={1191} y={665} s={.9} t={t} robe="#b48b79" surprise={ease(t,19.1,20.1)*.8} phase={3.1}/>}
 {t>24.8&&t<28.4&&<g opacity={ease(t,24.8,25.1)*(1-ease(t,28,28.4))}><L d="M1000 372 Q1001 351 1018 352 Q1040 353 1033 369 Q1015 377 1018 390" strokeWidth="4"/><circle cx="1018" cy="402" r="3" fill={ink}/></g>}
 </g></svg>;
};
