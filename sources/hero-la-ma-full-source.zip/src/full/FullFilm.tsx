import React from 'react';
import {AbsoluteFill,Audio,OffthreadVideo,Sequence,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import scenes from '../../project/full/scenes.json';
import {Knowledge} from './Knowledge';
import {Work} from './Work';
import {Devices} from './Devices';
import {Txt} from './props';
import {ease} from '../art';
export const getScene=(f:number)=>{let lo=0,hi=scenes.length-1;while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(scenes[mid].startFrame<=f)lo=mid;else hi=mid-1}return scenes[lo]};
export function SceneVisual({s,t}:{s:any;t:number}){const node=Knowledge({s,t})??Work({s,t})??Devices({s,t});if(!node)throw new Error('Unimplemented scene '+s.id+' / '+s.kind);const close=['aeolipile','mirror','coin','gears','boring','pump','condenser'].includes(s.kind)&&s.duration>7&&t>s.duration*.6;return <g transform={close?'translate(-104 -44) scale(1.15)':undefined}>{node}</g>}
export function FullSvg({frame}:{frame:number}){const s=getScene(frame),t=(frame-s.startFrame)/30;return <svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1280 720"><rect width="1280" height="720" fill="#f0e7ce"/><SceneVisual s={s} t={t}/>{s.label&&<g opacity={ease(t,.1,.48)}><path d="M87 90 L1191 90" stroke="#f0e7ce" strokeWidth="66" opacity=".93" strokeLinecap="round"/><Txt x={640} y={101} text={s.label} size={s.label.length>49?26:31}/></g>}<rect width="1280" height="720" fill="#f0e7ce" opacity={ease(frame/30,2148.55,2148.9)}/></svg>}
export function FullFilm(){const frame=useCurrentFrame();const {fps}=useVideoConfig();return <AbsoluteFill style={{background:'#f0e7ce'}}><style>{`@font-face{font-family:Patrick;src:url('${staticFile('fonts/PatrickHand-Regular.ttf')}')}`}</style><Audio src={staticFile('audio/full-mix.wav')}/><Sequence name="Bản mở đầu đã duyệt" from={0} durationInFrames={1011} premountFor={fps}><OffthreadVideo src={staticFile('demo-approved.mp4')} muted/></Sequence>{frame>=1011&&<FullSvg frame={frame}/>}</AbsoluteFill>}
