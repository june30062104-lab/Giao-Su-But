import React from 'react';
import {L,Shape,ease,ink} from '../art';
import {Scroll,Wood,Coins} from './props';
export type Pose='idle'|'point'|'read'|'write'|'hammer'|'carry'|'think'|'pull'|'crank'|'offer'|'measure'|'pour';
type Props={x:number;y:number;t:number;s?:number;fromX?:number;walkFor?:number;delay?:number;face?:number;color?:string;pose?:Pose;tool?:string;headwear?:string;mood?:string;hand?:[number,number];phase?:number;leaveAt?:number;leaveTo?:number;gait?:boolean;seated?:boolean};
export function Actor({x:target,y,t,s=1,fromX=target,walkFor=1.7,delay=0,face=1,color='#a89168',pose='idle',tool='',headwear='',mood='calm',hand,phase=0,leaveAt=1e6,leaveTo=target,gait=false,seated=false}:Props){
 walkFor=Math.max(walkFor,Math.abs(target-fromX)/(160*s));
 const travel=ease(t,delay,delay+walkFor),exit=ease(t,leaveAt,leaveAt+2);const bodyX=fromX+(target-fromX)*travel+(leaveTo-target)*exit;
 const walking=gait||(t>delay&&t<delay+walkFor&&fromX!==target)||(t>leaveAt&&t<leaveAt+2&&leaveTo!==target);const active=pose==='carry'||pose==='read'?1:ease(t,delay+walkFor-.2,delay+walkFor+.35);const at=Math.max(0,t-delay-walkFor);const hz=Math.sin(at*3.5+phase);
 const xAt=(tt:number)=>fromX+(target-fromX)*ease(tt,delay,delay+walkFor)+(leaveTo-target)*ease(tt,leaveAt,leaveAt+2);
 const foot=(off:number)=>{const exiting=exit>0,origin=exiting?target:fromX,direction=(exiting?leaveTo-target:target-fromX)>=0?1:-1,stride=52*s,u=Math.abs(bodyX-origin)/stride+off,k=Math.floor(u),p=u-k,anchor=origin+direction*((k-off)*stride+17*s),next=anchor+direction*stride,wx=p<.58?anchor:anchor+(next-anchor)*ease(p,.58,1);return [(wx-bodyX)/(s*face),p<.58?0:-Math.sin((p-.58)/.42*Math.PI)*13]};
 const legs=seated?[[42,0],[64,0]]:walking?(gait?[[Math.sin(t*7)*17,-Math.max(0,Math.cos(t*7))*11],[-Math.sin(t*7)*17,-Math.max(0,-Math.cos(t*7))*11]]:[foot(0),foot(.5)]):[[-23,0],[23,0]];const bob=walking?Math.abs(Math.sin(t/ .68*Math.PI*2))*2:Math.sin(t*1.4+phase)*.4;
 const lhand:[number,number]=pose==='read'||pose==='write'?[-5,-95]:pose==='carry'?[-8,-95]:[-38,-71];
 let rh:[number,number]=[35,-70];
 if(pose==='point')rh=[40+active*51,-71-active*49+hz*2];if(pose==='think')rh=[34,-72-active*66];if(pose==='write')rh=[38+Math.sin(at*5)*8,-95+Math.sin(at*3)*3];if(pose==='read')rh=[48,-97];if(pose==='carry'||pose==='offer')rh=[55,-96-active*5];if(pose==='hammer')rh=[65,-100-Math.max(0,hz)*58*active];if(pose==='pull')rh=[73,-123+Math.sin(at*2.6)*23*active];if(pose==='crank')rh=[70+Math.cos(at*2.2)*18*active,-112+Math.sin(at*2.2)*18*active];if(pose==='measure')rh=[68,-108];if(pose==='pour')rh=[65,-113];
 if(hand&&active>.01){rh=[35+((hand[0]-bodyX)/(s*face)-35)*active,-70+((hand[1]-y)/s+70)*active]}
 const adx=rh[0]-25,ady=rh[1]+107,ad=Math.max(.001,Math.hypot(adx,ady)),alen=Math.max(29,ad*.59),ah=Math.sqrt(Math.max(0,alen*alen-ad*ad/4)),asign=ady<0?1:-1,ex=(25+rh[0])/2-asign*ady/ad*ah,ey=(-107+rh[1])/2+asign*adx/ad*ah;
 const nod=(pose==='read'||pose==='write'?4:pose==='think'?-4:0)+Math.sin(t*1.35+phase)*1.2;const blink=(t+phase)%3.73<.12;const look=pose==='read'||pose==='write'?3:0;
 return <g transform={`translate(${bodyX} ${y}) scale(${s*face} ${s})`}>
 <ellipse cy="6" rx="43" ry="6" fill="#77775e" opacity=".13"/>{seated&&<><Shape d="M-38 -54 L35 -54 L42 -42 L-42 -42Z" fill="#a58a63" strokeWidth="2"/><L d="M-31 -40 L-37 4 M30 -42 L28 4" strokeWidth="7" stroke="#937853"/></>}
 {legs.map((a,i)=>{const hx=i?13:-13,fx=a[0],fy=a[1];const kneeX=seated?(i?63:46):(hx+fx)/2+(i?9:-9),kneeY=seated?-45:-23-Math.abs(fx-hx)*.05;return <g key={i}><L d={`M${hx} -46 Q${kneeX} ${kneeY} ${fx} ${fy-4}`} strokeWidth="4"/><Shape d={`M${fx-9} ${fy-3} Q${fx} ${fy-8} ${fx+9} ${fy} L${fx+10} ${fy+4} L${fx-10} ${fy+4}Z`} fill="#826748" strokeWidth="2"/></g>})}
 <g transform={`translate(0 ${-bob})`}>
 <Shape d="M-25 -123 Q-39 -96 -44 -43 Q-6 -33 40 -44 L28 -123 Q0 -137 -25 -123Z" fill={color} strokeWidth="2.7"/>
 <Shape d="M-22 -123 L-1 -94 L19 -124 L29 -111 L10 -81 L-9 -91Z" fill="#d9d0ad" strokeWidth="2.1"/><L d="M-32 -67 L-36 -46 M3 -69 L9 -46" strokeWidth="1.5" opacity=".6"/>
 <g transform={`rotate(${nod} 0 -161)`}><Shape d="M-35 -162 C-36 -187 -20 -205 1 -205 C25 -205 40 -187 37 -161 C36 -135 22 -123 0 -123 C-23 -123 -35 -139 -35 -162Z" fill="#fffdf6" strokeWidth="2.7"/>
 {headwear==='british'?<><Shape d="M-41 -187 L-30 -198 L-18 -193 Q0 -205 19 -194 L31 -199 L43 -185 Q0 -176 -41 -187Z" fill="#817966" strokeWidth="2.2"/></>:headwear==='turban'?<Shape d="M-37 -181 Q-45 -214 0 -216 Q42 -214 39 -181 Q8 -191 -37 -181Z" fill="#d9c9a3" strokeWidth="2.2"/>:headwear==='laurel'?<><L d="M-31 -181 Q1 -211 31 -183" stroke="#78835f" strokeWidth="6"/>{[-1,1].map(a=><L key={a} d={`M${a*27} -188 l${a*8} -9 M${a*13} -196 l${a*3} -10`} stroke="#78835f" strokeWidth="4"/>)}</>:headwear==='worker'?<Shape d="M-35 -183 Q0 -198 37 -184 L34 -196 Q-1 -208 -33 -196Z" fill="#9fac90" strokeWidth="2.2"/>:null}
 {blink?<L d={`M5 ${-156+look} L12 ${-155+look} M23 ${-156+look} L30 ${-155+look}`} strokeWidth="2.6"/>:<><ellipse cx="9" cy={-156+look} rx="2.8" ry={mood==='surprise'?5:3.5} fill={ink}/><ellipse cx="27" cy={-156+look} rx="2.8" ry={mood==='surprise'?5:3.5} fill={ink}/></>}
 {mood==='surprise'?<ellipse cx="19" cy="-138" rx="4" ry="6" fill={ink}/>:<L d={mood==='worry'?'M12 -137 Q19 -144 26 -137':'M12 -140 Q19 -133 26 -140'} strokeWidth="2"/>}{mood==='worry'&&<L d="M4 -171 L13 -168 M23 -168 L31 -171" strokeWidth="2"/>}</g>
 <L d={`M-27 -108 Q-47 -89 ${lhand[0]} ${lhand[1]}`} strokeWidth="4.2"/>
 <L d={`M25 -107 L${ex} ${ey} L${rh[0]} ${rh[1]}`} strokeWidth="4.2"/>
 {pose==='read'&&<Scroll x={23} y={-94} s={.5}/>} {pose==='write'&&<L d={`M${rh[0]} ${rh[1]} l17 -29 q-14 1 -13 19`} strokeWidth="2.5"/>}
 {tool==='scroll'&&<Scroll x={rh[0]-19} y={rh[1]+1} s={.4}/>} {tool==='wood'&&<Wood x={rh[0]-10} y={rh[1]+10} s={.38}/>} {tool==='stone'&&<Shape d={`M${rh[0]-48} ${rh[1]-15} l70 -4 l10 29 l-76 4Z`} fill="#aaa78d" strokeWidth="2"/>}{tool==='coin'&&<Coins x={rh[0]} y={rh[1]} n={2} s={.55}/>}
 {tool==='hammer'&&<g transform={`translate(${rh[0]} ${rh[1]}) rotate(${-10-Math.max(0,hz)*35})`}><L d="M0 0 L-8 -30" strokeWidth="5" stroke="#8e7252"/><Shape d="M-26 -43 L10 -49 L18 -30 L-21 -25Z" fill="#8b9383" strokeWidth="2"/></g>}
 {tool==='jug'&&<g transform={`translate(${rh[0]} ${rh[1]}) rotate(${pose==='pour'?ease(at,.5,2)*38:0})`}><Shape d="M-15 -11 L15 -11 L12 0 Q29 36 0 39 Q-29 36 -12 0Z" fill="#b28a63" strokeWidth="2"/><L d="M15 4 Q37 3 26 26 L16 24" strokeWidth="3"/></g>}
 {tool==='quill'&&<L d={`M${rh[0]} ${rh[1]} l14 -22 q-12 2 -11 16`} strokeWidth="2"/>}
 {[lhand,rh].map((a,i)=><ellipse key={i} cx={a[0]} cy={a[1]} rx="5.5" ry="4.2" fill="#fffdf6" stroke={ink} strokeWidth="1.8"/>)}
 </g></g>
}
