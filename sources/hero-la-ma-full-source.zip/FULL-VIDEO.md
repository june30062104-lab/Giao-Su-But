# Toàn bộ video Hero / La Mã

Composition `HeroFull`: 1920×1080, 30 fps, 64467 frames, 35:48.9. Toàn bộ 255 cảnh theo SRT/CSV người dùng cung cấp; 10 chương. Lời đọc gốc gồm phần 1 rồi phần 2, không thay tốc độ.

## Chạy lại

```sh
npm install
python scripts/restore-full-audio.py
npm run typecheck
npm run studio
npm run render:full
```

`render:full` là đường xuất Remotion/Chromium. Bản giao giữ 1011 frame mở đầu đã duyệt từ Remotion; các frame tiếp theo dùng cùng các React SVG component của `HeroFull`, raster bằng FFmpeg/librsvg để xuất bản dài nhanh hơn. Đã đối chiếu một frame máy bơm giữa Chromium và librsvg; khung hình, nét, font và vị trí trùng về bố cục, có thể khác khử răng cưa. `npm run render:native` chạy đường xuất này; cần FFmpeg có librsvg, fontconfig và esbuild. Không dùng ảnh tĩnh thay chuỗi diễn hoạt.

Audio trộn lossless ở `public/audio/full-mix.flac`; script phục hồi WAV trước khi chạy Remotion. Tệp gốc CSV, SRT, prompt và storyboard ở `inputs/`. MP3 gốc không gói lại trong bộ source chính để tránh lặp tài nguyên lớn; người dùng đã cung cấp hai tệp. Để tạo mix mới từ `scripts/audio-full.py`, cần đặt voice gốc nối đúng thứ tự ở `inputs/voice-complete.flac`. Mix đã dựng được gói đầy đủ và chạy lại không cần MP3 gốc.

## Dựng và chuyển động

- `src/full/Actor.tsx`: nhân vật đầu trắng, mặt/tay/chân riêng; đi đến vị trí làm việc, đọc/ghi/cầm/trao/kéo/quay tay. Chân giữ điểm đứng trong pha chống; bước tính theo quãng đường, giảm trượt. Nhân vật ngồi có ghế và chân gập. Tốc độ tiếp cận điều chỉnh theo quãng đường.
- `src/full/machines.tsx`: quả cầu Hero, bơm piston/van, dầm Newcomen, bình ngưng, cửa đền khí–nước–xô–đối trọng, cẩu guồng người, cưa nước, đồng hồ và máy nhận xu.
- `Knowledge.tsx`, `Work.tsx`, `Devices.tsx`: các bố cục theo từng nhóm cảnh; file `project/full/scenes.json` là phân công và timing của 255 cảnh. Cảnh ý niệm dùng sơ đồ; không ép thêm người đi lại khi cần tập trung nhìn cơ cấu.
- `project/full/timeline.json`: placements SFX, mức đỉnh, nguồn audio và độ dài. SFX thư viện tổng hợp có mô tả nguồn trong `public/audio/sfx/SOURCES.md`; không dùng nhạc hay giọng TTS.

Timing các cảnh theo SRT đã gửi. Các mốc thao tác bên trong câu là lựa chọn biên tập, chưa phải căn từng từ/âm vị. Nhân vật minh họa hành động trong lời dẫn, không lip-sync voice người kể. Cơ cấu là sơ đồ giải thích giản lược, không phải mô phỏng kỹ thuật để chế tạo thiết bị.

Các nhãn “giả định”, tính bất định và phân biệt Hero với Newcomen được giữ trong lời đọc và các nhãn biên tập thích hợp. Cảnh 10.04 tiếp tục cơ cấu đồng xu theo lời đọc; 10.05 chuyển sang chim và bình tự rót, sửa độ trễ của bảng minh họa gốc.

Video đầy đủ có chương và phụ đề SRT riêng. Tất cả file demo cũ được giữ nguyên trong repo.

## Các bản tải trên GitHub

Bản liền mạch được nén thêm ở 1080p để nằm dưới giới hạn 100 MiB/tệp của GitHub (H.264 CRF 27, AAC mono 80 kbps). Hai phần HQ giữ nguyên luồng hình của bản xuất gốc (CRF 22; đoạn mở đầu đã duyệt giữ bản gốc). Tất cả có cùng nội dung, timing và tốc độ voice. Hai phần HQ nối tại 18:03.7; bản liền mạch phù hợp để xem từ đầu đến cuối.
