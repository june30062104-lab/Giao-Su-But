# Sound-effect sources

All WAV assets in this folder are the original procedural sound-design library developed for the earlier explainer projects in this workspace. They were synthesized from seeded noise, filtered noise, sine oscillators, envelopes and short transients; no commercial music or downloaded film effects are used.

The `industry-*` files add machinery, ink, coins, waterwheel, mine-drip and shipping textures. The `original-*` names refer to original synthesized fire/gravel/pouring textures, not sounds extracted from the user’s reference video. Other short sounds represent steps, paper, taps, drawing and questions.

`project/full/timeline.json` lists the exact 22 files used after the approved opening, with times and gains. The approved opening’s separate 15 event placements and procedural mix script are in `project/demo-audio.json` and `scripts/audio-demo.py` (the video file includes its ready audio). Narration was supplied by the user and is not included as a sound-effect asset. No additional license is required for these original synthesized effects.
