import React from 'react';
export const ink='#27241f';
export const L=({d,...p}:React.SVGProps<SVGPathElement>)=><path d={d} fill="none" stroke={ink} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" {...p}/>;
export const Shape=({d,fill,...p}:React.SVGProps<SVGPathElement>)=><path d={d} fill={fill} stroke={ink} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" {...p}/>;
export const ease=(t:number,a:number,b:number)=>{let x=Math.max(0,Math.min(1,(t-a)/(b-a)));return x*x*(3-2*x)};
export const Flame=({t,scale=1}:{t:number;scale?:number})=><g transform={`scale(${scale})`}><path d={`M-15 0 Q-29 -24 -9 -42 Q-17 -61 1 ${-76+Math.sin(t*9)*6} Q4 -54 18 -42 Q39 -16 15 0Z`} fill="#d98948" stroke={ink} strokeWidth="2.5"/><path d={`M-7 -2 Q-15 -20 0 ${-45+Math.sin(t*7)*5} Q17 -18 8 -2Z`} fill="#f1cb77"/>{[0,1,2].map(i=><circle key={i} cx={Math.sin(t*2+i)*10} cy={-80-((t*31+i*23)%60)} r={1.5} fill="#e2a44f" opacity={.65}/>)}</g>;
export const Smoke=({t,x,y,opacity=.32}:{t:number;x:number;y:number;opacity?:number})=><g opacity={opacity}>{[0,1,2].map(i=><path key={i} d={`M${x+i*9} ${y} C${x-32+Math.sin(t+i)*12} ${y-45},${x+35} ${y-70},${x+Math.sin(t*.9+i)*24} ${y-115-i*21}`} fill="none" stroke="#e9e5d5" strokeWidth={8-i*1.8} strokeLinecap="round"/>)}</g>;
type PersonProps={x:number;y:number;s?:number;t:number;robe?:string;priest?:boolean;surprise?:number;action?:number;phase?:number};
export const Person=({x,y,s=1,t,robe='#a89168',priest=false,surprise=0,action=0,phase=0}:PersonProps)=>{
 const think=priest?0:ease(t,26,27.4)*(1-ease(t,31.7,33));const glance=priest?0:ease(t,9,9.8)*(1-ease(t,10.5,11.4));const blink=Math.sin(t*1.8+phase)> .992;const lean=priest?Math.sin(action*Math.PI)*5:Math.sin(t*1.6+phase)*.7;const hx=priest?35+action*67:40-surprise*5-think*16+glance*15,hy=priest?-72+action*22:-66-surprise*44-think*22-glance*24;
 return <g transform={`translate(${x} ${y}) scale(${s})`}>
 <ellipse cx="0" cy="7" rx="46" ry="9" fill="#6f725b" opacity=".12"/>
 <L d="M-13 -40 L-19 -6 L-34 0 M14 -40 L20 -7 L33 0" strokeWidth="5"/><Shape d="M-37 -1 Q-29 -8 -18 -5 L-13 3 L-37 4Z" fill="#856747"/><Shape d="M14 3 L19 -6 Q32 -5 38 2 L37 5Z" fill="#856747"/>
 <g transform={`rotate(${lean} 0 -45)`}>
 <Shape d="M-27 -117 Q-42 -95 -42 -70 L-48 -37 Q-5 -25 40 -38 L29 -116 Q-2 -131 -27 -117Z" fill={robe}/>
 <Shape d="M-23 -118 L-3 -88 L22 -119 L31 -105 L12 -70 L-13 -79Z" fill={priest?'#e4d7b6':'#b7c2a1'}/>
 <L d="M-30 -93 L-23 -64 L-3 -52" strokeWidth="5"/>
 <L d={`M22 -99 Q${20+action*22} ${-65-action*32} ${hx} ${hy}`} strokeWidth="5"/>
 <ellipse cx={hx} cy={hy} rx="7" ry="5" fill="#fffdf4" stroke={ink} strokeWidth="2" transform={`rotate(-20 ${hx} ${hy})`}/>
 <L d="M-29 -58 L-34 -43 M5 -62 L10 -40" strokeWidth="2" opacity=".5"/>
 <g transform={`translate(${priest?action*10:0} ${Math.sin(t*1.5+phase)*.7}) rotate(${surprise*-5+lean*.5+think*9+glance*5} 0 -150)`}>
 <Shape d="M-35 -153 C-38 -181 -19 -199 2 -199 C27 -199 41 -177 37 -150 C35 -126 19 -115 -3 -116 C-27 -116 -36 -131 -35 -153Z" fill="#fffdf6"/>
 {priest&&<><Shape d="M-35 -176 Q-36 -193 -20 -197 L25 -197 L37 -178 Q7 -184 -35 -176Z" fill="#b7a177"/><L d="M-34 -183 Q1 -190 33 -184" strokeWidth="2"/></>}
 {blink?<><L d="M5 -151 L12 -150" strokeWidth="3"/><L d="M23 -151 L29 -150" strokeWidth="3"/></>:<><ellipse cx={9-glance*9-think*2} cy="-150" rx="3" ry={3.8+surprise*2} fill={ink}/><ellipse cx={27-glance*9-think*2} cy="-150" rx="3" ry={3.8+surprise*2} fill={ink}/></>}
 {surprise>.4&&think<.5?<ellipse cx="19" cy="-133" rx="4.5" ry="6" fill={ink}/>:<L d="M12 -134 Q18 -128 24 -134" strokeWidth="2.5"/>}
 {surprise>.4&&<><L d="M3 -162 L12 -166 M23 -166 L31 -163" strokeWidth="2"/></>}
 </g>
 {priest&&<g transform={`translate(${hx} ${hy}) rotate(${5+action*9})`}><Shape d="M-4 4 L3 4 L4 -47 L-3 -47Z" fill="#825b3c"/><Shape d="M-9 -45 L10 -45 L8 -58 L-7 -58Z" fill="#8f7960"/><g transform="translate(0 -53)"><Flame t={t} scale={.45}/></g></g>}
 </g></g>
};
export const Column=({x,y,h=470}:{x:number;y:number;h?:number})=><g transform={`translate(${x} ${y})`}><Shape d={`M-31 0 L-26 ${-h+34} L26 ${-h+34} L32 0Z`} fill="#d3c8a7"/><Shape d={`M-42 ${-h+34} L-42 ${-h+55} L42 ${-h+55} L42 ${-h+34}Z`} fill="#e9ddba"/><Shape d={`M-50 ${-h+34} L-50 ${-h+17} L50 ${-h+17} L50 ${-h+34}Z`} fill="#d6c9a4"/><Shape d="M-44 0 L43 0 L49 18 L-49 18Z" fill="#e1d4b0"/><L d={`M-13 -9 L-12 ${-h+65} M10 -9 L12 ${-h+65}`} strokeWidth="1.8" opacity=".5"/></g>;
