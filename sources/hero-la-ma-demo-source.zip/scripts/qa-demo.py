from pathlib import Path
import json,subprocess,hashlib
p=Path(__file__).resolve().parents[1];movie=p/'output/hero-la-ma-demo.mp4'
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=codec_name,width,height,r_frame_rate,nb_frames','-of','json',str(movie)]))
v=next(s for s in info['streams'] if s['codec_name']=='h264');assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1920,1080,'30/1',1011)
assert any(s['codec_name']=='aac' for s in info['streams']);assert abs(float(info['format']['duration'])-33.7)<.05
subprocess.run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'],check=True)
manifest=json.loads((p/'project/demo-timeline.json').read_text());audio=json.loads((p/'project/demo-audio.json').read_text());assert audio['peak']<1
for s in manifest['assets']:assert (p/'public'/s).exists()
report={'composition':'HeroDemo','frameCount':1011,'fps':30,'resolution':'1920x1080','duration':float(info['format']['duration']),'fullDecode':'pass','typescript':'pass (tsc --noEmit)','voiceSpeed':1,'mixPeakBeforeEncoding':audio['peak'],'sfxPlacements':len(audio['events']),'sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'visualReview':'Contact sheet and isolated lighting/open-door frames inspected. Improved reaction framing and added glance/thinking gestures after review.','limits':'Narration only; no phoneme lip sync. Internal event timings editorial. No claim of exact reproduction of a reference video.'}
(p/'project/demo-qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
