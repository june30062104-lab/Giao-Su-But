from pathlib import Path
import numpy as np,subprocess,wave,json
p=Path(__file__).resolve().parents[1];sr=44100;duration=33.7
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p/'inputs/voice-part-01.mp3'),'-t',str(duration),'-ac','1','-ar',str(sr),'-f','f32le','-'])
voice=np.frombuffer(raw,dtype='<f4').copy();n=round(duration*sr);voice=np.pad(voice,(0,max(0,n-len(voice))))[:n];mix=voice.astype(np.float64)*.9;rng=np.random.default_rng(17);events=[]
def add(start,length,kind,gain):
 t=np.arange(round(length*sr))/sr;noise=rng.standard_normal(len(t));env=np.minimum(1,t/.025)*np.minimum(1,(length-t)/.12)
 if kind=='sea':
  smooth=np.convolve(noise,np.ones(160)/160,mode='same');a=smooth*(.6+.4*np.sin(t*1.1))
 elif kind=='step':a=noise*np.exp(-t*35)*.25+np.sin(2*np.pi*105*t)*np.exp(-t*24)*.22
 elif kind=='fire':a=noise*.065+np.sin(t*94)*noise*.03; a*=.5+.5*np.sin(t*31)**8
 elif kind=='door':a=(np.sin(2*np.pi*(140*t+13*np.sin(t*2)))+.3*np.sin(t*1900))*np.sin(np.pi*t/length)*.11+noise*.013
 elif kind=='cloth':a=noise*.1*np.sin(np.pi*t/length)**2
 elif kind=='chime':a=(np.sin(2*np.pi*660*t)+.4*np.sin(2*np.pi*990*t))*np.exp(-t*5)*.16
 elif kind=='swish':a=noise*.12*np.sin(np.pi*t/length)**3
 elif kind=='bird':a=np.sin(2*np.pi*(1700*t+120*np.sin(t*14)))*np.sin(np.pi*t/length)**2*.1
 else:a=noise*.01
 a*=gain*env;idx=round(start*sr);end=min(n,idx+len(a));mix[idx:end]+=a[:end-idx];events.append({'time':start,'duration':length,'type':kind,'gain':gain})
add(0,8.6,'sea',.35);add(1.9,.5,'bird',.2);add(5.0,.65,'bird',.16);add(8.63,.26,'swish',.3)
for i,st in enumerate([9.1,9.67,12.3,12.9]):add(st,.18,'step',.32+i*.02)
add(13.2,1.2,'cloth',.3);add(14.35,.5,'swish',.3);add(14.6,17.8,'fire',.19);add(17.15,4.6,'door',.55);add(21.6,.3,'step',.32);add(23.65,.32,'cloth',.3);add(25.0,.6,'chime',.22)
fade=np.minimum(1,(np.arange(n)[::-1]/sr)/.15);mix*=fade
peak=float(np.max(np.abs(mix)));assert peak<1,peak
with wave.open(str(p/'public/audio/demo-mix.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
(p/'project/demo-audio.json').write_text(json.dumps({'duration':duration,'voiceGain':.9,'speed':1,'peak':peak,'sfxProvenance':'Original procedural sound design: seeded noise and oscillators; no music.','events':events},indent=2))
print('Audio peak',peak,'events',len(events))
