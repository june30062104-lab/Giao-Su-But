SFX from existing project synthesised library; original-fire/gravel/pour generated locally by seeded filtered noise. No external licensed audio. Voice supplied by user.

Bản đầy đủ bổ sung industry-* bằng synth noise/oscillator có seed1788 trong scripts/prepare-full.py. 223 event placements dùng31file khác nhau; thư viện48file. Mix lossless đóng gói FLAC, bản bàn giao AAC96k mono giữ voice ở tốc độ ban đầu.
