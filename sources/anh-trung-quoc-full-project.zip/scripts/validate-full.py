from pathlib import Path
import json,sys,subprocess,hashlib
r=Path(__file__).resolve().parents[1];m=json.loads((r/'project/full/timeline.json').read_text());scenes=json.loads((r/'project/full/storyboard.json').read_text());cues=json.loads((r/'project/cues-full.json').read_text())
assert len(scenes)==116 and len(cues)==204 and m['duration']==900
assert len(m['voiceEnvelope'])==27000 and len(m['shots'])==116
assert scenes[0]['clipStart']==0 and scenes[-1]['clipEnd']==900
assert all(a['clipEnd']==b['clipStart'] for a,b in zip(scenes,scenes[1:]))
for s in scenes:
 assert abs(s['start']-cues[s['srtStart']-1]['start'])<.002
 assert abs(s['end']-cues[s['srtEnd']-1]['end'])<.002
 assert s['kind'] in ['opening','compare','network','foundry','city','printing','clock','waterwheel','sea','scholar','mine','engine','map','town','caravan','weaving','economy','plantation','farmland','coffee','experiment','exam','court','train','treaty','data','modern','lineup','growth']
 assert s['clipStart']<=s['start']<s['end']<=s['clipEnd']
for name in ['song-ironworks','britain-ironworks','song-city','mine','mill','port','coffee','court','farmland','modern','english-fields','plantation']:assert (r/'public/art'/f'{name}.png').is_file(),name
for fx in m['soundEffects']:assert 0<=fx['time']<900 and (r/'public'/fx['src']).is_file(),fx
assert (r/'public'/m['audio']).is_file()
assert m['mixPeak']<.95
print('FULL QA: 116 prompt scenes / 204 SRT cues; 29 visual families; 12 background plates; 900s; 27000 frames;',len(m['soundEffects']),'SFX; peak',m['mixPeak'])
if len(sys.argv)>1:
 p=Path(sys.argv[1]);meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]));v=next(x for x in meta['streams'] if x['codec_type']=='video');a=next(x for x in meta['streams'] if x['codec_type']=='audio')
 assert (v['codec_name'],v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==('h264',1920,1080,'30/1',27000)
 assert a['codec_name']=='aac' and abs(float(meta['format']['duration'])-900)<.06
 subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','/dev/null'],check=True)
 report={'duration':meta['format']['duration'],'frames':27000,'resolution':'1920x1080','fps':30,'video':'h264','audio':'aac','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'decode':'passed','scenes':116,'cues':204,'sfx':len(m['soundEffects'])}
 (r/'output/full/qa-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
