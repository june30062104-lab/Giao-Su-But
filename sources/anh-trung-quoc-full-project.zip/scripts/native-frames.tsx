import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {SceneVisual} from '../src/full-scenes';
import {Title} from '../src/full-film';
import {OpeningSvg} from '../src/film';
import {K} from '../src/full-primitives';
import fs from 'node:fs';
import path from 'node:path';
import scenes from '../project/full/storyboard.json';
import timeline from '../project/full/timeline.json';
const from=Number(process.argv.find(a=>a.startsWith('--from='))?.split('=')[1]??0);
const to=Number(process.argv.find(a=>a.startsWith('--to='))?.split('=')[1]??26999);
const out=path.resolve('output/full/native-frames');fs.mkdirSync(out,{recursive:true});
const images=path.join(out,'art');fs.mkdirSync(images,{recursive:true});for(const name of fs.readdirSync('public/art'))if(!fs.existsSync(path.join(images,name)))fs.copyFileSync(path.join('public/art',name),path.join(images,name));
const embedded=new Map<string,string>();for(const file of fs.readdirSync('output/full/art-jpeg'))embedded.set(file.replace('.jpg','.png'),'data:image/jpeg;base64,'+fs.readFileSync(path.join('output/full/art-jpeg',file)).toString('base64'));
let i=0;
for(let f=from;f<=to;f++){
 const time=f/30;while(i<scenes.length-1&&time>=scenes[i].clipEnd)i++;
 const s=scenes[i],t=time-s.clipStart,iris=[22,52,64,83,105].includes(s.index);
 let svg=s.index<=3?renderToStaticMarkup(<OpeningSvg t={time}/>):renderToStaticMarkup(<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1280 720"><rect width="1280" height="720" fill="#faf0da"/><defs><clipPath id="chapter-iris"><circle cx="640" cy="360" r={iris?K(t,0,.4,0,1490):1490}/></clipPath></defs><g clipPath="url(#chapter-iris)"><SceneVisual s={s} t={t} level={timeline.voiceEnvelope[f]??0}/></g><Title text={s.title} t={t}/><rect width="1280" height="720" fill="#302b28" opacity={K(time,899.78,900)}/></svg>);
 svg=svg.replaceAll('font-family="Patrick"','font-family="Patrick Hand"').replaceAll('href="/','href="');
 svg=svg.replace(/href="art\/([^"]+)"/g,(_,name)=>{const data=embedded.get(name);if(!data)throw new Error('Missing embedded image '+name);return 'href="'+data+'"';});
 fs.writeFileSync(path.join(out,`frame-${String(f).padStart(5,'0')}.svg`),svg);
 if(f%1500===0)console.log('Authored Remotion SVG frames',f,'/27000');
}
console.log('SVG frames ready',from,to);
