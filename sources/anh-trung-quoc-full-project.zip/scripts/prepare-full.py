from pathlib import Path
import json,subprocess,wave,shutil,numpy as np,csv
r=Path(__file__).resolve().parents[1];rate=44100;dur=900;n=rate*dur
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(r/'inputs/voice-original.mp3'),'-ar',str(rate),'-ac','1','-f','f32le','-']);voice=np.frombuffer(raw,'<f4');mix=np.zeros(n,np.float32);mix[:len(voice)]=voice*.9
base=r/'public/audio/sfx';sfxdir=r/'public/audio/sfx'
# Existing synthesised SFX remain packaged locally after initial preparation.
if base.exists():
 for src in base.glob('*.wav'):
  if not (sfxdir/src.name).exists():shutil.copy2(src,sfxdir/src.name)
def load(path):
 with wave.open(str(path)) as w:
  assert w.getframerate()==rate and w.getsampwidth()==2
  a=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
  return a.reshape(-1,w.getnchannels()).mean(axis=1)
# Keep the already approved opening's mix; no altered voice speed.
first=load(r/'public/audio/preview-mix.wav');mix[:len(first)]=first
cache={p.stem:load(p) for p in sfxdir.glob('*.wav')}
rng=np.random.default_rng(1788)
for j,kind in enumerate(['steam','gears','mine-drips','ship-creak','loom-shuttle','train','stamp','ink','coins','cotton','ore','waterwheel']):
 size=int(rate*(.6+(j%3)*.25));ts=np.arange(size)/rate;noise=rng.normal(0,1,size).astype(np.float32);smooth=np.convolve(noise,np.ones(17)/17,mode='same');env=np.sin(np.linspace(0,np.pi,size))**.9
 if kind in ['steam','cotton']:a=smooth*env*.29
 elif kind in ['mine-drips','ink','waterwheel']:a=(np.sin(ts*2*np.pi*(540+330*np.exp(-ts*6)))+smooth*.7)*env*np.exp(-ts*3)*.2
 elif kind in ['coins','stamp','ore']:a=(smooth+np.sin(ts*2*np.pi*(750+j*31))*.2)*env*np.exp(-ts*6)*.5
 else:a=(smooth*.5+np.sin(ts*2*np.pi*(100+j*9))*.15)*env*(.3+.7*np.sin(ts*(31+j))**8)*.5
 a=a.astype(np.float32);name='industry-'+kind;cache[name]=a
 with wave.open(str(sfxdir/(name+'.wav')),'wb') as w:w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes((a*32767).astype('<i2').tobytes())
scenes=json.loads((r/'project/full/storyboard.json').read_text());cues=json.loads((r/'project/cues-full.json').read_text());fx=[]
pools={'engine':['industry-steam','industry-gears','industry-waterwheel'],'mine':['industry-mine-drips','industry-ore','water'],'weaving':['industry-loom-shuttle','industry-cotton','curtain-swish'],'sea':['industry-ship-creak','water','paper-note'],'city':['steps','industry-coins','soft-tap'],'scholar':['paper-note','industry-ink','pencil-cross'],'court':['industry-stamp','paper-note','steps'],'train':['industry-train','industry-gears'],'modern':['industry-train','industry-gears'],'foundry':['industry-ore','industry-steam'],'network':['soft-pop','brain-pop','focus-pop'],'data':['paper-note','caption-snap','red-pencil'],'coffee':['soft-tap','paper-note','industry-gears']}
def place(time,name,gain):
 a=cache[name];at=round(time*rate);take=min(len(a),n-at)
 mix[at:at+take]+=a[:take]*gain;fx.append(dict(time=round(time,3),src=f'audio/sfx/{name}.wav',volume=gain))
for s in scenes:
 if s['index']<=3:continue
 pool=pools.get(s['kind'],['paper-note','soft-pop','industry-gears','soft-tap']);place(s['clipStart']+.18,pool[s['index']%len(pool)],.13)
 local=[c for c in cues if s['srtStart']<=c['id']<=s['srtEnd']]
 for k,c in enumerate(local[1:]):place(c['start']+.08,pool[(s['index']+k+1)%len(pool)],.105)
 if s['clipEnd']-s['clipStart']>7 and len(local)==1:place(s['clipStart']+4.1,pool[(s['index']+1)%len(pool)],.09)
# Very quiet contextual ambience, separated from narration and event accents.
for s in scenes:
 if s['kind'] not in ['mine','engine','sea','foundry','weaving','train']:continue
 if s['index']<=3:continue
 start=round(s['clipStart']*rate);end=min(n,round(s['clipEnd']*rate));length=end-start
 noise=rng.normal(0,1,length).astype(np.float32);a=np.convolve(noise,np.ones(29)/29,mode='same').astype(np.float32)*.008
 edge=min(rate//3,length//2);a[:edge]*=np.linspace(0,1,edge);a[-edge:]*=np.linspace(1,0,edge);mix[start:end]+=a
peak=float(np.abs(mix).max());assert peak<.95,peak
mix[-int(.18*rate):]*=np.linspace(1,0,int(.18*rate))
with wave.open(str(r/'public/audio/full-mix.wav'),'wb') as w:w.setparams((1,2,rate,0,'NONE','not compressed'));w.writeframes((mix*32767).astype('<i2').tobytes())
env=[round(float(np.sqrt(np.mean(voice[i:i+1470]**2))),4) for i in range(0,len(voice),1470)];env+=(27000-len(env))*[0]
opening=json.loads((r/'project/preview-timeline.json').read_text())
manifest={'profile':{'width':1920,'height':1080,'fps':30},'duration':900,'audio':'audio/full-mix.wav','shots':[dict(id=s['id'],start=s['clipStart'],end=s['clipEnd'],kind=s['kind'],variant=s['variant'],title=s['title'],srtStart=s['srtStart'],srtEnd=s['srtEnd']) for s in scenes],'soundEffects':opening['soundEffects']+fx,'voiceEnvelope':env,'cues':cues,'mixPeak':peak,'notes':['All 116 original prompt scenes retained. Gaps between SRT cues held by previous scene.','Original audio speed unchanged. Source claims are illustrated as supplied, not independently fact-checked.','Generated background plates are reused in original staged compositions; actors and objects animated separately.']}
(r/'project/full/timeline.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
with (r/'project/full/shotlist.csv').open('w') as f:
 fields=list(manifest['shots'][0]);w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(manifest['shots'])
print('900 seconds;',len(scenes),'scenes;',len(manifest['soundEffects']),'event SFX;',len(cache),'available sounds; peak',peak)
