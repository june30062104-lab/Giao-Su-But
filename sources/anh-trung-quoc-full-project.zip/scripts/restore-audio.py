from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1];wav=r/'public/audio/full-mix.wav';flac=r/'public/audio/full-mix.flac'
if not wav.exists():
 if flac.exists():subprocess.run(['ffmpeg','-v','error','-i',str(flac),str(wav)],check=True)
 else:subprocess.run(['python',str(r/'scripts/prepare-full.py')],check=True)
print('Full mixed audio ready:',wav)
