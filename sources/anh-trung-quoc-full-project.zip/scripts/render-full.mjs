import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {selectComposition,renderMedia} from '@remotion/renderer';
const serveUrl=fs.readFileSync('output/full/bundle-path.txt','utf8').trim();
const composition=await selectComposition({serveUrl,id:'IndustryFull',browserExecutable:'/usr/bin/chromium'});
const benchmark=process.argv.includes('--benchmark');
const chunks=benchmark?[[12465,12584]]:Array.from({length:6},(_,i)=>[i*4500,(i+1)*4500-1]);
for(let i=0;i<chunks.length;i++){
 const range=chunks[i];const outputLocation=path.resolve(benchmark?'output/full/benchmark.mp4':`output/full/part-${String(i+1).padStart(2,'0')}.mp4`);
 if(!benchmark&&fs.existsSync(outputLocation)){
  try{const frames=Number(JSON.parse(execFileSync('ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=nb_frames','-of','json',outputLocation],{encoding:'utf8'})).streams[0].nb_frames);if(frames===4500){console.log('Resume: verified existing chapter',i+1);continue;}}catch{}
 }
 const start=Date.now();let last=-1;
 console.log('START',benchmark?'benchmark':`chapter ${i+1}/6`,range.join('-'));
 await renderMedia({serveUrl,composition,codec:'h264',outputLocation,frameRange:range,muted:true,crf:20,x264Preset:'fast',imageFormat:'jpeg',jpegQuality:90,concurrency:4,chromiumOptions:{enableMultiProcessOnLinux:true},browserExecutable:'/usr/bin/chromium',logLevel:'warn',onProgress:p=>{const mark=Math.floor(p.renderedFrames/150);if(mark!==last){last=mark;const state={chapter:i+1,totalChapters:chunks.length,renderedFrames:p.renderedFrames,chapterFrames:range[1]-range[0]+1,overallFrames:i*4500+p.renderedFrames,totalFrames:27000,elapsedSeconds:Math.round((Date.now()-start)/1000)};fs.writeFileSync('output/full/render-state.json',JSON.stringify(state));console.log(JSON.stringify(state));}}});
 console.log('DONE',benchmark?'benchmark':i+1,Math.round((Date.now()-start)/1000),'seconds',fs.statSync(outputLocation).size,'bytes');
}
