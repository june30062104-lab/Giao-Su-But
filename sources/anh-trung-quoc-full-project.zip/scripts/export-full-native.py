"""Export the authored Remotion SVG scene graph through FFmpeg/librsvg, or use npm run render:full for Chromium."""
from pathlib import Path
import subprocess,os
r=Path(__file__).resolve().parents[1];os.chdir(r);out=r/'output/full';out.mkdir(parents=True,exist_ok=True);(out/'art-jpeg').mkdir(exist_ok=True)
if not (r/'public/audio/full-mix.wav').exists():subprocess.run(['python','scripts/restore-audio.py'],check=True)
for src in (r/'public/art').glob('*.png'):
 dst=out/'art-jpeg'/(src.stem+'.jpg')
 if not dst.exists():subprocess.run(['ffmpeg','-v','error','-i',str(src),'-q:v','2','-pix_fmt','yuvj444p','-frames:v','1',str(dst)],check=True)
(out/'fonts.conf').write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>'+str(r/'public/fonts')+'</dir><cachedir>'+str(out/'font-cache')+'</cachedir><config></config></fontconfig>')
subprocess.run(['npx','--no-install','esbuild','scripts/native-frames.tsx','--bundle','--platform=node','--packages=external','--outfile=output/full/native-frames.cjs','--format=cjs'],check=True)
subprocess.run(['node','output/full/native-frames.cjs','--from=0','--to=26999'],check=True)
subprocess.run(['python','scripts/render-native-full.py'],check=True)
print('Master ready: output/anh-trung-quoc-full-master.mp4')
