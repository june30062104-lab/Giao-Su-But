from pathlib import Path
import argparse,json,subprocess
r=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--input',type=Path);a=p.parse_args();default=r/'output/anh-trung-quoc-full-master.mp4';src=a.input or (default if default.exists() else r/'output/anh-trung-quoc-full-remotion.mp4')
subprocess.run(['python',str(r/'scripts/restore-audio.py')],check=True)
dur=json.loads((r/'project/full/timeline.json').read_text())['duration'];out=r/'output/anh-trung-quoc-full-1080p.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(src),'-i',str(r/'public/audio/full-mix.wav'),'-i',str(r/'project/full/chapters.ffmeta'),'-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-c:v','copy','-c:a','aac','-b:a','96k','-t',str(dur),'-movflags','+faststart',str(out)],check=True)
print('Delivery:',out,out.stat().st_size,'bytes')
