from pathlib import Path
import subprocess,concurrent.futures,os,json,time
r=Path(__file__).resolve().parents[1];out=r/'output/full';env=os.environ.copy();env['FONTCONFIG_FILE']=str(out/'fonts.conf');frames=out/'native-frames'
# Same frame-driven React/Remotion SVG components; native rasterisation avoids browser capture overhead.
# Chapter 01 already rendered using Remotion's browser renderer, preserved unchanged.
def render(index):
 start=index*4500;dest=out/f'part-{index+1:02d}.mp4';beg=time.time()
 if dest.exists():
  try:
   v=int(json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames','-of','json',str(dest)]))['streams'][0]['nb_frames'])
   if v==4500:print('REUSE',index+1,flush=True);return dest
  except Exception:pass
 cmd=['ffmpeg','-hide_banner','-y','-framerate','30','-start_number',str(start),'-i',str(frames/'frame-%05d.svg'),'-frames:v','4500','-an','-c:v','libx264','-crf','20','-preset','fast','-threads','1','-pix_fmt','yuv420p','-video_track_timescale','15360',str(dest)]
 with (out/f'native-part-{index+1:02d}.log').open('w') as log:subprocess.run(cmd,check=True,env=env,stdout=log,stderr=log)
 print(json.dumps({'completedChapter':index+1,'frames':4500,'seconds':round(time.time()-beg,1),'bytes':dest.stat().st_size}),flush=True);return dest
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:files=list(pool.map(render,range(6)))
listing=out/'concat.txt';listing.write_text(''.join("file '"+str(f)+"'\n" for f in files))
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(listing),'-i',str(r/'public/audio/full-mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-t','900','-movflags','+faststart',str(r/'output/anh-trung-quoc-full-master.mp4')],check=True)
print('MASTER_COMPLETE',flush=True)
