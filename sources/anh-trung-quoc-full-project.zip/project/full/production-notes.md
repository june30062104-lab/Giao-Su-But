# Bản đầy đủ — Anh và Trung Quốc

## Đầu vào và timing

Voice gốc 899,78775 giây; SRT 204 câu, kết thúc ở 899,640 giây. Tất cả 116 cảnh prompt đã đối chiếu start/end với phạm vi SRT tương ứng. Video dài 900 giây, 27000 khung hình 1920×1080/30 FPS; khoảng lặng giữa các cảnh giữ hình của cảnh trước, không tự đổi tốc độ hoặc dịch lời đọc.

## Hình ảnh và diễn xuất

Giữ phong cách bản thử: nền giấy kem, nét tối, màu phẳng ấm, người đầu trắng tròn và tay chân mảnh. 116 bố cục được gán riêng trong storyboard, dùng 29 nhóm cách thể hiện. Có 12 bối cảnh vẽ mới dùng lại theo địa điểm; nhân vật, máy móc, đồ vật và sơ đồ được vẽ SVG và chuyển động riêng. Không tuyên bố đã tạo 116 ảnh AI độc lập. Các hình lịch sử là minh họa, không phải phục dựng khảo cổ đã được xác minh từng chi tiết.

Đã tách bối cảnh Trung Quốc, đồng quê Anh và đồn điền châu Mỹ để tránh dùng lẫn kiến trúc/cây trồng rõ rệt. Nét mặt, cử chỉ tay, máy hơi nước, bánh xe, nước mỏ, thuyền, máy dệt và tàu chạy theo frame. Miệng trong cảnh trao đổi dùng biên độ voice, chưa phải lip-sync âm vị. Đồ họa bản đồ là sơ đồ vị trí, không dùng như bản đồ ranh giới chính xác.

Các con số và cách diễn đạt bất định theo lời người dùng: ước tính sắt thời Tống khác số liệu gang thô Anh; GDP là tỷ trọng ước tính lịch sử; dữ liệu thép năm2025 được minh họa như kịch bản cung cấp, không tuyên bố đã fact-check độc lập.

## Âm thanh

Giữ voice nguyên tốc độ, gain0,9; mix mono ở giữa. Tổng223 mốc SFX từ31 file được dùng, cùng ambience rất nhẹ theo mỏ/biển/xưởng. Bộ synth có48 âm thanh sẵn có, không đồng nghĩa48 âm thanh đều được phát. Không thêm nhạc/TTS. Mix peak trước AAC0,82945, không clipping. Track âm thanh được ghép một lần cho cả900giây để tránh sai khác padding AAC giữa các đoạn hình.

## Xuất

Source là composition Remotion IndustryFull. Có hai đường xuất: Chromium/Remotion renderer đầy đủ (`npm run render:full`), hoặc xuất cùng React SVG scene graph rồi raster bằng FFmpeg/librsvg để giảm chi phí chụp frame trình duyệt (`npm run render:native`). Bản giao có đoạn đầu150giây đã xuất bằng Remotion renderer; phần tiếp theo dùng cùng các component, timing, font qua native path. Đã đối chiếu khung hình của hai đường xuất; không khẳng định giống từng byte/pixel trên mọi môi trường.

Asset PNG gốc được giữ. Native path nhúng JPEG chất lượng cao của bối cảnh vào SVG để tránh tham chiếu ảnh ngoài bị bỏ qua bởi bộ raster, và cấu hình Fontconfig dùng đúng Patrick Hand. Không giảm FPS hoặc độ phân giải. Các đoạn được chuẩn timebase và ghép với một track voice/SFX. Mã nguồn giữ đường xuất Chromium nếu môi trường khác không có FFmpeg/librsvg.
