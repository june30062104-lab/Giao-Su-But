# Cách mạng công nghiệp: Anh và Trung Quốc

Dự án đầy đủ theo voice, SRT và 116 prompt do người dùng gửi. Composition `IndustryFull`: 900 giây, 1920×1080, 30 FPS, 27000 frame. Composition `IndustryPreview` giữ bản thử 26,8 giây đã duyệt.

## Đầu vào và dữ liệu

- `inputs/voice-original.mp3`, `inputs/original.srt`, `inputs/prompts.md`: nguyên bản, không chỉnh sửa.
- `project/scenes-full.json`, `project/cues-full.json`: 116 cảnh và204 câu.
- `project/full/storyboard.json`: cách thể hiện cụ thể của từng cảnh.
- `project/full/timeline.json`, `shotlist.csv`, `chapters.json`: timing, SFX, waveform và chương.
- `public/art`: 12 bối cảnh PNG mới; nhân vật/đồ vật/sơ đồ được vẽ và hoạt hình bằng component SVG trong `src/`.

## Chạy bằng Remotion

Cần Node.js22+, npm, Python3, ffmpeg/ffprobe. Dependencies được pin version.

```bash
npm install
npm run studio
npm run typecheck
npm run prepare:audio
npm run check:full
npm run render:full
npm run deliver:full
```

Nếu cần Chromium hệ thống trên Linux, thêm `--browser-executable=/usr/bin/chromium` vào lệnh render. File xuất trực tiếp từ Remotion: `output/anh-trung-quoc-full-remotion.mp4`.

## Đường xuất nhanh cho SVG

Cần FFmpeg có decoder `librsvg` và Fontconfig. Đường này dùng cùng React/Remotion components và thời gian frame, không thay thế scene bằng ảnh tĩnh.

```bash
npm run render:native
```

Script dựng các SVG frame, nhúng bối cảnh JPEG chất lượng cao (PNG gốc giữ nguyên), cấu hình fontPatrick Hand, xuất6 đoạn hình và ghép một track âm thanh liền. Cần khoảng10GB trống để lưu frame trung gian. File master: `output/anh-trung-quoc-full-master.mp4`. Chạy `npm run deliver:full` để ghép12chương và AAC96k mono vào file bàn giao `output/anh-trung-quoc-full-1080p.mp4` mà không encode lại hình. Các đoạn4500frame đã kiểm hợp lệ được dùng lại nếu tiếp tục tác vụ.

## Âm thanh và QA

Mix đầy đủ được đóng gói lossless trong `public/audio/full-mix.flac`. Chạy `npm run prepare:audio` để khôi phục WAV trước khi kiểm tra/render. Không thay đổi tốc độ hay mẫu âm thanh. Nếu muốn tạo lại: `python scripts/prepare-full.py` (cần NumPy); voice giữ nguyên tốc độ. Có223 placement từ31 SFX được phát và ambience nhẹ. 48 sound assets có trong thư viện, không phải tất cả đều phát. Không thêm nhạc/TTS.

```bash
python scripts/validate-full.py output/anh-trung-quoc-full-master.mp4
```

Validator kiểm dữ liệu và MP4 thực: độ dài, frame count, fps, kích thước, codec và decode toàn clip. `scripts/render-qa-frames.mjs` xuất khung hình đại diện116cảnh bằng Remotion để rà layout; render:native có thể dùng khi không có đường xuất trình duyệt hiệu quả.

Xem `project/full/production-notes.md` để biết cách dựng, giới hạn minh họa lịch sử, dữ liệu chưa fact-check độc lập và phạm vi kiểm thử. Bản đồ là sơ đồ minh họa, miệng chuyển theo RMS, chưa phải lip-sync âm vị.
